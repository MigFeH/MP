package uo.mp2122.newsstand.comparators;

import java.util.Comparator;

import uo.mp2122.newsstand.domain.Publication;

public class PublicationsBySalesComparator implements Comparator<Publication> {

	@Override
	public int compare(Publication o1, Publication o2) {
		return o1.getSales() - o2.getSales();
		
		/* ALTERNATIVA (si son enteros):
		return ((Integer) (o1.getSales())).compareTo((Integer) (o2.getSales()));
		*/
	}

}
