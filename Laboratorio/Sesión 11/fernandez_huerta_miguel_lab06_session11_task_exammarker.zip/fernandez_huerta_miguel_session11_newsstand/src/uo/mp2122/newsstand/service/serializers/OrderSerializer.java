package uo.mp2122.newsstand.service.serializers;

import java.util.ArrayList;
import java.util.List;

import uo.mp2122.newsstand.domain.Order;

public class OrderSerializer { // es simétrico al parser (es como hacer un toString)

	/**
	 * Returns a list of String out of a list of Orders
	 * @param orders, the list of orders to convert
	 * @return a list of String-serialized orders
	 */
	public List<String> serialize(List<Order> orders) {
		List<String> result = new ArrayList<>();
		
		for(Order order : orders)
		{
			result.add(order.serialize());
		}
		return result;
	}

}
