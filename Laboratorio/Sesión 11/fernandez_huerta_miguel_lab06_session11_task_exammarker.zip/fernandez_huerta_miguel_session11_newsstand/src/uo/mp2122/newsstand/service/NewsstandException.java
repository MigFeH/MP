package uo.mp2122.newsstand.service;

public class NewsstandException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public NewsstandException() {
		// TODO Auto-generated constructor stub
	}
	
	public NewsstandException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
