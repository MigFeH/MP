package uo.mp2122.newsstand.exception;

public class NotYetImplementedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
