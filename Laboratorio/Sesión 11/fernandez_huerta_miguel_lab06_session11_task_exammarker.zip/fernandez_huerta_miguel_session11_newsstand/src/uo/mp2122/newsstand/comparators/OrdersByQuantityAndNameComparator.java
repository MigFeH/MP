package uo.mp2122.newsstand.comparators;

import java.util.Comparator;

import uo.mp2122.newsstand.domain.Order;

public class OrdersByQuantityAndNameComparator implements Comparator<Order> {

	@Override
	public int compare(Order o1, Order o2) {
		int diff = o1.getQuantity() - o2.getQuantity();
		if (diff == 0) // si son iguales en cantidad...
		{
			return o1.getName().compareTo(o2.getName());
		} else {
			return diff;
		}
	}

}
