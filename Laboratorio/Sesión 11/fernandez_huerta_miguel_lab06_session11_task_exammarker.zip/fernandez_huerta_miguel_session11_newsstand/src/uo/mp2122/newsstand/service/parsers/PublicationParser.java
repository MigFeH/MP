package uo.mp2122.newsstand.service.parsers;

import java.util.ArrayList;
import java.util.List;

import uo.mp2122.newsstand.domain.Magazine;
import uo.mp2122.newsstand.domain.Newspaper;
import uo.mp2122.newsstand.domain.Publication;
import uo.mp2122.util.log.Logger;

public class PublicationParser {
	
	private int lineNumber = 0;

	/**
	 * Transforms a list of Strings in a list of instances of Publication.
	 * Any of the following are invalid lines in the input file: 
	 * 		- blank lines, 
	 * 		- wrong number of fields in a line, and 
	 * 		- incorrect data format in numeric fields.
	 * Invalid lines will not produce a Publication instance but will throw an InvalidLineFormatException instead.
	 * As a result of processing this exception, a message will be written to a log (use Log) 
	 * @param lines non-null list of strings, probably empty
	 * 		One by each publication
	 * 				type_of_publication \t name_of_publication \t sales \t stock \t frequency
	 * 
	 * @return a list of publications
	 */
	public List<Publication> parse(List<String> lines) {
		List<Publication> list = new ArrayList<>();
		for (String line: lines)
		{
			lineNumber++;
			Publication publication;
			try {
				publication = parseLine(line); // convierte una línea en publicación y la retorna
				list.add(publication);
			} catch (InvalidLineFormatException e) {
				Logger.log(e.getMessage()); // graba un mensaje pasado como parámetro y lo escribe en el archivo log
			}
		}
		return list;
	}

	private Publication parseLine(String line) throws InvalidLineFormatException {
		checkIsBlank(line);
		String[] parts = line.split("\t");
		String type = parts[0];
		if (type.equals("newspaper"))
		{
			return parseNewspaper(parts); // creará un Newspaper y lo retornará
		} else if (type.equals("magazine"))
		{
			return parseMagazine(parts); // creará un Magazine y lo retornará
		} else
		{
			throw new InvalidLineFormatException(lineNumber, "TIPO DESCONOCIDO");
		}
	}

	private void checkIsBlank(String line) throws InvalidLineFormatException{
		if (line.isBlank())
		{
			throw new InvalidLineFormatException(lineNumber, "LINEA EN BLANCO");
		}
	}

	private Publication parseMagazine(String[] parts) throws InvalidLineFormatException {
		checkParts(parts, 5);
		String name = parts[1];
		int stock = toInteger(parts[2]);
		int sales = toInteger(parts[3]);
		int frecuency = toInteger(parts[4]);
		return new Magazine(name, stock, sales, frecuency);
	}

	private Publication parseNewspaper(String[] parts) throws InvalidLineFormatException {
		checkParts(parts, 4);
		String name = parts[1];
		int stock = toInteger(parts[2]);
		int sales = toInteger(parts[3]);
		return new Newspaper(name, stock, sales);
	}

	private void checkParts(String[] parts, int i) throws InvalidLineFormatException {
		if (parts.length != i)
		{
			throw new InvalidLineFormatException(lineNumber, "NUMERO DE CAMPOS NO VÁLIDO");
		}
		
	}

	private int toInteger(String string) throws InvalidLineFormatException {
		try {
			return Integer.parseInt(string); // le pasan un string y devuelve el int que representa
		} catch (NumberFormatException e)
		{
			throw new InvalidLineFormatException(lineNumber, "FORMATO DE NUMERO NO VALIDO");
		}
		
	}

}
