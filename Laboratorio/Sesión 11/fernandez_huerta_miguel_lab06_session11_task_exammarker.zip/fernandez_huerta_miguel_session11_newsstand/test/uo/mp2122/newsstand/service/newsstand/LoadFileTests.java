package uo.mp2122.newsstand.service.newsstand;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.List;

import org.junit.Test;

import uo.mp2122.newsstand.domain.Publication;
import uo.mp2122.newsstand.service.Newsstand;
import uo.mp2122.newsstand.service.NewsstandException;

public class LoadFileTests {
	
	/**
	 * GIVEN: Nombre de fichero que es un String vacío
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Salta NewsstandException
	 */
	@Test
	public void testLoadFileWithEmptyFileName()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("");
		} catch(NewsstandException | FileNotFoundException e)
		{
			assertEquals("Nombre de fichero no válido", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero null
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Salta NewsstandException
	 */
	@Test
	public void testLoadFileWithNullFileName()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile(null);
		} catch(NewsstandException | FileNotFoundException e)
		{
			assertEquals("Nombre de fichero no válido", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero de longitud mayor del máximo permitido (25 caracteres)
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Salta NewsstandException
	 */
	@Test
	public void testLoadFileWithTooLongFileName()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("hghghghghghghghghghghghghghghg");
		} catch(NewsstandException | FileNotFoundException e)
		{
			assertEquals("Nombre de fichero demasiado largo (supera el límite de " 
					+ Newsstand.MAX_STRINGS_LENGTH + "caracteres)", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: El nombre del fichero no existe
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Salta FileNotFoundException
	 */
	@Test
	public void testLoadFileWithNonExistingFileName()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publications2.txt");
		} catch(NewsstandException | FileNotFoundException e)
		{
			// Salta FileNotFoundException sin mensaje
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero existente y válido
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Se cargan los elementos del fichero
	 */
	@Test
	public void testLoadFileWithCorrectFileName()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publications.txt");
		} catch (FileNotFoundException | NewsstandException e) 
		{
			// No salta ninguna excepción
		}
		
		List<Publication> aux = ns.getPublications();
		
		for(int i = 0; i < aux.size(); i++)
		{
			assertNotNull(aux.get(i));
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero existente y válido pero conteniendo 
	 * publicaciones de tipos desconocidos
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Se lanza InvalidLineFormatException que, antes de llegar 
	 * al LoadFile(), se trata la excepción
	 */
	@Test
	public void testLoadFileWithCorrectFileNameAndUnknownPublicationTypes()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publicationsUnknownType.txt");
		} catch (FileNotFoundException | NewsstandException e) 
		{
			// No salta ninguna excepción
		}
		
		List<Publication> aux = ns.getPublications();
		
		for(int i = 0; i < aux.size(); i++)
		{
			assertNotNull(aux.get(i));
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero existente y válido pero conteniendo 
	 * líneas vacías
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Se lanza InvalidLineFormatException que, antes de llegar 
	 * al LoadFile(), se trata la excepción
	 */
	@Test
	public void testLoadFileWithCorrectFileNameAndEmptyLines()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publicationsWithEmptyLines.txt");
		} catch (FileNotFoundException | NewsstandException e) 
		{
			// No salta ninguna excepción
		}
		
		List<Publication> aux = ns.getPublications();
		
		for(int i = 0; i < aux.size(); i++)
		{
			assertNotNull(aux.get(i));
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero existente y válido pero conteniendo 
	 * números no válidos
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Se lanza InvalidLineFormatException que, antes de llegar 
	 * al LoadFile(), se trata la excepción
	 */
	@Test
	public void testLoadFileWithCorrectFileNameAndWrongNumbers()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publicationsWithWrongNumbers.txt");
		} catch (FileNotFoundException | NewsstandException e) 
		{
			// No salta ninguna excepción
		}
		
		List<Publication> aux = ns.getPublications();
		
		for(int i = 0; i < aux.size(); i++)
		{
			assertNotNull(aux.get(i));
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero existente y válido pero conteniendo 
	 * un número de campos inválido
	 * WHEN: Se invoca al método LoadFile()
	 * THEN: Se lanza InvalidLineFormatException que, antes de llegar 
	 * al LoadFile(), se trata la excepción
	 */
	@Test
	public void testLoadFileWithCorrectFileNameAndWrongNumberFields()
	{
		Newsstand ns = new Newsstand();
		
		try {
			ns.loadFile("publicationsWrongNumberFields.txt");
		} catch (FileNotFoundException | NewsstandException e) 
		{
			// No salta ninguna excepción
		}
		
		List<Publication> aux = ns.getPublications();
		
		for(int i = 0; i < aux.size(); i++)
		{
			assertNotNull(aux.get(i));
		}
	}

}
