package uo.mp2122.newsstand.service.parsers;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import uo.mp2122.newsstand.domain.Magazine;
import uo.mp2122.newsstand.domain.Publication;

public class ParseMagazineTests {
	
	/**
	 * GIVEN: Fichero de periódicos vacío
	 * WHEN: Se invoca al método parse()
	 * THEN: Retorna una lista vacía
	 */
	@Test
	public void testParseWithEmptyMagazineFile()
	{
		List<String> file = new ArrayList<>();
		List<Publication> aux = new ArrayList<>();
		PublicationParser pp = new PublicationParser();
		
		for (int i = 1; i < 6; i++)
		{
			file.add("");
		}
		assertEquals(aux, pp.parse(file));
	}
	
	/**
	 * GIVEN: Fichero de periódicos no vacío
	 * WHEN: Se invoca al método parse()
	 * THEN: Retorna una lista con el periódico
	 */
	@Test
	public void testParseWithMagazineFile()
	{
		List<String> file = new ArrayList<>();
		List<Publication> aux = new ArrayList<>();
		PublicationParser pp = new PublicationParser();
		
		file.add("magazine	Hola	14	30	7");
		aux.add(new Magazine("Hola", 14, 30, 7));		
		
		assertEquals(aux, pp.parse(file));
	}
	
	/**
	 * GIVEN: Fichero de periódicos
	 * WHEN: Se invoca al método parse()
	 * THEN: Retorna una lista con los periódicos
	 */
	@Test
	public void testParseWithManyMagazinesFile()
	{
		List<String> file = new ArrayList<>();
		List<Publication> aux = new ArrayList<>();
		PublicationParser pp = new PublicationParser();
		
		file.add("magazine	Hola	14	30	7");
		file.add("magazine	PCWord	14	30	30");
		
		aux.add(new Magazine("Hola", 14, 30, 7));
		aux.add(new Magazine("PCWord", 14, 30, 30));
		
		assertEquals(aux, pp.parse(file));
	}
	
	/**
	 * GIVEN: Fichero de periódico no válido (datos incorrectos)
	 * WHEN: Se invoca al método parse()
	 * THEN: Salta IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testParseWithInvalidMagazineFieldFile()
	{
		List<String> file = new ArrayList<>();
		List<Publication> aux = new ArrayList<>();
		PublicationParser pp = new PublicationParser();
		
		file.add("magazine	Hola	14	30	-7");
		
		assertEquals(aux, pp.parse(file));
	}
	
	/**
	 * GIVEN: Fichero de periódico no válido (número de campos incorrecto)
	 * WHEN: Se invoca al método parse()
	 * THEN: No se crea el periódico, retorna lista vacía
	 */
	@Test
	public void testParseWithInvalidMagazineNumberOfFieldsFile()
	{
		List<String> file = new ArrayList<>();
		List<Publication> aux = new ArrayList<>();
		PublicationParser pp = new PublicationParser();
		
		file.add("magazine	14	30	-7");
		
		assertEquals(aux, pp.parse(file));
	}
}
