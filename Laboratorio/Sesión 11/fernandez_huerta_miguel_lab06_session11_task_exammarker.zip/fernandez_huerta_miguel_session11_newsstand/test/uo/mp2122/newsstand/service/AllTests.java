package uo.mp2122.newsstand.service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses(
		{uo.mp2122.newsstand.service.newsstand.AllTests.class,
			uo.mp2122.newsstand.service.parsers.AllTests.class})
public class AllTests {

}
