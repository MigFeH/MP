package uo.mp.s11.marker.parser.questionParser;

import static org.junit.Assert.*;

import org.junit.Test;

public class ParseTests {

	/**
	 * 1- Linea null
	 * 2- 
	 */
}
