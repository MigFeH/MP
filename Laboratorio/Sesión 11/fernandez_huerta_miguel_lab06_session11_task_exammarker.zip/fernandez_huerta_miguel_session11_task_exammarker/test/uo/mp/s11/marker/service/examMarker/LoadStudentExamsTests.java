package uo.mp.s11.marker.service.examMarker;


import static org.junit.Assert.*;

import org.junit.Test;

public class LoadStudentExamsTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
