package uo.mp.s11.marker.comparators;

import java.util.Comparator;

import uo.mp.s11.marker.model.StudentMark;
import uo.mp.util.ArgumentsCheck;

public class MarksByStudentIdComparator implements Comparator<StudentMark> {

	@Override
	public int compare(StudentMark o1, StudentMark o2) {
		return toInteger(o1.getStudentId()) - toInteger(o2.getStudentId());
	}

	private int toInteger(String studentId) {
		ArgumentsCheck.isTrue(studentId != null && !studentId.isBlank());
		return Integer.parseInt(studentId);
	}

}
