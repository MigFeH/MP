package uo.mp.s11.marker.parser;

import java.util.ArrayList;
import java.util.List;

import uo.mp.s11.marker.exception.InvalidLineFormatException;
import uo.mp.s11.marker.model.question.ChoiceQuestion;
import uo.mp.s11.marker.model.question.GapQuestion;
import uo.mp.s11.marker.model.question.Question;
import uo.mp.s11.marker.model.question.ValueQuestion;
import uo.mp.s11.marker.util.log.Logger;
import uo.mp.util.ArgumentsCheck;

public class QuestionParser {
	
	private int lineNumber = 0;

	/**
	 * 
	 * @param lines
	 * @return
	 * @throws IllegalArgumentException if lines is null
	 */
	public List<Question> parse(List<String> lines) {
		ArgumentsCheck.isTrue(lines != null);
		
		List<Question> res = new ArrayList<>();
		for(String theLine : lines)
		{
			lineNumber++;
			try
			{
				res.add(parseLine(theLine));
			} catch(InvalidLineFormatException e)
			{
				Logger.log(e.getMessage());
			}
		}
		return res;
	}

	private Question parseLine(String theLine) throws InvalidLineFormatException {
		if(theLine.isBlank()) // l�nea vac�a...
		{
			throw new InvalidLineFormatException(lineNumber,"L�NEA VAC�A");
		}
		
		String parts[] = theLine.split("\t");
		String questionType = parts[0];
		double points = toDouble(parts[1]);
		
		if(questionType.equals("choice")) // pregunta de tipo choice...
		{
			return parseChoice(parts, points);
		}
		if(questionType.equals("gap")) // pregunta de tipo gap...
		{
			return parseGap(parts, points);
		}
		if(questionType.equals("value")) // pregunta de tipo value...
		{
			return parseValue(parts, points);
		}
		
		throw new InvalidLineFormatException(lineNumber,"TIPO DESCONOCIDO");
		 
	}

	private Question parseValue(String[] parts, double points) throws InvalidLineFormatException {
		checkParts(parts, 3);
		double rightAnswer = toDouble(parts[2]);
		return new ValueQuestion(lineNumber, points, rightAnswer);
	}

	private Question parseGap(String[] parts, double points) throws InvalidLineFormatException {
		checkParts(parts, 3);
		String rightAnswer = parts[2];
		return new GapQuestion(lineNumber, points, rightAnswer);
	}

	private Question parseChoice(String[] parts, double points) throws InvalidLineFormatException {
		checkParts(parts, 3);
		String rightAnswer = parts[2];
		return new ChoiceQuestion(lineNumber, points, rightAnswer);
	}
	
	private void checkParts(String[] parts, int i) throws InvalidLineFormatException {
		if(parts.length != i) // distinto n�mero de campos obligatorios...
		{
			throw new InvalidLineFormatException(lineNumber, "N�MERO DE CAMPOS NO V�LIDO");
		}
	}

	private double toDouble(String number) {
		return Double.parseDouble(number);
	}
	
}
