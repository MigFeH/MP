package uo.mp.s11.marker.model.question;

import uo.mp.util.ArgumentsCheck;

public abstract class Question {

	private int questionNumber;
	private Double weight;

	/**
	 * @param number
	 * @param weight
 	 * @throws IllegalArgumentException if question <= 0
	 * @throws IllegalArgumentException if weight <= 0
	 */
	public Question(int number, double weight) {
		ArgumentsCheck.isTrue(number > 0 && weight > 0.0, "Valores no v�lidos");
		
		this.questionNumber = number;
		this.weight = weight;
	}

	/**
	 * 
	 * @param answer
	 * @return
	 * @throws IllegalArgumentException
	 */
	public abstract double mark(String answer);

	public double getWeight() {
		return weight;
	}
	
	public int getNumber() {
		return this.questionNumber;
	}

	@Override
	public String toString() {
		return "Question [questionNumber=" + questionNumber + ", weight=" + weight + "]";
	}

	
}
