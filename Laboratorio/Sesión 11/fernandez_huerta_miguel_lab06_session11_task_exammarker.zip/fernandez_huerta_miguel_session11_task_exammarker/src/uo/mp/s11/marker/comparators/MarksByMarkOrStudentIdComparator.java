package uo.mp.s11.marker.comparators;

import java.util.Comparator;

import uo.mp.s11.marker.model.StudentMark;
import uo.mp.util.ArgumentsCheck;

public class MarksByMarkOrStudentIdComparator implements Comparator<StudentMark> {

	@Override
	public int compare(StudentMark o1, StudentMark o2) {
		int diff = Double.compare(o1.getMark(), o2.getMark());
		
		if(diff == 0.0) // si son iguales...
		{
			return Double.compare(toDouble(o1.getStudentId()), toDouble(o2.getStudentId()));
		} else
		{
			return diff;
		}
	}

	private double toDouble(String studentId) {
		ArgumentsCheck.isTrue(studentId != null && !studentId.isBlank());
		return Double.parseDouble(studentId);
	}

}
