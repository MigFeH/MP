package uo.mp.s3.socialNetwork.post;

import uo.mp.util.ArgumentsCheck;

public class Message extends Post{

	private String mg; // Mensajes de post
	
	
	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param el nombre del usuario
	 * @param el mensaje
	 */
	public Message(String userName, String mg)
	{
		super(userName);	
		setMessage(mg);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	private void setMessage(String mg) 
	{
		ArgumentsCheck.isTrue(mg != null, "Esperaba mensaje pero fue null");
		this.mg = mg;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en dicho atributo
	 */
	public String getMessages()
	{
		return mg;	
	}
	
	
	/**
	 * Retorna en un String los atributos del objeto en el formato:
	 * 
	 * Message User: Usuario1 msg: Mensaje1
	 * 
	 * @return el String con los atributos del objeto
	 */
	public String toString()
	{
		return ("Message User: " + getUserName() + " msg: " + getMessages());
	}
	
}
