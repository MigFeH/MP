package uo.mp.s3.socialNetwork.post;

public enum Fich {
	CAMPOS , MONTA�AS

}
