package uo.mp.s3.socialNetwork;

import uo.mp.s3.socialNetwork.app.*;

public class Main {
	
	public static void main(String args[])
	{
		new NetworkApplication().Run();
	}

}
