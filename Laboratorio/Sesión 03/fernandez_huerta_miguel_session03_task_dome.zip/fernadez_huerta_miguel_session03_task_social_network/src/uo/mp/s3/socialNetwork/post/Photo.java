package uo.mp.s3.socialNetwork.post;

import uo.mp.util.ArgumentsCheck;

public class Photo extends Post{
	
	private Fich ft; // Fotos de post
	
	private String title; // T�tulo de fotograf�a
	
	
	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param el nombre del usuario
	 * @param el la foto
	 * @param el t�tulo de la foto
	 */
	public Photo(String userName, Fich ft, String title)
	{
		super(userName);
		setPhoto(ft);
		setTitle(title);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	private void setPhoto(Fich ft) 
	{
		ArgumentsCheck.isTrue(ft != null, "Esperaba foto pero fue null");
		this.ft = ft;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	private void setTitle(String title) 
	{
		ArgumentsCheck.isTrue(title != null, "Esperaba t�tulo pero fue null");
		this.title = title;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en dicho atributo
	 */
	public Fich getPhoto()
	{
		return ft;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en dicho atributo
	 */
	public String getTitle()
	{
		return title;
	}
	
	
	/**
	 * Retorna en un String los atributos del objeto en el formato:
	 * 
	 * Photo user: Usuario1 File: foto1 Title: titulo1
	 * 
	 * @return el String con los atributos del objeto
	 */
	public String toString()
	{
		return ("Photo user: " + getUserName() + " File: " + 
				getPhoto() + " Title: " + getTitle());
	}
}
