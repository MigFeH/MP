package uo.mp.s3.socialNetwork.post.photo;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s3.socialNetwork.post.Fich;
import uo.mp.s3.socialNetwork.post.Photo;

public class ToStringTest {

	/**
	 * GIVEN: Par�metros v�lidos
	 * WHEN: Se llama al toString
	 * THEN: Se ejecuta el m�todo correctamente
	 */
	@Test
	public void testToStringWithCorrectParams()
	{
		Photo ft = new Photo("Paco",Fich.MONTA�AS,"T�tulo");
		
		assertEquals("Photo user: Paco File: MONTA�AS Title: T�tulo",
				ft.toString());
	}

}
