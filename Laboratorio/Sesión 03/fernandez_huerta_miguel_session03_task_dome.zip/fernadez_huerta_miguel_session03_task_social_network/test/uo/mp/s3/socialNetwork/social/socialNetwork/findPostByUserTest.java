package uo.mp.s3.socialNetwork.social.socialNetwork;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s3.socialNetwork.post.Post;
import uo.mp.s3.socialNetwork.social.SocialNetwork;

public class findPostByUserTest {

	/**
	 * GIVEN: Par�metro v�lido
	 * WHEN: Se llama al m�todo findPostByUser
	 * THEN: Devuelve la lista con los posts
	 */
	@Test
	public void testFindPostByUserWithCorrectParam()
	{
		SocialNetwork sm = new SocialNetwork();
		sm.addPost(new Post("Pablo"));
		assertNotNull(sm.findPostsByUser("Pablo"));
	}
	
	
	/**
	 * GIVEN: Par�metro null
	 * WHEN: Se llama al m�todo findPostByUser
	 * THEN: Lanza excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testFindPostByUserWithNullParam()
	{
		SocialNetwork sm = new SocialNetwork();
		sm.addPost(new Post("Pablo"));
		sm.findPostsByUser(null);
	}

}
