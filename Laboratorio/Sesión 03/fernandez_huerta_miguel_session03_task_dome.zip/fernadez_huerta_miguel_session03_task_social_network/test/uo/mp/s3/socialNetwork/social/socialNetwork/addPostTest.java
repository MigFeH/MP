package uo.mp.s3.socialNetwork.social.socialNetwork;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s3.socialNetwork.post.Post;
import uo.mp.s3.socialNetwork.social.SocialNetwork;

public class addPostTest {

	/**
	 * GIVEN: Par�metro null
	 * WHEN: Se llama al m�todo addPost
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testAddPostWithNullParam()
	{
		new SocialNetwork().addPost(null);
	}
	
	
	/**
	 * GIVEN: Par�metro v�lido
	 * WHEN: Se llama al m�todo addPost
	 * THEN: Se a�ade el post correctamente
	 */
	@Test
	public void testAddPostWithCorrectParam()
	{
		SocialNetwork sn = new SocialNetwork();
		sn.addPost(new Post("Pablo"));
		
		assertNotNull(sn.getPosts().get(0));	
	}
}
