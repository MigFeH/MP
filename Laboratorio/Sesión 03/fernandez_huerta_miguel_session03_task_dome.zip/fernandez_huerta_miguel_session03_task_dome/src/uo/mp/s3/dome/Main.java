package uo.mp.s3.dome;

import uo.mp.s3.dome.ui.MediaPlayer;

public class Main {

	public static void main(String[] args) {
		new MediaPlayer().run();
	}

}
