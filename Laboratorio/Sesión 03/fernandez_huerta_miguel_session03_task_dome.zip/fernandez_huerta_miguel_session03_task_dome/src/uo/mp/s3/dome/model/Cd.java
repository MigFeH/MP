package uo.mp.s3.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public class Cd extends Item  {

	private String artist;
	private int numberOfTracks;
	
	public Cd(String theTitle, String theArtist, int tracks, int time) {
		super(theTitle,time);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
	}

	private void setArtist(String artist) {
		ArgumentsCheck.isTrue(artist != null);
		this.artist = artist;
	}

	private void setNumberOfTracks(int numberOfTracks) {
		ArgumentsCheck.isTrue(numberOfTracks > 0);
		this.numberOfTracks = numberOfTracks;
	}

	public String getArtist() {
		return this.artist;
	}
	
	public int getNumberOfTracks() {
		return this.numberOfTracks;
	}
	
	public void print(PrintStream out) {
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
	}
}