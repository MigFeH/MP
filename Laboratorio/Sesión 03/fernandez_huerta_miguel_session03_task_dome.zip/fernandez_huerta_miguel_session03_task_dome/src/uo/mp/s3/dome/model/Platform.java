package uo.mp.s3.dome.model;

public enum Platform 
{
	// Tipo enumerado que representa las plataformas de juego
	XBOX, PLAYSTATION, NINTENDO
}
