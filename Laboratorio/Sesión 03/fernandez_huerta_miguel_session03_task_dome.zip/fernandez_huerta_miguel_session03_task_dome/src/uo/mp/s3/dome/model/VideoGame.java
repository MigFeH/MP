package uo.mp.s3.dome.model;

import uo.mp.util.ArgumentsCheck;

public class VideoGame extends Item{
	
	private String author; // El autor
	private int players; // El número de jugadores
	private Platform platform; // La plataforma de juego
	
	
	/**
	 * Constructor con parámetros de la clase VideoGame
	 * 
	 * @param title, el título
	 * @param author, el autor
	 * @param players, el número de jugadores
	 * @param form, la plataforma de juego
	 */
	public VideoGame(String title, String author, int players, Platform form)
	{
		setTitle(title);
		setAuthor(author);
		setPlayers(players);
		setPlatform(form);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo author
	 * 
	 * @param el autor del juego
	 */
	private void setAuthor(String author)
	{
		ArgumentsCheck.isTrue(author != null);
		this.author = author;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo platform
	 * 
	 * @param la plataforma de juego
	 */
	private void setPlatform(Platform form) 
	{
		ArgumentsCheck.isTrue(form != null);
		this.platform = form;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo players
	 * 
	 * @param el número de jugadores
	 */
	private void setPlayers(int players) 
	{
		ArgumentsCheck.isTrue(players >= 0);
		this.players = players;
	}
	
	
	/**
	 * Retorna el valor almacenado en author
	 * 
	 * @return el valor
	 */
	public String getAuthor() 
	{
		return author;
	}
	
	
	/**
	 * Retorna el valor almacenado en platform
	 * 
	 * @return el valor
	 */
	public Platform getPlatform() 
	{
		return platform;
	}
	
	
	/**
	 * Retorna el valor almacenado en players
	 * 
	 * @return el valor
	 */
	public int getPlayers() 
	{
		return players;
	}
}
