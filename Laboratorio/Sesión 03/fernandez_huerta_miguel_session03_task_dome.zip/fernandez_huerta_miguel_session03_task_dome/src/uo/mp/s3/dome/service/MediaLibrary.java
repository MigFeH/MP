package uo.mp.s3.dome.service;

import java.io.PrintStream;
import java.util.ArrayList;

import uo.mp.s3.dome.model.Cd;
import uo.mp.s3.dome.model.Dvd;
import uo.mp.s3.dome.model.Item;
import uo.mp.s3.dome.model.Platform;
import uo.mp.s3.dome.model.VideoGame;
import uo.mp.util.ArgumentsCheck;

public class MediaLibrary {
	
	private ArrayList<Item> items = new ArrayList<Item>();
	
	
	/**
	 * A�ade un item a la lista no nulo
	 * 
	 * @param item a a�adir
	 */
	public void add(Item theItem)
	{
		ArgumentsCheck.isTrue(theItem != null);
		items.add(theItem);
	}
	
	/**
	 * Retorna el n�mero de items con propietario
	 * 
	 * @return n�mero de items con propietario
	 */
	public int getNumberOfItemsOwned()
	{
		int numberOfItems = 0;
		for(Item theItem: items)
		{
			if(theItem.getOwn())
			{
				numberOfItems++;
			}
		}
		return numberOfItems;
	}
	
	/**
	 * Retorna una copia de la lista de items
	 * 
	 * @return la lista copia de items
	 */
	public ArrayList<Item> getItems()
	{
		ArrayList<Item> copy = new ArrayList<Item>();
		for (Item theItem: items)
		{
			copy.add(theItem);
		}
		return copy;
	}
	
	
	/**
	 * Busca en la lista un item recibido como par�metro (solo igualdad de 
	 * identidad no de contenido o estado) y devuelva la posici�n que ocupa, 
	 * si lo encuentra, o bien -1 si no lo ha encontrado
	 * 
	 * @param el item a devolver su posici�n en la lista
	 * @return la posici�n que ocupa el item recibido como par�metro, o -1
	 * si dicho item par�metro no se encuentra en la lista par�metro
	 */
	public int searchItem(Item theItem)
	{
		ArgumentsCheck.isTrue(theItem != null);
		
		for(Item item: items)
		{
			if (theItem.equals(item))
			{
				return this.items.indexOf(item);
			}
		}
		return -1;
	}
	
	
	/** Retorna un String (posiblemente vac�o si no hay datos) que contiene la 
	 * persona responsable para cada �tem, separados por comas. 
	 * En el caso de los CDs, el responsable es el artista. 
	 * En el caso de los DVDs el responsable es el director
	 * 
	 * @return el String con el responsable de cada item
	 */
	public String getResponsable()
	{
		if (items.get(0) == null)
		{
			return "";
		} else
		{
			String data = "";
			for (Item theItem: items)
			{
				if (theItem == new Cd(
						"Panes y flautas", "Mi amigo", 5, 2))
				{
					data = data + ((Cd) theItem).getArtist();
				}
				if (theItem == new Dvd(
						"Thor", "Marvel", 10))
				{
					data = data + ((Dvd) theItem).getDirector();
				}
				if (theItem == new VideoGame(
						"God of War", "Santa M�nica Studios", 1, Platform.PLAYSTATION))
				{
					data = data + ((VideoGame) theItem).getAuthor();
				}
			}
			return data;
		}
	}
	
	
	/**
	 * Imprime todos los items
	 */
	public void list(PrintStream out)
	{
		for(Item theItem: items)
		{
			theItem.print(out);
		}
	}
}
