package uo.mp.s3.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public class Item {

	private String title;
	private int playingTime;
	private boolean gotIt;
	private String comment;

	public Item() 
	{
		super();
	}
	
	public Item(String theTitle, int time)
	{
			setTitle(theTitle);
			setPlayingTime(time);
			setOwn(false);
			setComment("No comment");
	}

	protected void setTitle(String title) {
		ArgumentsCheck.isTrue(title != null);
			this.title = title;
	}

	protected void setPlayingTime(int playingTime) {
		ArgumentsCheck.isTrue(playingTime > 0);
			this.playingTime = playingTime;
	}

	public void setOwn(boolean ownIt) {
		gotIt = ownIt;
	}

	public void setComment(String comment) {
		if (comment != null) {
			this.comment = comment;
		}
	}

	public String getComment() {
		return comment;
	}

	public boolean getOwn() {
		return gotIt;
	}

	public String getTitle() {
		return this.title;
	}

	public int getPlayingTime() {
		return this.playingTime;
	}
	
	public void print(PrintStream out)
	{
		
	}

}