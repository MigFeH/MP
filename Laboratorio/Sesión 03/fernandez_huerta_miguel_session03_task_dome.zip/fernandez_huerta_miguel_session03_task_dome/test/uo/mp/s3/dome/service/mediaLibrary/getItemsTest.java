package uo.mp.s3.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import uo.mp.s3.dome.model.Item;
import uo.mp.s3.dome.service.MediaLibrary;

public class getItemsTest {

	/**
	 * GIVEN: 
	 * WHEN: Se llama al m�todo getItems
	 * THEN: Retorna una copia de una lista de items
	 */
	@Test
	public void testGetItems()
	{
		MediaLibrary md = new MediaLibrary();
		ArrayList<Item> copy = new ArrayList<Item>();
		Item it = new Item();

		for(int i = 0; i < 2; i++)
		{
			md.add(it);
			copy.add(it);
		}

		assertEquals(copy,md.getItems());
	}

}
