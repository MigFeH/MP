package uo.mp.s3.dome.model.cd;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s3.dome.model.Cd;
import uo.mp.s3.dome.model.Item;


public class SetCommentTest {
	private Item aCD;
	private String theTitle;
	private String theArtist;
	private int theTime;
	private int theTracks;
	
	
	@Before
	public void setUp() {
		theTitle = "Come Together";
		theArtist = "Beatles";
		theTime = 70;
		theTracks = 4;
		aCD = new Cd(theTitle, theArtist, theTracks, theTime);
	}

	/**
	 * GIVEN: 	cd con comentario vac�o
	 * WHEN: 	invoca setComment con cadena no vac�a como comentario
	 * THEN:	se cambia el comentario a la cadena
	 */
	
	@Test
	public void testSetComment() {
		aCD.setComment("Excellent");

		assertEquals("Excellent", aCD.getComment());
	}
	
	/**
	 * GIVEN: 	cd con comentario no vac�o
	 * WHEN: 	invoca setComment con null
	 * THEN:	permanece el comentario que hab�a
	 */
	@Test
	public void testSetInvalidComment() {
		aCD.setComment("Excellent");
		aCD.setComment(null);

		assertEquals("Excellent", aCD.getComment());
	}
}
