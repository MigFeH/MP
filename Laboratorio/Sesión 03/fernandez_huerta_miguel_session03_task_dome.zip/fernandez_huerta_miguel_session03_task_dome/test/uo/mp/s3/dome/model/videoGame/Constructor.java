package uo.mp.s3.dome.model.videoGame;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s3.dome.model.Platform;
import uo.mp.s3.dome.model.VideoGame;

public class Constructor {
	
	private String theTitle;
	private String theAuthor;
	private int thePlayers;
	private Platform thePlatform;
	
	@Before
	public void setUp()
	{
		theTitle = "Call of Duty";
		theAuthor = "Activision";
		thePlayers = 200;
		thePlatform = Platform.XBOX;
	}
	
	
	/**
	 * GIVEN: Par�metro t�tulo null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullTitle()
	{
		new VideoGame(null, theAuthor, thePlayers, thePlatform);
	}
	
	
	/**
	 * GIVEN: Par�metro autor null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullAuthor()
	{
		new VideoGame(theTitle, null, thePlayers, thePlatform);
	}
	
	
	/**
	 * GIVEN: Par�metro players no v�lido
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithIncorrectPlayersParam()
	{
		new VideoGame(theTitle, theAuthor, -1, thePlatform);
	}
	
	
	/**
	 * GIVEN: Par�metro platform null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullPlatform()
	{
		new VideoGame(theTitle, theAuthor, thePlayers, null);
	}
	
	
	/**
	 * GIVEN: Par�metros correctos
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Se crea el objeto correctamente
	 */
	@Test
	public void testConstructorWithCorrectParams()
	{
		VideoGame vd = new VideoGame(
				theTitle, theAuthor, thePlayers, thePlatform);
		assertNotNull(vd);
	}
}
