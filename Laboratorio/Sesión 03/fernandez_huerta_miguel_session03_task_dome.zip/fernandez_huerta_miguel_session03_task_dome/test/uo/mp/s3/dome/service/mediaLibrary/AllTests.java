package uo.mp.s3.dome.service.mediaLibrary;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ addTest.class,
	getItemsTest.class,
	getNumberOfItemsOwnedTest.class,
	searchItemTest.class})
public class AllTests {

}
