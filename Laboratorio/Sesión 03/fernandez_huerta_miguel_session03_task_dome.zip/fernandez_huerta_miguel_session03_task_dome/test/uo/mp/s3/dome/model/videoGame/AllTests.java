package uo.mp.s3.dome.model.videoGame;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Constructor.class })
public class AllTests {

}
