package uo.mp.s2.analyzer.wordanalyzer;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s2.analyzer.model.WordAnalyzer;



public class FirstMultipleCharacterTest {

	
	@Test
	public void testNoMultipleCharacter() {			
		WordAnalyzer abcdefg = new WordAnalyzer("abcdef");
		assertEquals('\0',abcdefg.firstMultipleCharacter());
	}
		
	
	@Test
	public void testConsecutiveMultipleCharacterAtBeginnig() {			 
		WordAnalyzer aaabcddddcbc = new WordAnalyzer("aaabcddddcbc");
		assertEquals('a',aaabcddddcbc.firstMultipleCharacter());
	}
	
	@Test
	public void testConsecutiveMultipleCharacterAtMidle() {
		WordAnalyzer abcccdddef = new WordAnalyzer("abcccdddef");
		assertEquals('c',abcccdddef.firstMultipleCharacter());
	}
	
	
	@Test
	public void testConsecutiveMultipleCharacterAtEnd() {			
		WordAnalyzer abcdefff = new WordAnalyzer("abcdefff");
		assertEquals('f',abcdefff.firstMultipleCharacter());
    }
	
	@Test
	public void testNoConsecutiveMultipleCharacter() {			
		WordAnalyzer abcdefff = new WordAnalyzer("abcadefff");
		assertEquals('a',abcdefff.firstMultipleCharacter());
    }
	
}
