package uo.mp.s2.analyzer.wordanalyzer;





import static org.junit.Assert.*;


import org.junit.Test;

import uo.mp.s2.analyzer.model.WordAnalyzer;






public class WordAnalyzerTest {

	

	/*
	 * Casos
	 * 1- Palabra cualquiera. Se crea el analizador
	 * 2- null como par�metro.Salta excepci�n
	 * 3- palabra vac�a. Salta excepci�n
	 * 4- palabra con m�ltiples espacios en blanco. Salta excepci�n
	 * 
	 */
	
	/**
	 * GIVEN una palabra cualquiera
	 * WHEN creamos un analizador para esa palabra
	 * THEN se crea el analizador con dicha palabra
	 */
	@Test
	public void someCharactersWord() {
		WordAnalyzer wordAnalyzer = new WordAnalyzer("axbdr");
		assertNotNull(wordAnalyzer);
		assertEquals("axbdr", wordAnalyzer.toString());
	}

	/**
	 * GIVEN 
	 * WHEN creamos analizador que recibe null
	 * THEN salta excepci�n IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNullWord() {
		new WordAnalyzer(null);
//		try {
//			new WordAnalyzer(null);
//			fail("Se deber�a haber lanzado una excepci�n");
//		}catch(IllegalArgumentException iae) {
//			assertTrue(true);
//		}		
	}
	
	@Test
	public void testEmptyWord() {
	
		try {
			new WordAnalyzer("");
			fail("Se deber�a haber lanzado una excepci�n");
		}catch(IllegalArgumentException iae) {
			assertTrue(true);
		}		
	}
	
	@Test
	public void testBlankWord() {
	
		try {
			new WordAnalyzer("    ");
			fail("Se deber�a haber lanzado una excepci�n");
		}catch(IllegalArgumentException iae) {
			assertTrue(true);
		}		
	}
	
}
