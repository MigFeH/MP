package uo.mp.s2.analyzer.wordanalyzer;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s2.analyzer.model.WordAnalyzer;



public class FirstRepeatedCharacterTest {

	/*
	 * Casos de uso
	 * 
	 * 1- Caracteres repetidos consecutivos al principio
	 * 2- Caracteres repetidos consecutivos en el medio
	 * 3- Caracteres repetidos consecutivos al final
	 * 4- Varios grupos de caracteres repetidos consecutivos
	 * 5- Caracteres repetidos no consecutivos
	 * 6- Sin caracteres repetidos
	 * 
	 */
	
	/**
	 * GIVEN analizador de palabra con caracteres consecutivos al principio
	 * WHEN se llama al m�todo firstRepatedCharacter
	 * THEN	devuelve el primer caracter de la palabra
	 */
	
	@Test
	public void testRepeatedConsecutiveCharacterAtBeginning() {		 
		WordAnalyzer aabc = new WordAnalyzer("aabc");
		assertEquals('a',aabc.firstRepeatedCharacter());
	
	}
	
	@Test
	public void testRepeatedConsecutiveCharacterInMiddle() {
		WordAnalyzer abccde = new WordAnalyzer("abccde");
		assertEquals('c',abccde.firstRepeatedCharacter());		
	}
	
	@Test
	public void testRepeatedConsecutiveCharacterAtEnd() {
		 
		WordAnalyzer abcdd = new WordAnalyzer("abcdd");
		assertEquals('d',abcdd.firstRepeatedCharacter());		
	}
	
	@Test
	public void testMultipleGroupsOfRepeatedCharacter() {
		 
		WordAnalyzer abbbcdd = new WordAnalyzer("abbcdd");
		assertEquals('b',abbbcdd.firstRepeatedCharacter());		
	}
	
	@Test
	public void testRepeatedCharacterNotConsecutive() {		
		WordAnalyzer abcbcbcad = new WordAnalyzer("abcbcbcad");
		assertEquals(0,abcbcbcad.firstRepeatedCharacter());
	}
	
	
		
	@Test
	public void testNoRepeatedCharacter() {
		WordAnalyzer abcdef = new WordAnalyzer("abcdef");
		assertEquals(0,abcdef.firstRepeatedCharacter());
	}	
	
	

}

