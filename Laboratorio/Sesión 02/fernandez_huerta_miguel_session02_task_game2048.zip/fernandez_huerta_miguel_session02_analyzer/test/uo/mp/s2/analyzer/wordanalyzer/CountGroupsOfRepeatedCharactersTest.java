package uo.mp.s2.analyzer.wordanalyzer;


import static org.junit.Assert.assertEquals;


import org.junit.Test;

import uo.mp.s2.analyzer.model.WordAnalyzer;



public class CountGroupsOfRepeatedCharactersTest {

	
	
	@Test
	public void testNoneGroupRepeatedCharacter() {
		WordAnalyzer noneRepeated = new WordAnalyzer("abcde");	
		assertEquals(0,noneRepeated.countGroupsOfRepeatedCharacters());
	}
	
	
	@Test
	public void testGroupsAtBeginingMidleAndEnd() {
		WordAnalyzer repeated = new WordAnalyzer("aaabccdeeee");	
		assertEquals(3,repeated.countGroupsOfRepeatedCharacters());		
	}
	
	

}
