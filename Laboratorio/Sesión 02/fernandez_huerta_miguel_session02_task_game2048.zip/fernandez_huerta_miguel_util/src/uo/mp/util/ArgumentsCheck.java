package uo.mp.util;

public class ArgumentsCheck {
	
	/**
	 * Si no cumple la condici�n recibida, salta excepci�n 
	 * IllegalArgumentException con el mensaje recibido
	 * @param condition
	 * @param msg
	 */
	public static void isTrue(boolean condition, String msg)
	{
		if(!condition)
		{
			throw new IllegalArgumentException(msg);
		}
	}
	
	/**
	 * Si no cumple la condici�n recibida, salta excepci�n 
	 * IllegalArgumentException con el mensaje recibido
	 * @param condition
	 */
	public static void isTrue(boolean condition)
	{
		if(!condition)
		{
			throw new IllegalArgumentException();
		}
	}
}
