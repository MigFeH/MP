package uo.mp.s2.game.model;

import java.util.Random;

import uo.mp.util.ArgumentsCheck;

/**
 * <p>
 * T�tulo: Clase Game2048
 * </p>
 * <p>
 * Descripci�n: A partir de un array bidimensional de n�meros y a trav�s de
 * diferentes operaciones se simula un juego llamado "2048"
 * </p>
 * <p>
 * Copyright: Copyright (c) 2022
 * </p>
 * <p>
 * Empresa: Escuela de Ingenier�a Inform�tica - Universidad de Oviedo
 * </p>
 * 
 * @author Miguel
 * @version 1/2/2022
 */
public class Game2048 {
	public static final int MIN_ROWS = 3; // N�mero m�nimo de filas del tablero
	public static final int MIN_COLUMNS = 3; // N�mero m�nimo de columnas del 
											 // tablero
	
	public static final int MAX_ROWS = 10; // N�mero m�ximo de filas del tablero
	public static final int MAX_COLUMNS = 10; // N�mero m�ximo de columnas del 
											  // tablero
	
	private int[][] board; // Tablero de juego

	/**
	 * Constructor sin par�metros con tablero por defecto de 3*3 Inicialmente 
	 * todas las posiciones con valor 0
	 */
	public Game2048() {
		// Tablero creado con las dimensiones m�nimas posibles
		this.board = new int[MIN_ROWS][MIN_COLUMNS];	
	}

	/**
	 *Constructor que recibe el tama�o del tablero
	 *
	 *@param size, el tama�o del tablero con longitudes limitadas entre [1,10]
	 */
	public Game2048(int size) {
		if (size <= 0 || size > MAX_ROWS) /* Si el tama�o pasado por par�metro 
		es menor o igual que 0, o mayor que 10... */
		{
			// Crea el tablero con las dimensiones m�nimas posibles
			this.board = new int[MIN_ROWS][MIN_COLUMNS]; 
		} else { // En caso contrario...
			// Crea el tablero con las dimensiones pasadas por par�metro
			this.board = new int[size][size]; 
		}
	}
	
	/**
	 * Inicializa el tablero con la matriz pasada como par�metro
	 * 
	 * @param board, la matriz tablero
	 */
	public Game2048(int[][] board) {
		// COMPROBACIONES:
		
		// Comprobaci�n de si el par�metro es null; 
		/* Comprobaci�n de si el tablero par�metro tiene dimensiones dentro del
		rango permitido */ 
		ArgumentsCheck.isTrue(board != null && board.length > 0 
				&& board.length <= MAX_ROWS, "Tablero inadecuado o null"); 
		
		
		// Comprobaci�n de que todas las columnas son de igual tama�o
		
		int t = 0; /* Variable local que guardar� el tama�o 
		m�ximo de columnas del tablero par�metro. A partir del valor de t se 
		comprobar� que el resto de columnas tienen el mismo tama�o */
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i].length >= t) // Si el tama�o de una columna es 
										// superior a t...
				{
					t = board[i].length; // t guardar� el tama�o de la columna
				}
			}
		}
		
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			ArgumentsCheck.isTrue(board[i].length == t, 
						"Tablero inadecuado o null"); 
		}
		
		
		// Comprobaci�n de que la matriz es cuadrada
		ArgumentsCheck.isTrue(board.length == board[0].length, 
				"Tablero inadecuado o null");
		
		
		 // Crea e inicializa un tablero con las dimensiones y valores de la 
		// matriz par�metro
		this.board = board;
	}


	/**
	 * Devuelve una copia de la matriz para poder usarla en las pruebas
	 * 
	 * @return board, el tablero
	 */
	public int[][] getBoard() {
		int[][] copyBoard = new int[board.length][board[0].length];
		
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				copyBoard[i][j] = board[i][j];
			}
		}
		return copyBoard;
		//return board.clone();
	}
	
	
	/**
	 * Reinicia todas las posiciones a 0 y llama a next para que incluya un
	 * 2 en una posici�n aleatoria
	 */
	public void restart() {
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				board[i][j] = 0; // Guarda en cada posici�n del tablero un 0
			}
		}
		// Llamada al m�todo next para completar la funci�n del m�todo
		this.next();
	}
	
	
	/**
	 * A�ade un nuevo  2 en una posici�n aleatoria vac�a
	 * siempre que exista alguna
	 */
	public void next() {
		// Creaci�n de un objeto random de la clase Random
		Random random = new Random(); 
		
		 /* Variable local que guarda el resultado de la ejecuci�n del m�todo 
		 isBoardFull() */
		boolean t = this.isBoardFull();
		
		if (t == false) // Si t es false...
		{

			for (int i = 0; i < board.length; i++) // Recorrido por filas
			{
				/* Creaci�n de una variable local que tomar� valores aleatorios 
				correspondientes a cada fila del tablero */
				int a = random.nextInt(board.length);
				/* Creaci�n de una variable local que tomar� valores aleatorios 
				correspondientes a cada columna del tablero */
				int b = random.nextInt(board[0].length); 
					
				if (board[a][b] == 0) /* Si el elemento en la fila a y columna b 
				es 0... */
				{
					board[a][b] = 2; // Que se guarde en esa posici�n un 2
					break; // Que rompa el bucle
				}
			}
		}
	}
	
	
	/**
	 * Comprueba si el tablero est� lleno. Esto ocurre cuando todas las celdas
	 * o posiciones del tablero tienen un n�mero distinto de cero
	 * 
	 * @return true (si el tablero est� lleno) o false (en caso contrario)
	 */
	public boolean isBoardFull() {
		boolean p = true; /* Creaci�n de una variable local inicializada a true;
		 �sta variable ser� la que guarde el resultado de si el tablero est� 
		 lleno o no */
		for(int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for(int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i][j] != 0) // Si en la posici�n i,j no hay un 0...
				{
					p = true; 
				} else // En caso contrario...
				{
					return false;
				}
			}
		}
		return p;
	}
	
	
	/**
	 * Compacta el board a la izquierda, dejando en cada fila todos los valores
	 * positivos consecutivos en las primeras posiciones y todos los ceros en 
	 * las �ltimas posiciones de la fila
	 */
	public void moveLeft()
	{
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i][j] != 0 && j > 0) /* Si el elemento i,j no es 0 y
				el valor de j es superior a 0... */
				{	
					int coord = 0; // Variable local coord que guarda el valor 0
					while (board[i][coord] != 0 && coord < j && 
							board[i][coord] != board[i][j]) 
					/* Mientras el elemento i,coord no es 0, el valor coord es inferior al 
					* de j, y el valor de i,coord es distinto del de i,j... */
					{
						coord = coord + 1; /* Aumentar en una unidad el valor de coord */
					}
					if (board[i][coord] == board[i][j] && coord != j) /* Si el elemento
					i,coord es igual que el de i,j; y el valor de coord no es igual que el 
					de j... */
					{
						board[i][coord] = board[i][coord] * 2; /* Es lo mismo que 
						board[i][coord] + board[i][coord] */
						board[i][j] = 0; // Se guarda en i,j el elemento 0
					} else {
						int m = board[i][j]; // Guarda el elemento de la posici�n i,j
						board[i][j] = 0; // Se asigna a la posici�n i,j el valor 0
						board[i][coord] = m; // En i,coord se guarda el valor de m
					}
				}
			}
		}
	}

	
	
	/**
	 * Compacta el board a la derecha, dejando en cada fila todos los valores
	 * positivos consecutivos en las �ltimas posiciones de la fila y todos los 
	 * ceros en las primeras posiciones de la fila
	 */
	public void moveRight()
	{
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = MIN_COLUMNS - 1; j >= 0; j--) // Recorrido por columnas
			{
				if (board[i][j] != 0 && j < MIN_COLUMNS - 1) /* Si el elemento 
				i,j no es 0 y el valor de j es inferior al n�mero m�nimo de 
				columnas posibles menos una unidad... */
				{
					int coord = board.length - 1; /* Variable local coord que guarda el valor
					del n�mero m�nimo de columnas posibles menos una unidad */
					while (board[i][coord] != 0 && coord > j && 
							board[i][coord] != board[i][j])
					/* Mientras el elemento i,coord no es 0, el valor coord es superior al 
					 * de j, y el valor de i,coord es distinto del de i,j... */
					{
						coord = coord - 1; /* Disminuir en una unidad el valor de coord */
					}
					if (board[i][coord] == board[i][j] && coord != j) /* Si el elemento
						i,coord es igual que el de i,j; y el valor de coord no es igual que 
						el de j... */
					{
						board[i][coord] = board[i][coord] * 2;  /* Es lo mismo que 
						board[i][coord] + board[i][coord] */
						board[i][j] = 0; // Se guarda en i,j el elemento 0
					} else {
						int m = board[i][j]; // Guarda el elemento de la posici�n i,j
						board[i][j] = 0; // Se asigna a la posici�n i,j el valor 0
						board[i][coord] = m; // En i,coord se guarda el valor de m
					}
				}
			}
		}
	}
	
	
	/**
	 * Compacta el board hacia arriba, dejando en cada columna todos los valores
	 * positivos consecutivos en las primeras posiciones y todos los ceros en 
	 * las �ltimas posiciones
	 */
	public void moveUp()
	{
		for (int j = 0; j < board.length; j++) // Recorrido por filas
		{
			for (int i = 0; i < board[j].length; i++) // Recorrido por columnas
			{
				if (board[i][j] != 0 && i > 0) /* Si el elemento 
					i,j no es 0 y el valor de i es superior a 0... */ 
				{
					int coord = 0; // Variable local coord que guarda el valor 0
					while (board[coord][j] != 0 && coord < i && 
							board[coord][j] != board[i][j])
					/* Mientras el elemento coord,j no es 0, el valor coord es inferior al 
					de i, y el valor de coord,j es distinto del de i,j... */
					{
						coord = coord + 1; /* Aumentar en una unidad el valor de coord */
					}
					if (board[coord][j] == board[i][j] && coord != i) /* Si el elemento
						coord,j es igual que el de i,j; y el valor de coord no es igual que 
						el de i... */
					{
						board[coord][j] = board[coord][j] * 2; /* Es lo mismo que 
						board[coord][j] + board[coord][j] */
						board[i][j] = 0; // Se guarda en i,j el elemento 0
					} else {
						int m = board[i][j]; // Guarda el elemento de la posici�n i,j
						board[i][j] = 0; // Se asigna a la posici�n i,j el valor 0
						board[coord][j] = m; // En coord,j se guarda el valor de m
					}
				}
			}
		}
	}
	
	
	/**
	 * Compacta el board hacia abajo, dejando en cada columna todos los valores
	 * positivos consecutivos en las �ltimas posiciones y todos los ceros en las
	 * primeras posiciones
	 */
	public void moveDown()
	{
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i][j] != 0 && i < MIN_COLUMNS - 1) /* Si el elemento 
					i,j no es 0 y el valor de i es inferior al n�mero m�nimo de
					columnas posibles menos una unidad... */ 
				{
					int coord = board.length - 1; /* Variable local coord que guarda el 
					valor de la longitud de board (n�mero de filas) menos una unidad */
					while (board[coord][j] != 0 && coord > i && 
							board[coord][j] != board[i][j]) /* Mientras el elemento coord,j 
					no es 0, el valor coord es superior al de i, y el valor de coord,j es 
					distinto del de i,j... */
					{
						coord = coord - 1; /* Disminuir en una unidad el valor de coord */
						}
					if (board[coord][j] == board[i][j] && coord != i) /* Si el elemento
						coord,j es igual que el de i,j; y el valor de coord no es igual que 
						el de i... */
					{
						board[coord][j] = board[coord][j] * 2; /* Es lo mismo que 
						board[coord][j] + board[coord][j] */
						board[i][j] = 0; // Se guarda en i,j el elemento 0
					}else {
						int m = board[i][j]; // Guarda el elemento de la posici�n i,j
						board[i][j] = 0; // Se asigna a la posici�n i,j el valor 0
						board[coord][j] = m; // En coord,j se guarda el valor de m
					}
				}
			}
		}
	}
	
	
	/**
	 * Devuelve un String con los datos de la matriz en formato para ser 
	 * mostrado por pantalla
	 * Con un blanco entre dos elementos consecutivos de la fila
	 * Ejemplo:
	 *    2 2 0
	 *    2 0 0
	 *    2 0 2
	 *    
	 *	@return el toString con los datos de la matriz en el formato deseado
	 */
	public String toString()
	{
		String data1 = "";
		for (int i = 0; i < board.length; i++)
		{
			for (int j = 0; j < board[i].length; j++)
			{
				data1 = data1 + board[i][j] + " ";
			}
			data1 = data1 + "\n";
		}
		return "\n" + data1;
	}
	
	
//	/**
//	 * Eval�a un par�metro matriz cuadrada recibida por par�metro
//	 * Saltar� una excepci�n IllegalArgumentException si la matriz par�metro:
//	 * 1-Es null
//	 * 2-Tiene un n�mero de filas negativo
//	 * 3-Tiene un n�mero de columnas negativo
//	 * 4-No es cuadrada
//	 * 
//	 * @param la matriz a evaluar
//	 */
//	private void matrixEvaluation(int[][] matrix)
//	{
//		/* Control de par�metro distinto de null, y de que tenga n�mero de filas 
//		 * y de columnas mayor que cero */
//		ArgumentsCheck.isTrue(matrix != null && matrix.length > 0 &&
//				matrix[0].length > 0, "Matriz par�metro no v�lida");
//		
//		/* Control de par�metro matriz de que sea una matriz cuadrada */
//		for (int i = 0; i < matrix.length; i++) // Recorrido por filas
//		{
//			for (int j = 0; j < matrix[i].length; j++) // Recorrido por columnas
//			{
//				ArgumentsCheck.isTrue(matrix.length == matrix[i].length, 
//						"Matriz par�metro no v�lida");
//			}
//		}
//	}
	
	
}
