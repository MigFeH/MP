package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.assertArrayEquals;


import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class MoveLeftTest {

	/*
	 * Casos de uso:
	 * 1- Matriz con un valor por fila en columna 0
	 * 2- Matriz con un valor por fila en columna 1
	 * 3- Matriz con un valor por fila en columna 2
	 * 
	 * 4- Matriz con 2 valores por fila (en 1 y 2)
	 * 5- Matriz con 2 valores por fila (en 0 y 1)
	 * 6- Matriz con 2 valores por fila (en 1 y 3)
	 * 
	 * 7- Matriz con 3 valores por fila 
	 * 8- Matriz 4x4 con 2 valores por fila (en 0 y 1)
	 */
	
	/**
	 * GIVEN compactador a la izquierda con un valor por fila en columna 0
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testOneValueForRowInColumn0() {
		//		public static int[][] SEMIFULL12 = {{2,0,0},
		//                							{2,0,0},
		//                							{2,0,0}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL12);
		game.moveLeft();
		assertArrayEquals(CodeForTest.SEMIFULL1_LEFTCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con un valor por fila en columna 1
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testOneValueForRowInColumn1() {
		//		public static int[][] SEMIFULL11 = {{0,2,0},
		//											{0,2,0},
		//											{0,2,0}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL11);
		game.moveLeft();
		assertArrayEquals(CodeForTest.SEMIFULL1_LEFTCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con un valor por fila en columna 2
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testOneValueForRowInColumn2() {
		//		public static int[][] SEMIFULL13 = {{0,0,2},
		//											{0,0,2},
		//											{0,0,2}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL13);
		game.moveLeft();
		assertArrayEquals(CodeForTest.SEMIFULL1_LEFTCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con dos valores por fila (en la 1 y 2)
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testTwoValuesForRowInColumn1And2() {
	//		public static int[][] SEMIFULL21 = {{0,2,2},
	//											{0,2,2},
	//											{0,2,2}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL21);
		game.moveLeft();
		int[][] matriz = {{4,0,0},
		  		  		  {4,0,0},
		  		  		  {4,0,0}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con dos valores por fila (en la 0 y 1)
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testTwoValuesForRowInColumn0And1() {
	//		public static int[][] SEMIFULL22 = {{2,2,0},
	//											{2,2,0},
	//											{2,2,0}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL22);
		game.moveLeft();
		int[][] matriz = {{4,0,0},
		  		  		  {4,0,0},
		  		  		  {4,0,0}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con dos valores por fila (en la 0 y 2)
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void testTwoValuesForRowInColumn1And4() {
	//		public static int[][] SEMIFULL23 = {{2,0,2},
	//											{2,0,2},
	//											{2,0,2}};
		Game2048 game = new Game2048(CodeForTest.SEMIFULL23);
		game.moveLeft();
		int[][] matriz = {{4,0,0},
		  		  		  {4,0,0},
		  		  		  {4,0,0}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con matriz llena de valores
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz sin cambios por estar llena
	 */
	@Test
	public void testThreeValuesForRow() {
	//		public static int[][] FULL = {{2,2,2},
	//		  							  {2,2,2},
	//		  							  {2,2,2}};
		Game2048 game = new Game2048(CodeForTest.FULL);
		game.moveLeft();
		assertArrayEquals(CodeForTest.FULL, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la izquierda con matriz 4x4 con 1 valor por fila 
	 * (en 0 y 1)
	 * WHEN se llama al m�todo compactLeft
	 * THEN devuelve la matriz compactada a la izquierda
	 */
	@Test
	public void test4x4Matrix() {
		int[][] matriz = {{2,2,0,0},{2,2,0,0},{0,0,0,0},{0,0,0,0}};
		Game2048 game = new Game2048(matriz);
		game.moveLeft();
		int[][] movedMatriz = {{4,0,0,0},{4,0,0,0},{0,0,0,0},{0,0,0,0}};
		assertArrayEquals(movedMatriz, game.getBoard());
	}	
}
