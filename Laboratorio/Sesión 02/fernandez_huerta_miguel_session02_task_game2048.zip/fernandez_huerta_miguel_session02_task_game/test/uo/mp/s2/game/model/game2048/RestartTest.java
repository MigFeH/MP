package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class RestartTest {
	
	/*
	 * Casos de uso:
	 * 1-Que la matriz est� vac�a
	 * 2-Que la matriz est� medio llena
	 * 3-Que la matriz est� llena
	 */

	/**
	 * GIVEN restart con matriz vac�a
	 * WHEN se llama al m�todo restart()
	 * THEN vac�a la matriz
	 */
	@Test
	public void testRestartWithVoidBoard()
	{
		Game2048 board = new Game2048();
		Game2048 matriz = new Game2048();
		
		matriz.restart();
		board.restart();
		
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		
		int p = 0;
		for (int i = 0; i < matriz.getBoard().length; i++)
		{
			for (int j = 0; j < matriz.getBoard()[0].length; j++)
			{
				if (matriz.getBoard()[i][j] != 0)
				{
					p = p + 1;
				}
			}
		}
		
		assertEquals(p,t);
	}
	
	
	/**
	 * 
	 * GIVEN restart con matriz medio llena
	 * WHEN se llama al m�todo restart()
	 * THEN vac�a la matriz
	 */
	@Test
	public void testRestartWithHalfEmptyBoard()
	{
		Game2048 board = new Game2048();
		Game2048 matriz = new Game2048();
		
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				matriz.getBoard()[i][j] = 2;
			}
		}
		
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				board.getBoard()[i][j] = 2;
			}
		}
		
		matriz.restart();
		board.restart();
		
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		
		int p = 0;
		for (int i = 0; i < matriz.getBoard().length; i++)
		{
			for (int j = 0; j < matriz.getBoard()[0].length; j++)
			{
				if (matriz.getBoard()[i][j] != 0)
				{
					p = p + 1;
				}
			}
		}
		
		assertEquals(p,t);
	}
	
	/**
	 * 
	 * GIVEN restart con matriz llena
	 * WHEN se llama al m�todo restart()
	 * THEN vac�a la matriz
	 */
	@Test
	public void testRestartWithFullBoard()
	{
		Game2048 board = new Game2048();
		Game2048 matriz = new Game2048();
		
		for (int i = 0; i < matriz.getBoard().length; i++)
		{
			for (int j = 0; j < matriz.getBoard()[0].length; j++)
			{
				matriz.getBoard()[i][j] = 2;
			}
		}
		
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				board.getBoard()[i][j] = 2;
			}
		}
		
		matriz.restart();
		board.restart();
		
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		
		int p = 0;
		for (int i = 0; i < matriz.getBoard().length; i++)
		{
			for (int j = 0; j < matriz.getBoard()[0].length; j++)
			{
				if (matriz.getBoard()[i][j] != 0)
				{
					p = p + 1;
				}
			}
		}
		
		assertEquals(p,t);
	}
	
}
