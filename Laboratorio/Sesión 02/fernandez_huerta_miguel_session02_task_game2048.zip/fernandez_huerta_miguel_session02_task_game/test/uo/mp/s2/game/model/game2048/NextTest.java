package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class NextTest {
	
	/*
	 * Casos de uso:
	 * 1-Que la matriz est� vac�a
	 * 2-Que la matriz est� medio llena
	 * 3-Que la matriz est� llena
	 */

	/**
	 * GIVEN next con matriz par�metro vac�a
	 * WHEN se llama al m�todo next()
	 * THEN pone un 2 en la matriz de forma aleatoria
	 */
	@Test
	public void testNextWithVoidBoard()
	{
		Game2048 board = new Game2048();
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(1,t);
	}
	
	/**
	 * GIVEN next con matriz par�metro medio llena
	 * WHEN se llama al m�todo next()
	 * THEN pone un 2 en la matriz de forma aleatoria
	 */
	@Test
	public void testNextWithHalfEmptyBoard()
	{
		int[][] matriz = {{2,2,2},{2,2,2},{0,0,0}};
		Game2048 board = new Game2048(matriz);
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] == 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(2,t);
	}
	
	/**
	 * GIVEN next con matriz par�metro llena
	 * WHEN se llama al m�todo next()
	 * THEN no hace nada
	 */
	@Test
	public void testNextWithFullBoard()
	{
		int[][] matriz = {{2,2,2},{2,2,2},{2,2,2}};
		Game2048 board = new Game2048(matriz);
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(9,t);
	}
	
}
