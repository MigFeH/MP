package uo.mp.s2.game.model.game2048;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Game2048WithBoardParamTest.class, Game2048WithIntParamTest.class, Game2048WithoutParamsTest.class,
		IsBoardFullTest.class, MoveDownTest.class, MoveLeftTest.class, MoveRightTest.class, MoveUpTest.class,
		NextTest.class, RestartTest.class })
public class AllTests {

}
