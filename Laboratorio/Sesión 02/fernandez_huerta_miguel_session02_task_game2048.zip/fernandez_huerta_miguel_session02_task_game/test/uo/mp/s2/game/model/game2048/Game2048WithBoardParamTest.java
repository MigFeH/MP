package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class Game2048WithBoardParamTest {
	
	/*
	 * Casos de uso:
	 * 1-Que el par�metro sea null (excepci�n)
	 * 2-Que el par�metro supere el m�ximo de filas permitidas (excepci�n)
	 * 3-Que el par�metro supere el m�ximo de columnas permitidas (excepci�n)
	 * 4-Que el par�metro sea v�lido
	 */
	
	/**
	 * GIVEN constructor con par�metro matriz null
	 * WHEN se crea un objeto de la clase Game2048 con dicho constructor
	 * THEN lanza excepci�n
	 */
	@Test
	public void testGame2048WithNullParam()
	{
		try
		{
			int[][] matriz = null;
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * GIVEN constructor con par�metro matriz con n�mero de filas superior al 
	 * m�ximo permitido
	 * WHEN se crea un objeto de la clase Game2048 con dicho constructor
	 * THEN lanza excepci�n
	 */
	@Test
	public void testGame2048WithTooMuchRowsParam()
	{
		try
		{
			int[][] matriz = new int[Game2048.MAX_ROWS + 1][5];
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * GIVEN constructor con par�metro matriz con n�mero de columnas superior al 
	 * m�ximo permitido
	 * WHEN se crea un objeto de la clase Game2048 con dicho constructor
	 * THEN lanza excepci�n
	 */
	@Test
	public void testGame2048WithTooMuchColumnsParam()
	{
		try
		{
			int[][] matriz = new int[5][Game2048.MAX_COLUMNS + 1];
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * GIVEN constructor con par�metro matriz con par�metro v�lido
	 * WHEN se crea un objeto de la clase Game2048 con dicho constructor
	 * THEN crea un objeto de la clase con los valores y dimensiones que la
	 * matriz par�metro
	 */
	@Test
	public void testGame2048WithCorrectParam()
	{
		int matriz[][] = {{2,0,0},{0,0,0},{2,0,2}};
		Game2048 board = new Game2048(matriz);
		
		assertArrayEquals(matriz, board.getBoard());
	}
	
}
