package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class MoveRightTest {

	/*
	 * Casos de uso:
	 * 1- Matriz con un valor por fila en columna 0
	 * 2- Matriz con un valor por fila en columna 1
	 * 3- Matriz con un valor por fila en columna 2
	 * 
	 * 4- Matriz con 2 valores por fila (en 1 y 2)
	 * 5- Matriz con 2 valores por fila (en 0 y 1)
	 * 6- Matriz con 2 valores por fila (en 0 y 2)
	 * 
	 * 7- Matriz con 3 valores por fila 
	 * 8- Matriz 4x4 con 2 valores por fila (en 0 y 1)
	 */
	
	/**
	 * Casos de uso
	 * 1. Matriz con un valor por fila en columna 0
	 */
	@Test
	public void testOneValueForRowInColumn0() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL12);
		game.moveRight();
		assertArrayEquals(CodeForTest.SEMIFULL1_RIGHTCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 2- Matriz con un valor por fila en columna 1
	 */
	@Test
	public void testOneValueForRowInColumn1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL11);
		game.moveRight();
		assertArrayEquals(CodeForTest.SEMIFULL1_RIGHTCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 3- Matriz con un valor por fila en columna 2
	 */
	@Test
	public void testOneValueForRowInColumn2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL13);
		game.moveRight();
		assertArrayEquals(CodeForTest.SEMIFULL1_RIGHTCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 4- Matriz con 2 valores por fila (en 1 y 2)
	 *
	 */
	@Test
	public void testTwoValuesForRowInColumn1And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL21);
		game.moveRight();
		int[][] matriz = {{0,0,4},
		  		  		  {0,0,4},
		  		  		  {0,0,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 5- Matriz con 2 valores por fila (en 0 y 1)
	 *
	 */
	@Test
	public void testTwoValuesForRowInColumn0And1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL22);
		game.moveRight();
		int[][] matriz = {{0,0,4},
		  		  		  {0,0,4},
		  		  		  {0,0,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 6- Matriz con 2 valores por fila (en 0 y 2)
	 *
	 */
	@Test
	public void testTwoValuesForRowInColumn0And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL23);
		game.moveRight();
		int[][] matriz = {{0,0,4},
		  		  		  {0,0,4},
		  		  		  {0,0,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 7- Matriz con 3 valores por fila 
	 *
	 */
	@Test
	public void testThreeValuesForRow() {
		Game2048 game = new Game2048(CodeForTest.FULL);
		game.moveRight();
		assertArrayEquals(CodeForTest.FULL, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a la derecha con matriz 4x4 con 2 valores por fila
	 * (en 0 y 1)
	 * WHEN se llama al m�todo moveRight
	 * THEN devuelve la matriz compactada a la derecha
	 */
	@Test
	public void test4x4Matrix() {
		int[][] matriz = {{2,2,0,0},{2,2,0,0},{0,0,0,0},{0,0,0,0}};
		Game2048 game = new Game2048(matriz);
		game.moveRight();
		int[][] movedMatriz = {{0,0,0,4},{0,0,0,4},{0,0,0,0},{0,0,0,0}};
		assertArrayEquals(movedMatriz, game.getBoard());
	}	
}