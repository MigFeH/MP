package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class MoveDownTest {
	/*
	 * Casos de uso:
	 * 1- Matriz con un valor por columna en fila 2
	 * 2- Matriz con un valor por columna en fila 1
	 * 3- Matriz con un valor por columna en fila 0
	 * 
	 * 4- Matriz con 2 valores por columna (en 1 y 2)
	 * 5- Matriz con 2 valores por columna (en 0 y 1)
	 * 6- Matriz con 2 valores por columna (en 0 y 2)
	 * 
	 * 7- Matriz con 3 valores por columna
	 * 
	 * 8- Matriz 4x4 con 1 valor por columna (en 0 y 1)
	 */
	
	/**
	 * GIVEN compactador a abajo con un valor por columna en fila 0
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testOneValueForColumnInRow0() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL33);
		game.moveDown();
		assertArrayEquals(CodeForTest.SEMIFULL3_DOWNCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con un valor por columna en fila 1
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testOneValueForColumnInRow1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL32);
		game.moveDown();
		assertArrayEquals(CodeForTest.SEMIFULL3_DOWNCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con un valor por columna en fila 2
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testOneValueForColumnInRow2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL31);
		game.moveDown();
		assertArrayEquals(CodeForTest.SEMIFULL3_DOWNCOMPACTED, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con dos valores por columna en fila 1 y 2
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testTwoValuesForColumnInRow1And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL41);
		game.moveDown();
		int[][] matriz = {{0,0,0},
		  		  		  {0,0,0},
		  		  		  {4,4,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con dos valores por columna en fila 0 y 1
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testTwoValuesForColumnInRow0And1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL43);
		game.moveDown();
		int[][] matriz = {{0,0,0},
				  		  {0,0,0},
				  		  {4,4,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con dos valores por columna en fila 0 y 2
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testTwoValuesForRowInColumn0And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL42);
		game.moveDown();
		int[][] matriz = {{0,0,0},
						  {0,0,0},
						  {4,4,4}};
		assertArrayEquals(matriz, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con matriz llena de valores
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void testThreeValuesForRow() {
		Game2048 game = new Game2048(CodeForTest.FULL);
		game.moveDown();
		assertArrayEquals(CodeForTest.FULL, game.getBoard());
	}
	
	/**
	 * GIVEN compactador a abajo con matriz 4x4 con 1 valor por columna 
	 * (en 0 y 1)
	 * WHEN se llama al m�todo compactDown
	 * THEN devuelve la matriz compactada a abajo
	 */
	@Test
	public void test4x4Matrix() {
		int[][] matriz = {{2,2,2,2},{2,2,2,2},{0,0,0,0},{0,0,0,0}};
		Game2048 game = new Game2048(matriz);
		game.moveDown();
		int[][] movedMatriz = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{4,4,4,4}};
		assertArrayEquals(movedMatriz, game.getBoard());
	}
	
}