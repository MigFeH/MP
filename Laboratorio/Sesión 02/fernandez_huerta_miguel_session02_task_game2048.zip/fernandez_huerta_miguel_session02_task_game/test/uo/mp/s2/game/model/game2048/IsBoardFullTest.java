package uo.mp.s2.game.model.game2048;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s2.game.model.Game2048;

public class IsBoardFullTest {
	// Escenarios:
		// caso 1: matriz completamente llena
		// caso 2: matriz parcialmente llena
	    // caso 3: matriz vac�a

	
	/**
	 * GIVEN isBoardFull con matriz par�metro llena
	 * WHEN se llama al m�todo isBoardFull()
	 * THEN devuelve true
	 */
	@Test
	public void testIsBoardFull() 
	{
		// {{2,2,2},{2,2,2},{2,2,2}}
		Game2048 game = new Game2048(CodeForTest.FULL); 
		assertTrue (game.isBoardFull());
	}
	
	
	/**
	 * GIVEN isBoardFull con matriz par�metro parcialmente llena
	 * WHEN se llama al m�todo isBoardFull()
	 * THEN devuelve false
	 */
	@Test
	public void testNotIsBoardFull()
	{  
		// {{2,2,0},{2,2,0},{2,2,0}}
		Game2048 game = new Game2048(CodeForTest.SEMIFULL22); 
		assertFalse (game.isBoardFull());
	}

	
	/**
	 * GIVEN isBoardFull con matriz par�metro vac�a
	 * WHEN se llama al m�todo isBoardFull()
	 * THEN devuelve false
	 */
	@Test
	public void testIsNullBoard()
	{
		Game2048 game = new Game2048();
		assertFalse(game.isBoardFull());
	}
			
}
