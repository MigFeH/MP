package uo.mp.s12.marker;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;



@RunWith(Suite.class)
@SuiteClasses({uo.mp.s12.marker.parser.questionParser.AllTests.class,
				uo.mp.s12.marker.service.examMarker.AllTests.class})
public class AllTests {

}
