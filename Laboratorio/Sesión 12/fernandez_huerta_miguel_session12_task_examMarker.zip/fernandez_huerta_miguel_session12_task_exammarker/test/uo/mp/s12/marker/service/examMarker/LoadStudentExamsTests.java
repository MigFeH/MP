package uo.mp.s12.marker.service.examMarker;


import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s12.marker.exception.ExamMarkerException;
import uo.mp.s12.marker.service.ExamMarker;

public class LoadStudentExamsTests {
	
	
	/**
	 * 1- Nombre de fichero de respuestas de alumno no existente (ExamMarkerException -> RuntimeException)
	 * 
	 * 2- Nombre de fichero de respuestas de alumno en blanco (IllegalArgumentException)
	 * 3- Nombre de fichero de respuestas de alumno null (IllegalArgumentException)
	 * 
	 * 4- Fichero que contiene dos ex�menes al mismo nombre de un alumno (ExamMarkerException)
	 * 
	 * 5- Fichero de respuestas de un alumno correcto
	 */

	/**
	 * GIVEN: nombre de fichero de respuestas de alumno no existente
	 * WHEN: se invoca al m�todo loadAnswers()
	 * THEN: salta ExamMarkerException que es transformada en RuntimeException
	 */
	@Test
	(expected = RuntimeException.class)
	public void testLoadAnswersWithNonExistingFileNameOfAnswers()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadAnswers("bwvcniulebwie.txt");
		} catch (ExamMarkerException e) {
			
		}
	}
	
	/**
	 * GIVEN: nombre de fichero de respuestas de alumno en blanco
	 * WHEN: se invoca al m�todo loadAnswers()
	 * THEN: salta IllegalArgumentException 
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testLoadAnswersWithEmptyFileNameOfAnswers()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadAnswers(" ");
		} catch (ExamMarkerException e) {
			// no salta una ExamMarkerException
		}
	}
	
	/**
	 * GIVEN: nombre de fichero de respuestas de alumno null
	 * WHEN: se invoca al m�todo loadAnswers()
	 * THEN: salta IllegalArgumentException 
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testLoadAnswersWithNullFileNameOfAnswers()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadAnswers(null);
		} catch (ExamMarkerException e) {
			// no salta una ExamMarkerException
		}
	}
	
	/**
	 * GIVEN: fichero que contiene dos ex�menes al mismo nombre de un alumno
	 * WHEN: se invoca al m�todo loadAnswers()
	 * THEN: salta ExamMarkerException 
	 */
	@Test
	public void testLoadAnswersWithRepeatedExam()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadAnswers("fileContainsRepeatedStudentExams.gz");
		} catch (ExamMarkerException e) {
			// salta la excepci�n y se recoge
		}
	}
	
	/**
	 * GIVEN: fichero de respuestas de alumno correcto
	 * WHEN: se invoca al m�todo loadAnswers()
	 * THEN: se cargan las respuestas del alumno correctamente
	 */
	@Test
	public void testLoadAnswersWithCorrectFileOfOneStudentAnswers()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadAnswers("fileContainsOneStudentExam.gz");
		} catch (ExamMarkerException e) {
			// no salta una ExamMArkerException
		}
		assertEquals("StudentExam [id=20209, answers=[c, b, cosa, computer, 10.5, 100, inheritance, 256.0, a, abstract]]", em.getAnswers().get(0).toString());
	}
}
