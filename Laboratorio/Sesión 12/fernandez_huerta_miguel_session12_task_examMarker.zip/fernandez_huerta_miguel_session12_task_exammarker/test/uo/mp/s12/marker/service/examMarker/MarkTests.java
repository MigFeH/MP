package uo.mp.s12.marker.service.examMarker;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s12.marker.exception.ExamMarkerException;
import uo.mp.s12.marker.model.StudentExam;
import uo.mp.s12.marker.model.question.Question;
import uo.mp.s12.marker.service.ExamMarker;

public class MarkTests {

	private List<Question> nullList; // lista de preguntas null
	
	private List<Question> correctChoiceList; // lista con pregunta de tipo Choice bien contestada
	private List<Question> correctGapList; // lista con pregunta de tipo Gap bien contestada
	
	/**
	 * 1- Lista de preguntas null (IllegalArgumentException)
	 * 
	 * 2- Lista con pregunta de tipo Choice bien contestada (retorna lista con nota del alumno igual al peso de la puntuaci�n de la pregunta)
	 * 3- Lista con pregunta de tipo Gap bien contestada (retorna lista con nota del alumno igual al peso de la puntuaci�n de la pregunta)
	 * 4- Lista con pregunta de tipo Value bien contestada (retorna lista con nota del alumno igual al peso de la puntuaci�n de la pregunta)
	 * 
	 * 5- Lista con pregunta de tipo Choice mal contestada (retorna lista con nota del alumno == -0.2)
	 * 6- Lista con pregunta de tipo Gap mal contestada (retorna lista con nota del alumno == 0.0)
	 * 7- Lista con pregunta de tipo Value mal contestada (retorna lista con nota del alumno == 0.0)
	 * 
	 * 8- Lista con pregunta de tipo Choice, Gap y Value bien contestadas (retorna lista con nota del alumno igual a la suma de los pesos de las preguntas)
	 */
	
	@Before
	public void setUp()
	{
		
	}
	
	/**
	 * GIVEN: lista de preguntas null
	 * WHEN: se invoca al m�todo mark()
	 * THEN: lanza IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testMarkWithNullListOfQuestions()
	{
		ExamMarker em = new ExamMarker();
		
		try {
			em.loadQuestions(null);
		} catch (ExamMarkerException e) {
			
		}
		
		em.mark();
		
	}

}
