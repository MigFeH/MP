package uo.mp.s12.marker.exception;

public class ExamMarkerException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ExamMarkerException(String msg)
	{
		super(msg);
	}
	
	
	@Override
	public String getMessage()
	{
		return super.getMessage();
	}
}
