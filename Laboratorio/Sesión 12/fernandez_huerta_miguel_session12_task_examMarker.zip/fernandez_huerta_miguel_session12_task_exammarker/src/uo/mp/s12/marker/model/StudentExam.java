package uo.mp.s12.marker.model;

import java.util.ArrayList;
import java.util.List;

import uo.mp.s12.marker.model.question.Question;
import uo.mp.util.ArgumentsCheck;

public class StudentExam {

	private String id;
	private ArrayList<String> answers;

	/**
	 * 
	 * @param id
	 * @param answers
	 * @throws IllegalArgumentException if 
	 * 		- id is null or blank
	 *      - id is not length five or does not contain just digits
	 * 		- answers is null
	 */
	public StudentExam(String id, List<String> answers) {
		ArgumentsCheck.isTrue(!id.isBlank() || id != null, "Identificador no v�lido");
		ArgumentsCheck.isTrue(id.length() == 5, "Longitud del identificador no v�lida");
		ArgumentsCheck.isTrue(answers != null, "Lista de respuestas no v�lida");
		
		this.id = id;
		this.answers = new ArrayList<>( answers );
	}

	/**
	 * 
	 * @param questions
	 * @return
	 * @throws IllegalArgumentException if questions is null
	 */
	public double mark(List<Question> questions) {
		ArgumentsCheck.isTrue(questions != null, "Lista de preguntas null");
		
		double res = 0.0; // nota final del examen
		for(int i = 0; i < questions.size(); i++)
		{
			Question q = questions.get(i); // objeto Question que guarda la pregunta correspondiente a la iteraci�n
			String answer = answers.get(i); // String que guarda la pregunta correspondiente a la iteraci�n
			res = res + q.mark(answer); // aplicaci�n de la puntuaci�n obtenida en la pregunta correspondiente a la iteraci�n
		}
		return res; // retorno de la puntuaci�n final
		
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return "StudentExam [id=" + id + ", answers=" + answers + "]";
	}
}
