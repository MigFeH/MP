package uo.mp.s12.marker.comparators;

import java.util.Comparator;

import uo.mp.s12.marker.model.StudentMark;

public class MarksByMarkOrStudentIdComparator implements Comparator<StudentMark> {

	@Override
	public int compare(StudentMark o1, StudentMark o2) {
		int diff = ( (Double) o1.getMark() ).compareTo( (Double) o2.getMark() );
		
		if(diff == 0) // si son iguales...
		{
			return (o1.getStudentId()).compareTo(o2.getStudentId());
		} else
		{
			return diff;
		}
	}

}
