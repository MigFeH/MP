package uo.mp.s12.marker.util.file;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

import uo.mp.util.ArgumentsCheck;

public class ZipFileUtil {
	
	public List<String> zipFileReadLines(String inZipName) throws FileNotFoundException
	{
		ArgumentsCheck.isTrue(inZipName != null && !inZipName.isBlank());
		
		List<String> res = new ArrayList<>();
		try
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(inZipName))));
			try
			{
				String line;
				while ((line = in.readLine()) != null)
				{
					res.add(line);
				}
			} finally 
			{
				in.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException("Fichero no encontrado");
		}
		return res;
	}
}
