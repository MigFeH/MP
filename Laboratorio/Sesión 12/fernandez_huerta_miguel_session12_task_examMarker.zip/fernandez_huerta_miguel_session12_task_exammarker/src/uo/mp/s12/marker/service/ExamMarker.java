package uo.mp.s12.marker.service;

import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.s12.marker.comparators.MarksByMarkOrStudentIdComparator;
import uo.mp.s12.marker.exception.ExamMarkerException;
import uo.mp.s12.marker.model.StudentExam;
import uo.mp.s12.marker.model.StudentMark;
import uo.mp.s12.marker.model.question.Question;
import uo.mp.s12.marker.parser.ExamParser;
import uo.mp.s12.marker.parser.QuestionParser;
import uo.mp.s12.marker.util.file.FileUtil;
import uo.mp.s12.marker.util.file.ZipFileUtil;
import uo.mp.util.ArgumentsCheck;


public class ExamMarker implements Serializable{
	
	private static final long serialVersionUID = 1L;
	/*
	 * file questions.txt is read and parsed into questions list
	 */
	transient private List<Question> questions = new ArrayList<>();
	/*
	 * file answers.gz is read and parsed into answers list
	 */
	transient private List<StudentExam> answers = new ArrayList<>();
	/*
	 * Student marks are computed and stored into marks list
	 */
	private List<StudentMark> marks = new ArrayList<>();


	/**
	 * 
	 * @param examModelFile
	 * @throws IllegalArgumentException if examModelFile is null or blank
	 * @throws FileNotFoundException if examModelFile cannot be found
	 */
	public void loadQuestions(String questionsFilename) throws ExamMarkerException {
		ArgumentsCheck.isTrue(!questionsFilename.isBlank() || questionsFilename != null);
		try
		{
			List<String> lines = new FileUtil().readLines(questionsFilename);
			List<Question> questions = new QuestionParser().parse( lines );
			addQuestions( questions );
		} catch(FileNotFoundException e)
		{
			throw new ExamMarkerException(e.getMessage());
		}
	}
	
	private void addQuestions(List<Question> quests) {
		ArgumentsCheck.isTrue(quests != null && !quests.isEmpty());
		for(Question q : quests)
		{
			questions.add(q);
		}
	}

	/**
	 * 
	 * @param answersFilename
	 * @throws FileNotFoundException if answersFile cannot be found 
	 * @throws IllegalArgumentException if answersFilename is null or blank
	 * @throws ExamMarkerException when there are more than one exam for the same student 
	 */
	public void loadAnswers(String answersFilename) throws ExamMarkerException {
		ArgumentsCheck.isTrue(answersFilename != null, "Fichero de respuestas de alumno no v�lido");
		ArgumentsCheck.isTrue(!answersFilename.isBlank(), "Fichero de respuestas de alumno no v�lido");
		try
		{
			List<String> lines = new ZipFileUtil().zipFileReadLines(answersFilename);
			List<StudentExam> exams = new ExamParser().parse( lines );
			addExams( exams );
		} catch(FileNotFoundException e)
		{
			throw new ExamMarkerException(e.getMessage());
		}
	}
	
	private void addExams(List<StudentExam> exams) throws ExamMarkerException {		
		List<String> aux = new ArrayList<>();
		List<StudentExam> res = new ArrayList<>();
		
		for(int i = 0; i < exams.size(); i++)
		{
			aux.add(exams.get(i).getId()); // lista de ids de los alumnos
		}
		
		for(int i = 0; i < exams.size(); i++) // recorrido de la lista de ex�menes
		{
			for(int j = 0; j < aux.size(); j++) // recorrido de la lista de ids
			{
				if(exams.get(i).getId().equals(aux.get(j)) && i != j) // si hay dos iguales...
				{
					throw new ExamMarkerException("Entrega repetida del alumno " + aux.get(j));
				}
				res.add(exams.get(i));
			}
		}
		this.answers = res;
	}

	public StudentMark findMark(String id) throws ExamMarkerException
	{
		for(StudentMark mark : marks)
		{
			if(mark.getStudentId().equals(id))
				return mark;
		}
		throw new ExamMarkerException("Nota no encontrada o estudiante desconocido");
	}

	/**
	 * 
	 * @return the list of marks ordered by student id in ascending order
	 */
	public List<StudentMark> getMarksByStudent() {
		Collections.sort(marks); /* ESTO ORDENA DE FORMA NATURAL (la clase del tipo debe tener 
		implements Comparable<Nombre de la clase en la que se hace el implements> */
		
		//Collections.sort(marks, new MarksByStudentIdComparator());
		//return (new ArrayList<StudentMark>(marks));
		
		// si nos piden una lista ordenada pero sin modificar la original lo hacemos de la siguiente forma:
		List<StudentMark> sorted = new ArrayList<>(marks);
		Collections.sort(sorted);
		return sorted;
	}

	/**
	 * 
	 * @return the list of marks ordered by grade in ascending order
	 * 			For the same grade, by ascending student id
	 */
	public List<StudentMark> getMarksByMark() {
		Collections.sort(marks, new MarksByMarkOrStudentIdComparator());
		
		
		return (new ArrayList<StudentMark>(marks));
	}

	/**
	 * calculates the mark for each exam. 
	 * Generates StudentMark instances
	 */
	public void mark() {
		for(StudentExam theAnswer: answers)
		{
			marks.add(new StudentMark(theAnswer.getId(), theAnswer.mark(questions)));
		}
	}

	/**
	 * 
	 * @param resultsFilename
	 * @throws IllegalArgumentException if resultsFilename is null or blank
	 */
	public void saveResults(String resultsFilename) throws RuntimeException  {
		ArgumentsCheck.isTrue(!resultsFilename.isBlank() || resultsFilename != null);
		new FileUtil().writeLines(marks, resultsFilename);
	}

	

	public List<StudentExam> getAnswers() {
		return new ArrayList<StudentExam>(answers);
	}

	public List<Question> getQuestions() {
		return new ArrayList<Question>(questions);
	}

}
