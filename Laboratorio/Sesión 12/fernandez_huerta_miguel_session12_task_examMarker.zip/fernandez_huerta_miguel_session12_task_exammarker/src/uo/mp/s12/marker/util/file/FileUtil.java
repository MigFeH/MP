package uo.mp.s12.marker.util.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import uo.mp.s12.marker.model.StudentMark;
import uo.mp.util.ArgumentsCheck;

public class FileUtil {
	
	public List<String> readLines(String inFileName) throws FileNotFoundException
	{
		ArgumentsCheck.isTrue(inFileName != null && !inFileName.isBlank());
		
		BufferedReader in = new BufferedReader(new FileReader(inFileName));
		List<String> res = new ArrayList<>();
		
		try 
		{
			try 
			{
				String line;
				while((line = in.readLine()) != null)
				{
					res.add(line);
				}
			} finally 
			{
				in.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException("Fichero no encontrado");
		}
		return res;
	}
	
	public void writeLines(List<StudentMark> lines, String outFileName) throws RuntimeException
	{
		ArgumentsCheck.isTrue(lines != null && !lines.isEmpty());
		ArgumentsCheck.isTrue(outFileName != null && !outFileName.isBlank());
		
		try
		{
		BufferedWriter bw = new BufferedWriter(new FileWriter(outFileName));
			try
			{
				for(int i = 0; i < lines.size(); i++)
				{
					String line = lines.get(i).getStudentId() + " --> " + lines.get(i).getMark();

					bw.write(line); // escritura de la l�nea
					bw.newLine(); // salto de l�nea
				}
			} finally
			{
				bw.close();
			}
		} catch(IOException e)
		{
			throw new RuntimeException(e);
		}
	}
}
