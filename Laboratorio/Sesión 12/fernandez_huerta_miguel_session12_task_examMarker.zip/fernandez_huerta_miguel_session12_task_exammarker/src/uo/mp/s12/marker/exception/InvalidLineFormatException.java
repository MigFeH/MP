package uo.mp.s12.marker.exception;

import uo.mp.util.ArgumentsCheck;

public class InvalidLineFormatException extends Exception {

	private static final long serialVersionUID = 1L;
	
	private int lineNumber;
	
	public InvalidLineFormatException(int lineNumber, String msg)
	{
		super(msg);
		ArgumentsCheck.isTrue(lineNumber > 0);
		this.lineNumber = lineNumber;
	}
	
	@Override
	public String getMessage()
	{
		return "INVALID LINE " + lineNumber + ": " + super.getMessage();
	}
}
