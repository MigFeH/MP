package uo.mp.s6.greenhouse.sensors;

import java.util.Random;


public class HumiditySensor{
	
	
	/**
	 * Retorna el porcentaje de humedad
	 * 
	 * @return el porcentaje
	 */
	public static double getHumidity()
	{
		return new Random().nextDouble(101);
	}
	
}
