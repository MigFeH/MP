package uo.mp.s6.greenhouse.controllers.devicescanner;

import java.util.ArrayList;
import java.util.List;

import uo.mp.s6.greenhouse.checkable.Checkable;
import uo.mp.util.ArgumentsCheck;

public class DeviceScanner {
	
	private List<Checkable> checkables = new ArrayList<>();//lista de checkables
	
	/**
	 * A�ade elementos checkables a la lista de checkables
	 * 
	 * @param el checkable a a�adir a la lista
	 */
	public void add(Checkable theCheckable)
	{
		ArgumentsCheck.isTrue(theCheckable != null, "Esperaba objeto checkable "
				+ "pero fue null");
		this.checkables.add(theCheckable);
	}
	
	
	/**
	 * Checkea el estado del dispositivo
	 * 
	 * @return mensajes para informar al jardinero sobre la operaci�n
	 */
	public List<String> scan()
	{
		List<String> messages = new ArrayList<>();
		
		for (Checkable theCheckable: checkables)
		{
			if (!theCheckable.check())
			{
				messages.add("WARNING: " + theCheckable.toString() + 
						" is not in a good condition");
			}
		}
		return messages;
	}

}
