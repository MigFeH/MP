package uo.mp.s6.greenhouse.switchmode;

public enum SwitchMode {
	OFF, LOW, MEDIUM, HIGH

}
