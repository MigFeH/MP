package uo.mp.s6.greenhouse.checkable;

public interface Checkable {
	boolean check();
}
