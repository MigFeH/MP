package uo.mp.s6.greenhouse.controllers;

import java.util.ArrayList;
import java.util.List;

import uo.mp.s6.greenhouse.sensors.HumiditySensor;
import uo.mp.s6.greenhouse.switchmode.SwitchMode;
import uo.mp.util.ArgumentsCheck;

public class HumidityController {
	
	public static final int MIN_HUMIDITY = 40; // m�nimo de h�medad confort
	public static final int MAX_HUMIDITY = 60; // m�ximo de humedad confort
	
	private static final double SO_HIGH_HUMIDITY = MAX_HUMIDITY + 
			(MAX_HUMIDITY * 0.2); /* representa el m�nimo de humedad en el que
	se le considera a �sta como demasiado alta (20% por encima del 
	l�mite superior) */
	private static final double SO_LOW_HUMIDITY = MIN_HUMIDITY - 
			(MIN_HUMIDITY * 0.2); /* representa el m�nimo de humedad en el que
	se le considera a �sta como demasiado baja (20% por debajo del 
	l�mite inferior) */

	private List<HumiditySensor> sensors; // lista de sensores de humedad
	
	private SwitchMode mode; // modo de regulaci�n del agua
	
	
	/**
	 * Constructor de la clase sin par�metros
	 */
	public HumidityController()
	{
		setMode(SwitchMode.OFF);
		this.sensors = new ArrayList<>();
	}
	
	
	/**
	 * A�ade un sensor de humedad a la lista de sensores
	 * 
	 * @param el sensor a a�adir a la lista
	 */
	public void add(HumiditySensor sensor)
	{
		ArgumentsCheck.isTrue(sensor != null, "Esperaba sensor pero fue null");
		this.sensors.add(sensor);
	}
	
	
	/**
	 * Retorna la humedad del entorno siendo un valor aleatorio en el rango
	 * [0-100]
	 * 
	 * @return la humedad
	 */
	public double getHumidity()
	{
		return HumiditySensor.getHumidity();
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo mode
	 * 
	 * @return el valor que almacena dicho atributo
	 */
	public SwitchMode getMode()
	{
		return mode;
	}

	
	/**
	 * Se cambia el modo de disparo del dispersor 
	 * 
	 * @param el nuevo valor para el atributo mode
	 */
	public String setMode(SwitchMode mode)
	{
		ArgumentsCheck.isTrue(mode != null, "Esperaba modo de regulaci�n del "
				+ "agua pero fue null");
		this.mode = mode;
		return "Irrigator set to " + mode;
	}
	
	
	/**
	 * Informa al jardinero sobre la humedad media del entorno
	 * 
	 * @return la lista de mensajes que informan al jardinero
	 */
	public List<String> actualHumidity()
	{
		List<String> theList = new ArrayList<>();
		
		theList.add("Current humidity is " + getHumidity());
		
		/* Si la humedad promedio est� en el nivel de confort... */		
		if (getHumidity() >= MIN_HUMIDITY && getHumidity() <= MAX_HUMIDITY)
		{
			theList.add("Humidity is right");
		}
		
		
		 /* Si la humedad promedio es demasiado alta 
		  * (20% por encima del l�mite superior)... */
		if (getHumidity() >= SO_HIGH_HUMIDITY)
		{
			SwitchMode oldStatus = getMode(); /* recoge el "anterior" modo de 
				disparo del sistema de riego */
			setMode(SwitchMode.OFF); // coloca a OFF el sistema de riego
			
			theList.add("Current humidity: " + getHumidity() + "." + "\n" 
					+ "It is too damp." + "\n" 
					+ "Irrigator system is " + oldStatus + " and is set to " 
					+ getMode() + "\n");			
		}
		
		
		/* Si la humedad media es demasiado baja 
		 * (20 % por debajo del l�mite inferior)... */
		if (getHumidity() <= SO_LOW_HUMIDITY)
		{
			SwitchMode oldStatus = getMode(); /* recoge el "anterior" modo de 
			disparo del sistema de riego */
			
			setMode(SwitchMode.HIGH); // se coloca el sistema de riego a HIGH
			
			theList.add("Current humidity: " + getHumidity() + "." + "\n"
					+ "It is too dry." + "\n"
					+ "Irrigator system is " + oldStatus + " and is set to " 
					+ getMode() + "\n");
		}
		
		
		/* Si la humedad media est� por encima del l�mite superior y debajo de
		 * ser demasiado alta (20% por encima del l�mite superior)... */
		if (getHumidity() >= MAX_HUMIDITY && getHumidity() <= SO_HIGH_HUMIDITY)
		{
			SwitchMode oldStatus = getMode(); /* recoge el "anterior" modo de 
			disparo del sistema de riego */
			
			setMode(decreaseMode()); /* se coloca el sistema de riego a un nivel 
			por debajo */
			
			theList.add("Current humidity: " + getHumidity() + "." + "\n"
					+ "It is a bit too damp." + "\n"
					+ "Irrigator system is " + oldStatus + " and is set to "
					+ getMode() + "\n");
		}
		
		
		/* Si la humedad media est� por debajo del l�mite inferior y por encima
		 * de ser demasiado baja (20% por debajo del l�mite inferior)... */
		if (getHumidity() <= MIN_HUMIDITY && getHumidity() >= SO_LOW_HUMIDITY)
		{
			SwitchMode oldStatus = getMode(); /* recoge el "anterior" modo de 
			disparo del sistema de riego */
			
			setMode(increaseMode()); /* se coloca el sistema de riego a un nivel 
			por encima */
			
			theList.add("Current humidity: " + getHumidity() + "." + "\n"
					+ "It is a bit too dry." + "\n"
					+ "Irrigator system is " + oldStatus + " and is set to "
					+ getMode() + "\n");
		}
		
		return theList;
	}
	
	
	/**
	 * Incrementa el nivel del sistema de riego en 1 unidad
	 * 
	 * @return el nuevo modo del sistema de riego
	 */
	private SwitchMode increaseMode()
	{
		if (getMode().equals(SwitchMode.OFF))
		{
			return SwitchMode.LOW;
		} else if (getMode().equals(SwitchMode.LOW))
		{
			return SwitchMode.MEDIUM;
		}
		return SwitchMode.HIGH;
	}
	
	
	/**
	 * Decrementa el nivel del sistema de riego en 1 unidad
	 * 
	 * @return el nuevo modo del sistema de riego
	 */
	private SwitchMode decreaseMode()
	{
		if (getMode().equals(SwitchMode.HIGH))
		{
			return SwitchMode.MEDIUM;
		} else if (getMode().equals(SwitchMode.MEDIUM))
		{
			return SwitchMode.LOW;
		}
		return SwitchMode.OFF;
	}
}
