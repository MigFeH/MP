package uo.mp.s6.greenhouse.actuators.doors;

import java.util.Random;

import uo.mp.s6.greenhouse.checkable.Checkable;

/**
 * <p>Title: Door</p>
 * <p>Description: Class that simulates a door.</p>
 * <p>Copyright: Copyright (c) 2022</p>
 * <p>Computer Science Engineering School</p>
 * <p>Programming Methodology</p>
 * 
 * @author Lectures of Programming Methodology
 * @version 2.0
 */
public class AutomaticDoor extends Door implements Checkable{
	
	
	public AutomaticDoor(int id) {
		super(id);
	}
	
	@Override
	public String open(){
		if ( ! isOpened()) {
			setOpened(true);
			return "Automatic door " + getId() + " is opening";
		}
		return null;
	}
	
	@Override
	public String close(){
		if ( isOpened()) {
			setOpened(false);
			return "Automatic door " + getId() + " is closing";
		}
		return null;
	}

	@Override
	public String toString() {
		return "[AutomaticDoor] " + getId();
	}
	
	@Override
	public boolean check()
	{
		return new Random().nextDouble() >= 0.005;
	}
	
}
