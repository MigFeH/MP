package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class GetTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: get() is invoked with index -1
	 * Then: throws IndexOutOfBoundsException
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void getWithInvalidPositionTest() {
		
		list.get(-1);
	}
	
	/**
	 * GIVEN: posici�n negativa
	 * WHEN: se llama al m�todo getPosition
	 * THEN: salta excepci�n
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void getPositionWithNegativeParamTest() {
		list.get(-1);
	}
	
	
	/**
	 * Given: an empty list
	 * When: get is invoked with index size
	 * Then: throws exception
	 */
	@Test
	(expected = Exception.class)
	public void getPositionWithTooHighIndexTest() {
		
		list.get(list.size());
	}
	
	/**
	 * GIVEN: Una lista vacia
	 * WHEN: Llamas al metodo get() en posicion 0
	 * THEN: Salta una excepcion y la lista se queda igual
	 */
	@Test
	(expected = Exception.class)
	public void getWithAlreadyEmptyListTest() {
			String ini = list.toString();
			int inisize = list.size();
			
			list.get(0);
			
			String fin = list.toString();
			int finsize = list.size();
			assertEquals(fin,ini);
			assertEquals(inisize,finsize);
		
	}
}
