package uo.mp2122.lab08.traversing.indices;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import uo.mp2122.lab08.traversing.hidden.Factory;

public class IterateWithIndices {

	public static void main(String[] args) {

		display(Factory.getAnimals());
	}

	private static void display(Collection arg) {
		List animals = (List)arg;
		for (int index = 0; index < animals.size(); index++ ) {
			System.out.println(animals.get(index));
		}
	}
	

}
