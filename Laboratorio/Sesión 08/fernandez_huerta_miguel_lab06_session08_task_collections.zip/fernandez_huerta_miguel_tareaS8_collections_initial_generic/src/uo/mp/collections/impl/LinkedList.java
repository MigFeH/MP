package uo.mp.collections.impl;

import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.collections.List;
import uo.mp.collections.impl.LinkedList.Node;
import uo.mp.util.ArgumentsCheck;

public class LinkedList<T> extends AbstractList<T> {
	
	private Node head; // la cabecera que apunta al primer nodo de la lista	
	
	/**
	 * Clase Node dentro de la LinkedList
	 */
	class Node
	{
		private Node next;
		private T value;
		
		/**
		 * Constructor con par�metros de la clase Node
		 * 
		 * @param el valor a almacenar en el nodo
		 * @param la referencia a un nodo
		 */
		private Node(T value, Node next)
		{
			this.value = value;
			this.next = next;
		}
	}

	/**
	 * Busca en la lista un objeto no nulo dado como par�metro y retorna true si
	 * el objeto estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a buscar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean contains(Object o) {
		ArgumentsCheck.isTrue(o != null, "Esperaba objeto pero fue null");
		
		if (! isEmpty()) // si la lista no est� vac�a...
		{
			Node aux = head;
			
			for (int i = 0; i < size(); i++)
			{
				if (aux.value.equals(o)) // si es el objeto que se busca...
				{
					return true;
				}	
				aux = aux.next;
			}
		}
		return false;
	}

	/**
	 * A�ade un elemento no nulo a la lista de objetos en el �ltimo nodo de 
	 * �sta y retorna true porque �ste tipo de lista admite elementos 
	 * repetidos
	 * 
	 * @param el objeto a a�adir
	 * @return true por permitir elementos repetidos
	 */
	@Override
	public boolean add(T element) {
		ArgumentsCheck.isTrue(element != null, 
				"Esperaba elemento a a�adir pero fue null");
		
		if (! isEmpty()) // si la lista no est� vac�a...
		{
			Node aux = head;
			
			for (int i = 0; i < size() - 1; i++)
			{
				aux = aux.next;
			}
			
			aux.next = new Node(element, null);
			
			setNumberOfElements(getNumberOfElements() + 1);
			return true;
		}
		
		
		add(0, element);
		return true;
		
		
	}

	/**
	 * Borra un elemento no nulo de la lista de objeto y retorna true si el 
	 * elemento que se iba a borrar estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a borrar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean remove(T o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a borrar pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			if (indexOf(o) != 0) // el objeto no est� en la primera posici�n...
			{
				Node aux = head;
				
				for (int i = 0; i < size(); i++)
				{
					if (aux.value.equals(o))
					{
						break;
					}
					aux = aux.next;
				}
				
				aux.next = aux.next;
				
				setNumberOfElements(getNumberOfElements() - 1);
				
				return true;
			} else {
				if (size() == 1) // si es el �nico elemento de la lista...
				{
					clear();
					
					return true;
				}
				
				head = head.next;
				
				setNumberOfElements(getNumberOfElements() - 1);
				
				return true;
			}
		}
		return false;
	}

	/**
	 * Limpia la lista por completo borrando todos los objetos que la contienen
	 */
	@Override
	public void clear() {
		head = null;
		setNumberOfElements(0);
	}

	/**
	 * Retorna un objeto de la lista de una posici�n dada como par�metro
	 * 
	 * @param la posici�n o �ndice en el que se encuentra el objeto
	 * @return el objeto que se ha encontrado en esa posici�n
	 */
	@Override
	public T get(int index) {
		ArgumentsCheck.isValid(index, size());
		
		Node aux = head;
		
		if (index == size() - 1) // si es el �ndice de la �ltima posici�n...
		{
			for (int i = 0; i < size() - 1; i++)
			{
				aux = aux.next;
			}
		} else if (index == 0) // si es el �ndice de la primera posici�n...
		{
			return head.value;
		} else { // sino...
			
			for (int i = 0; i < index; i++)
			{
				aux = aux.next;
			}
		}
		
		return aux.value;
	}

	/**
	 * Sustituye en la lista a un objeto que estaba en una posici�n dada como
	 * par�metro por otro objeto dado como par�metro no nulo
	 * 
	 * Retorna el objeto de antes de haber sido sustituido por el del par�metro
	 * 
	 * @param el �ndice a colocar el objeto
	 * @param el elemento a colocar en la lista
	 * @return el anterior objeto en la posici�n de la lista
	 */
	@Override
	public T set(int index, T element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba elemento para que "
				+ "sustituyese a otro pero fue null");
	
		if (! isEmpty()) // lista no vac�a...
		{
			if (index == 0) // si el �ndice es el primero de la lista...
			{
				Node previous = head;
				head = new Node(element, head.next);
				
				return previous.value;
			}
			
			if (index == size() - 1) // si el �ndice es el �ltimo de la lista...
			{
				Node previous = getNode(index);
				Node aux = getNode(index - 1);
				
				aux.next = new Node(element, null);
				
				return previous.value;
			}
			
			Node previous = getNode(index);
			Node aux = getNode(index - 1);
			
			aux.next = new Node(element, aux.next);
			
			return previous.value;
		}
		
		add(0, element);
		
		return null;
		
	}

	/**
	 * A�ade un objeto no nulo a la lista de elementos en un �ndice v�lido en la
	 * lista
	 * 
	 * @param el �ndice
	 * @param el elemento a a�adir
	 */
	@Override
	public void add(int index, T element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null,
				"Esperaba elemento a a�adir en la lista pero fue null");
		
		if (index == size() - 1) // si el �ndice es el del �ltimo de la lista...
		{
			add(element);
		} 
		else if (index == 0) // si el �ndice es del primero de la lista...
		{
			head = new Node(element, head);
			setNumberOfElements(getNumberOfElements() + 1);
		}
		else {
			
			Node aux = head;
			
			for (int i = 0; i < index; i++)
			{
				aux = aux.next;
			}
			
			aux.next = new Node(element, aux.next);
			
			setNumberOfElements(getNumberOfElements() + 1);
		}
	}

	/**
	 * Borra de la lista de objetos un objeto de �sta en un �ndice dado como
	 * par�metro y retorna el objeto que ha sido borrado
	 * 
	 * @param el �ndice del objeto que se quiere borrar
	 * @return el objeto que ha sido borrado
	 */
	@Override
	public T remove(int index) {
		ArgumentsCheck.isValid(index, size());
		
		if (! isEmpty()) // si la lista no est� vac�a...
		{
		
			if (index == 0) // si el �ndice es el del primer elemento...
			{
				Node previous = head;
				head = head.next;

				setNumberOfElements(getNumberOfElements() - 1);
				return previous.value;
			}

			if (index == size() - 1) // si el �ndice es el del �ltimo elemento...
			{
				Node previous = getNode(size() - 1);
				Node aux = head;

				for (int i = 0; i < size() - 1; i++)
				{
					aux = aux.next;
				}

				aux.next = null;
				setNumberOfElements(getNumberOfElements() - 1);

				return previous.value;
			}

			Node previous = getNode(index);
			Node aux = getNode(index - 1);

			aux.next = aux.next.next;

			setNumberOfElements(getNumberOfElements() - 1);

			return previous.value;
		}
		
		throw new IndexOutOfBoundsException();
	}

	/**
	 * Retorna el �ndice de un objeto no nulo en la lista, si el objeto no est�
	 * en la lista de objetos retorna -1
	 * 
	 * @param el objeto a buscarle el �ndice de su posici�n
	 * @return la posici�n en la que se encuentra el objeto
	 */
	@Override
	public int indexOf(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscarle el �ndice pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			Node aux = head;
			
			for (int i = 0; i < size(); i++)
			{
				if (aux.value.equals(o))
				{
					return i;
				}
				aux = aux.next;
			}
		}
		
		return -1;
	}

	/**
	 * Retorna el nodo de una posici�n dada como par�metro
	 * 
	 * @param la posici�n
	 * @return el nodo
	 */
	private Node getNode(int index)
	{
		ArgumentsCheck.isValid(index, size());
		
		if (index == 0) // si el �ndice es el primero de la lista...
		{
			return head;
		} else {
			
			Node aux = head;
			
			for (int i = 0; i < index; i++)
			{
				aux = aux.next;
			}
			return aux;
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public boolean equals(Object o) {
	if (o == null) return false;
	if (o == this) return true;
	if (!(o instanceof List)) return false;


	List<T> that = (List<T>) o;
	if ( this.size() != that.size() ) return false;

	for(int i = 0; i < size(); i++) {
	T e1 = this.get( i );
	T e2 = (T) that.get( i );
	if (!(e1.equals(e2)))
	return false;
	}
	return true;
	}
	
	@Override
	public int hashCode() {
	int result = 1;
	for (int i = 0; i < size(); i++) {
	T element = this.get( i );
	result = 31 * result + (element.hashCode());
	}
	return result;
	}

	@Override
	public String toString() {
		String data = "";
		Node aux = head;
		
		for (int i = 0; i < size(); i++)
		{
			if (i == size() - 1)
			{
				data = data + aux.value;
				break;
			}
			
			data = data + aux.value + ",";
			aux = aux.next;
		}
		return data;
	}

	@Override
	public Iterator<T> iterator() {
		return new LinkedListIterator();
	}
	
	
	private class LinkedListIterator implements Iterator<T>
	{
		
		private Node next;
		private int nextIndex = 0;
		private Node lastReturned;
		
		private LinkedListIterator()
		{
			next = head;
			nextIndex = 0;
			lastReturned = null;
			
		}
		
		@Override
		public boolean hasNext() {
			return next != null;
		}

		@Override
		public T next() {
			if (hasNext())
			{
				lastReturned = next;
				next = next.next;
				nextIndex++;
				return lastReturned.value;
			} else {
				throw new NoSuchElementException();
			}
		}
		
		
		
		// equals, indexOf y contains con Objecto.. NO CON T
		
	}
}
