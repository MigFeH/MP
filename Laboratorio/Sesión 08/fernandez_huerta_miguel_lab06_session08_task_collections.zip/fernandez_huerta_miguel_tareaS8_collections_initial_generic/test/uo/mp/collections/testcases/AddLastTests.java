package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class AddLastTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: add() is invoked with a null object
	 * Then: throws an exception
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void addLastWithNullParamTest()
	{
		list.add(null);
		
		assertEquals(0, list.size());
		assertEquals( "" , list.toString());
	}
	
	/**
	 * GIVEN: element in last position 
	 * WHEN: add is invoked
	 * THEN: element is added in last position
	 */
	@Test
	public void addInLastPositionWithCorrectParamTest() {
		assertTrue("A", list.add("A"));
	}
	
	
	/**
	 * Given: a list with several elements
	 * When: add() is invoked
	 * Then: element is inserted in last position
	 */
	@Test
	public void addLastWithAlreadyFullListTest() {
		list.add("A");
		list.add("B");
		
		list.add("C");
		
		//assertTrue( list.contains( "C" ) == true );
		assertEquals("C", list.get(list.size()-1));
	}
	
	/**
	 * Given: an empty list
	 * When: add() is call
	 * Then: the list add ir at first position
	 */
	@Test
	public void addLastWithAlreadyClearedListTest() {
	assertTrue( list.size() == 0 );
	assertTrue(list.add("A"));
	assertTrue( list.contains( "A" ) == true );
	assertTrue(list.indexOf("A")== 0);
	}
	
}
