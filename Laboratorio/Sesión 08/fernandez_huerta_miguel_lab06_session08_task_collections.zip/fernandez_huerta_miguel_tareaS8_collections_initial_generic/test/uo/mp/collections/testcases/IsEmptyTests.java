package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class IsEmptyTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: isEmpty() is invoked
	 * Then: returns true
	 */
	@Test
	public void isEmptyWithAlreadyEmptyListTest() {
		assertEquals("", list.toString());
		assertTrue(list.isEmpty());
	}
	
	/**
	 * GIVEN: 
	 * WHEN: se invoca al m�todo isEmpty
	 * THEN: 
	 */
	@Test
	public void isEmptyWithClearedListTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );

		list.clear();
		
		assertTrue( list.size() == 0 );
		
		assertTrue( list.contains( "A" ) == false );
		assertTrue( list.contains( "B" ) == false );
		assertTrue( list.contains( "C" ) == false );
		assertTrue( list.contains( "D" ) == false );
		//alternativa
		//assertEquals( "[]" , list.toString());
	}
	
	/**
	 * Given: a list with one element
	 * When: invoked isEmpty()
	 * Then: return false
	 */
	@Test
	public void isEmptyWithOnlyOneElementInListTest() {
		list.add("A");
		assertEquals(list.isEmpty(), false);
	}
	

}
