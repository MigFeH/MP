package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class AddInPositionTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: an empty list
	 * When: addInPosition() is invoked
	 * Then: the list now contains an element in position 0
	 */
	@Test
	public void addInPositionWithEmptyListTest()
	{
		list.add(0, "A");
		
		assertEquals(1, list.size());
		assertTrue(list.contains("A"));
		assertEquals( "A" , list.toString());
	}
	
	/**
	 * GIVEN: many objects to insert in the list
	 * WHEN: addPosition is invoked
	 * THEN: objects will be added to the list
	 */
	@Test
	public void addInPositionWithManyElementsTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );
		assertEquals(4, list.size());
		list.add(0,  "E" );
		assertEquals(5, list.size());
		assertEquals("A", list.get(1));
		assertEquals("B", list.get(2));
		assertEquals("C", list.get(3));
		assertEquals("D", list.get(4));
		assertEquals("E", list.get(0));		
	}
	
	/**
	 * GIVEN: a complete list 
	 * WHEN: addPosition is invoked
	 * THEN: inserts element in position and moves the rest to the right
	 */
	@Test
	public void addInPositionWithListParamTest() {
		list.add(0, list);
		
		assertNotNull(list);
	}

	/**
	 * Given: a list with elements
	 * When: add(int index, Object element) is invoked on the last element
	 * Then: the list adds the object on the last position
	 */
	@Test
	public void addInPositionInTheLastPositionTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );
		
		list.add(list.size() - 1, "E");
		
		assertTrue( list.size() == 5 );
		assertTrue( list.contains( "E" ) );
		assertEquals( list.get(list.size() - 1) , "E" );
		assertEquals( "A,B,C,D,E" , list.toString());
	}
	
	/**
	 * GIVEN: Una lista 
	 * WHEN: Llamamos al m�todo add con 2 par�metros, uno de ello correcto 
	 * (el elemento a a�adir) y otro de ellos incorrecto
	 * ( se le pasa una posici�n negativa)
	 * THEN: Nos salta un IllegalArgumentException
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void addInPositionWithNegativePositionParamTest() {
		Object object = new Object();
		list.add(-2, object);
	}
	
	/**
	 * GIVEN: Una lista
	 * WHEN: Llamas al metodo add()
	 * THEN: Salta una excepcion y la lista se queda igual
	 */
	@Test
	public void addInPositionWithTooHighPositionParamTest() {
		Object o = new Object();
		int position = list.size()+1;
		String ini = list.toString();
		int inisize = list.size();
		try {
			list.add(position,o);
			
		}
		catch(IndexOutOfBoundsException e) {
			String fin = list.toString();
			int finsize = list.size();
			assertEquals(fin,ini);
			assertEquals(inisize,finsize);
		}
	}
}
