package uo.mp.collections.testcases;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;



public class IteratorTests {

	private List list;
	
	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: an iterator from a new list
	 * When: hasNext() is called
	 * Then: returns false 
	 */
	@Test
	public void hasNextReturnsFalseOnEmptyList() {
		Iterator<Object> it = list.iterator();
		assertFalse(it.hasNext());
	}
	
	/**
	 * Given: a new iterator with one element in the list
	 * When: hasNext() is called 
	 * Then: returns true 
	 */
	@Test
	public void hasNextReturnsTrueOnNewIteratorWithOneElement() {
		list.add("X");
		Iterator<Object> it = list.iterator();
		assertTrue(it.hasNext());
	}
	
	/**
	 * Given: a new iterator from a list with several element
	 * When: hasNext() is called 
	 * Then: returns true 
	 */
	@Test
	public void hasNextReturnsTrueOnNewIteratorWithSeverealElements() {
		list.add("X");
		list.add("Y");
		list.add("Z");
		Iterator<Object> it = list.iterator();
		assertTrue(it.hasNext());
	}
	
	/**
	 * Given: a iterator over the first position of a list with two elements
	 * When: hasNext() is called
	 * Then: returns true 
	 */
	@Test
	public void hasNextReturnsTrueOnTheFirstElementOfaList() {
		fail();

	}

	/**
	 * Given: a iterator over the last position of a list 
	 * When: hasNext() is called
	 * Then: returns false
	 */
	@Test
	public void hasNextReturnsFalseOnTheLastElementOfaList() {
		fail();

	}
	
	/**
	 * Given: a iterator over an empty list 
	 * When: next() is called
	 * Then: a NoSuchElementException is thrown 
	 */
	@Test
	public void nextThrowsExceptionOnEmptyList() {
		fail();
	}

	/**
	 * Given: a iterator over an list with one element 
	 * When: next() is called
	 * Then: the first element is returned 
	 */
	@Test( )
	public void nextWithOneElemerntOnAList() {
		fail();

	}

	/**
	 * Given: a iterator over an list with one element 
	 * When: next() is called twice
	 * Then: a NoSuchElementException is thrown
	 */
	@Test
	public void nextTwiceWithOneElementOnAList() {
		fail();

	}
	
	/**
	 * Given: an empty list  
	 * When: a for each loop is executed
	 * Then: the loop do not iterate
	 */
	@Test
	public void useForEachOnEmptyList() {
		fail();

	}
	
	/**
	 * Given: a list with several elements  
	 * When: a for each loop is executed
	 * Then: the loop return each element
	 */
	@Test
	public void useForEachOnListWithElements() {
		fail();

	}
	
}