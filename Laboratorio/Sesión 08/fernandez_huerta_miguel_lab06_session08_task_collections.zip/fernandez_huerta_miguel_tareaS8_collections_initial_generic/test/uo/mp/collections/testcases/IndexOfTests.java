package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class IndexOfTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: an empty list
	 * When: indexOf(Object o) is invoked
	 * Then: returns index -1, because the object doesn't exist
	 */
	@Test
	public void indexOfWithAlreadyEmptyListTest() {
		assertEquals( -1, list.indexOf( "A" ) );
		
		assertTrue( list.size() == 0 );
		
		assertTrue( list.contains( "A" ) == false );
		
		assertEquals( "" , list.toString());
	}
	
	/**
	 * GIVEN: Una lista con 3 objetos repetidos
	 * WHEN: Llamas al metodo indexOf, con 1 objeto
	 * THEN: Devuelve la posicion del primer objeto
	 */
	@Test
	public void indexOfWithCorrectParamTest() {
		Object o=new Object();
		Object p=new Object();
		Object q=new Object();
		
		list.add(o);
		list.add(p);
		list.add(q);
		list.add(q);
		
		int result = list.indexOf(q);
		
		assertEquals(result,2);
		assertEquals(list.size(),4);
	}

}
