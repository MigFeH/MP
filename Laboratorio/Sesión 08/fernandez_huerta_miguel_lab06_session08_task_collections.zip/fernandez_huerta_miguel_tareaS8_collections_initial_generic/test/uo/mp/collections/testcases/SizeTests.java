package uo.mp.collections.testcases;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class SizeTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
