/**
 * 
 */
package uo.mp.util;

/**
 * @author mp
 *
 */
public class ArgumentsCheck {
	
	/**
	 * Checks whether the condition is true or false. When false, throws an
	 * IllegalArgumentException with the argument msg  
	 * 
	 * @param condition
	 * @param msg
	 */
	public static void isTrue(boolean condition, String msg) {
		if (!condition) {
			throw new IllegalArgumentException(msg);
		}
	}
	
	/**
	 * Checks whether the condition is true or false. When false, throws an
	 * IllegalArgumentException 
	 * 
	 * @param condition
	 */
	public static void isTrue(boolean condition) {
		if (!condition) {
			throw new IllegalArgumentException();
		}
	}
	
	public static void isValidPosition(int position, int size) {
		if (position < 0 || position >= size) {
			throw new IndexOutOfBoundsException();
		}
	}
	

}
