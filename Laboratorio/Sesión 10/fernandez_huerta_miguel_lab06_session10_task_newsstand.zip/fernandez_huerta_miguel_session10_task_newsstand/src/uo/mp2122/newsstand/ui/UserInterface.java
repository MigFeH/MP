package uo.mp2122.newsstand.ui;

import java.io.FileNotFoundException;
import java.util.List;

import uo.mp2122.newsstand.domain.Publication;
import uo.mp2122.newsstand.service.Newsstand;
import uo.mp2122.newsstand.service.NewsstandException;
import uo.mp2122.newsstand.ui.console.Console;
import uo.mp2122.util.log.Logger;

/**
 * It is in charge of interacting with the user:
 * 	- Shows the menu of options
 *  - Process the option chosen by the user
 *  	- For that it asks the user the necessary data to fulfill the request
 *  	- Shows the result of the request
 *  - In case of error shows an explaining message
 *  
 *  Note: This is the unique class allowed to show information to the user
 */
public class UserInterface {
	private static final int EXIT = 0;

	private Menu menu = new Menu();
	private Newsstand newsStand = new Newsstand();
	
	public void show()  {
		try {
			int option = EXIT;
			do {
				menu.show();
				option = menu.readOption();
				processOption(option);
			} while (option != EXIT);
		} catch (NewsstandException | FileNotFoundException e) // errores de usuario
		{
			handleUserError(e);
		} catch (RuntimeException e) // errores de programación o de sistema
		{
			handleSystemError(e);
			return;
		}
		
	}

	private void handleUserError(Exception e) {
		Console.println(e.getMessage());
	}

	private void handleSystemError(RuntimeException e) {
		Console.println("ERROR IRRECUPERABLE, AVISE AL ADMINISTRADOR.\n" + e.getMessage());
		Logger.log(e.getMessage());
		Logger.log(e); // le da por parámetro la traza de ejecución
		
	}

	private void processOption(int option) throws NewsstandException, FileNotFoundException {
		switch( option ) {
			case EXIT: return;
			case 1: loadFile(); break;
			case 2: showPublications(); break;				
			case 3: addPublication(); break;
			case 4: removePublication(); break;				
			case 5: createOrders(); break; 				
			case 6: saveOrdersToFile(); break;
			case 7: importFromZip(); break;
			case 8: exportToZip(); break;
		}
	}

	private void loadFile() throws NewsstandException, FileNotFoundException {
		String fileName = Console.readString("File name?");
		int attempts = 1;
		if (fileName.length() < 5) // nombre con menos de 5 caracteres...
		{
			while (fileName.length() < 5)
			{
				System.err.println("Nombre no válido por tener menos de 5 carácteres, prueba con otro nombre");
				String fileName2 = Console.readString("File name?");
				fileName = fileName2;
				attempts++;
				if (attempts == 5) // si ya no quedan intentos..
				{
					show();
					break;
				}
			}
		}
		newsStand.loadFile( fileName );
	}
	
	private void addPublication() {
		Publication p = new PublicationForm().askForPublication();
		try {
			newsStand.addPublication( p );
		} catch (NewsstandException e)
		{
			Logger.log("RECOVERABLE ERROR. <" + e.getMessage() + ">");
		} catch (IllegalArgumentException e)
		{
			Logger.log(e.getMessage());
		}
		
	}

	private void removePublication() throws NewsstandException {
		String name = Console.readString("publication name?");
		newsStand.removePublication( name );
		
	}
	
	private void showPublications() {
		List<Publication> publications = newsStand.getPublications();
		listPublications( publications );
	}

	private void createOrders() {
		newsStand.createOrders();
	}

	private void listPublications(List<Publication> publications) {
		Console.println("\nList of publications");
		Console.println("------------------");
		for (Publication p: publications) {
			System.out.println( p );
		}
	
		Console.println("------------------");
   }	
	
	private void saveOrdersToFile() throws NewsstandException {
		String fileName = Console.readString("output file name?");
		newsStand.saveOrdersToFile( fileName );
	}
	
	private void importFromZip() throws NewsstandException {
		String fileName = Console.readString("input zip file name?");
		newsStand.importPublicationsFromZipFile( fileName );
	}
	
	private void exportToZip() throws NewsstandException {
		String fileName = Console.readString("output file name?");
		newsStand.exportPublicationsToZipFile( fileName );
	}

}
