package uo.mp2122.util.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import uo.mp.util.ArgumentsCheck;
import uo.mp2122.newsstand.service.NewsstandException;

/**
 * A utility class to read/write text lines 
 * from/to a compressed text file (.txt.gz) 
 */
public class ZipFileUtil {

	public List<String> readLines(String inFileName) throws IOException {
		ArgumentsCheck.isTrue(inFileName != null && !inFileName.isBlank());
		
		List<String> res = new LinkedList<>();
		
		/* Lee líneas a partir de un "lector" de caracteres */
		BufferedReader in = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(inFileName))));

		try {
			try {
				while (in.ready()) // mientras haya mas bytes o caracteres a leer o preparado para leer...
				{
					res.add(in.readLine());
				}
			} finally {
				in.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException(e);
		}
		
		return res;
	}

	public void writeLines(String outZippedFileName, List<String> lines) throws NewsstandException {
		ArgumentsCheck.isTrue(outZippedFileName != null && !outZippedFileName.isBlank());
		
		try {
			BufferedWriter out = new BufferedWriter(
					new OutputStreamWriter(
							new GZIPOutputStream(
									new FileOutputStream(outZippedFileName))));
			try {
				for (String line : lines)
				{
					out.write(line);
					out.newLine();
				}
			} finally {
				out.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException();
		}

	}
}
