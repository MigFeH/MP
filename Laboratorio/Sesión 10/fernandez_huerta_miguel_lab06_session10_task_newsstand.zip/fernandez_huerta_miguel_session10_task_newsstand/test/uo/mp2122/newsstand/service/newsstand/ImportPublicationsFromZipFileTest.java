package uo.mp2122.newsstand.service.newsstand;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp2122.newsstand.service.Newsstand;
import uo.mp2122.newsstand.service.NewsstandException;

public class ImportPublicationsFromZipFileTest {
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, vacío
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithEmptyFileName()
	{
		Newsstand ns = new Newsstand();
		try {
			ns.importPublicationsFromZipFile("");
		} catch(NewsstandException e)
		{
			assertEquals("Nombre de fichero del que importar publicaciones no válido", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, null
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithNullFileName()
	{
		Newsstand ns = new Newsstand();
		try {
			ns.importPublicationsFromZipFile(null);
		} catch(NewsstandException e)
		{
			assertEquals("Nombre de fichero del que importar publicaciones no válido", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, correcto
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithCorrectFileName()
	{
//		Newsstand ns = new Newsstand();
//		try {
//			ns.importPublicationsFromZipFile();
//		} catch(NewsstandException e)
//		{
//			
//		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, correcto pero con 
	 * publicaciones de tipos desconocidos
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithCorrectFileNameAndUnknownPublicationTypes()
	{
//		Newsstand ns = new Newsstand();
//		try {
//			ns.importPublicationsFromZipFile();
//		} catch(NewsstandException e)
//		{
//			
//		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, correcto pero conteniendo 
	 * líneas vacías
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithCorrectFileNameAndEmptyLines()
	{
//		Newsstand ns = new Newsstand();
//		try {
//			ns.importPublicationsFromZipFile();
//		} catch(NewsstandException e)
//		{
//			
//		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, correcto pero conteniendo 
	 * datos numéricos no válidos
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithCorrectFileNameAndInvalidNumbers()
	{
//		Newsstand ns = new Newsstand();
//		try {
//			ns.importPublicationsFromZipFile();
//		} catch(NewsstandException e)
//		{
//			
//		}
	}
	
	/**
	 * GIVEN: Nombre de fichero, del que importar las publicaciones, correcto pero conteniendo 
	 * un número de campos de las publicaciones no válido
	 * WHEN: Se invoca al método ImportPublicationsFromZipFile()
	 * THEN: Lanza NewsstandException
	 */
	@Test
	public void testImportPublicationsFromZipFileWithCorrectFileNameAndInvalidNumberOfFields()
	{
//		Newsstand ns = new Newsstand();
//		try {
//			ns.importPublicationsFromZipFile();
//		} catch(NewsstandException e)
//		{
//			
//		}
	}

}
