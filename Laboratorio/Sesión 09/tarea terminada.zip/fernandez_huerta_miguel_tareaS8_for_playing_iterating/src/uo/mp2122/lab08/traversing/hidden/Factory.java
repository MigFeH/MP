package uo.mp2122.lab08.traversing.hidden;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class Factory {

	public static Collection getAnimals() {
		Collection animals = new LinkedList();
		animals.add("Horse");
		animals.add("Lion");
		animals.add("Tiger");
		return animals;

	}
}
