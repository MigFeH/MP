package uo.mp.collections.testcases;

import static org.junit.Assert.assertTrue;



import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;
import uo.mp.collections.impl.*;



public class EqualsTests {
	
	private List list;
	private List other;

	@Before
	public void setUp() throws Exception {
//		list = Settings.factory.newList();
//		other = Settings.factory.newList();
		list = Settings.list;
		list.clear();
		other = Settings.other;
		other.clear();
	}


	/**
	 * GIVEN: two empty lists  
	 * THEN: they are equal
	 */
	@Test
	public void testEmpty() {
		assertTrue(list.equals(other));
		assertTrue(other.equals(list));
	}
	
	/**
	 * GIVEN: two non empty lists, different size  
	 * THEN: they are not equal
	 */
	@Test
	public void difSize() {
		list.add( "testing" );
		list.add( "with" );
		list.add( "JUnit" );
		list.add( "framework" );

		other.add( "testing" );
		other.add( "with" );
		other.add( "JUnit" );

		assertTrue(list.equals(other) == false);
		assertTrue(other.equals(list) == false);
	}
	
	/**
	 * GIVEN: two non empty lists, containing the same elements, in the
	 * same order  
	 * THEN: they are equal
	 */
	@Test
	public void sameLists() {
		list.add( "testing" );
		list.add( "with" );
		list.add( "JUnit" );
		list.add( "framework" );

		other.add( "testing" );
		other.add( "with" );
		other.add( "JUnit" );
		other.add( "framework" );
	
		assertTrue(list.equals(other));
		assertTrue(other.equals(list));
	}	
	
	/**
	 * GIVEN: two non empty lists, containing the same elements, in different
	 * order  
	 * THEN: they are not equal
	 */
	@Test
	public void notSameLists() {
		list.add( "testing" );
		list.add( "with" );
		list.add( "JUnit" );
		list.add( "framework" );

		other.add( "framework" );
		other.add( "testing" );
		other.add( "with" );
		other.add( "JUnit" );
		other.add( "framework" );

		
		assertTrue(list.equals(other) == false);
		assertTrue(other.equals(list) == false);
	}	

	/**
	 * GIVEN: a list and a container different type
	 * THEN: they are not equal
	 */
	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void checkDiffType() {
		String[] s = new String[] {"testing", "with", "JUnit", "framework"};

		assertTrue(list.equals(s) == false);
		assertTrue(s.equals( list ) == false);
	}
	
	/**
	 * GIVEN: two non empty lists, one of type ArrayList and the other of type
	 * LinkedList, with the same elements, in the same positions
	 * THEN: they are equal
	 */
	@Test
	public void checkDifferentImplementationsAreEquals() {
		List al = new ArrayList();
		List ll = new LinkedList();
		al.add( "A" );
		al.add( "B" );
		ll.add( "A" );
		ll.add( "B" );
		
		assertTrue( al.equals( ll ) );
		assertTrue( ll.equals( al ) );
	}
	
	/**
	 * GIVEN: two empty lists, one of type ArrayList and the other of type
	 * LinkedList
	 * THEN: they are equal
	 */
	@Test
	public void checkDifferentEptyImplementationsAreEquals() {
		List al = new ArrayList();
		List ll = new LinkedList();

		assertTrue( al.equals( ll ) );
		assertTrue( ll.equals( al ) );
	}
	
	/**
	 * GIVEN: two non empty lists, one of type ArrayList and the other of type
	 * LinkedList, with the same elements, in different positions
	 * THEN: they are not equal
	 */
	@Test
	public void checkDifferentImplementationsAreNotEquals() {
		List al = new ArrayList();
		List ll = new LinkedList();
		al.add( "A" );
		al.add( "B" );
		ll.add( "B" );
		ll.add( "A" );
		
		assertTrue( al.equals( ll ) == false );
		assertTrue( ll.equals( al ) == false );
	}
	
	/**
	 * GIVEN: two empty lists, one of type ArrayList and the other of type
	 * LinkedList
	 * THEN: they are not equal
	 */
	@Test
	public void checkDifferentNotEmptyImplementationsAreNotEquals() {
		List al = new ArrayList();
		List ll = new LinkedList();
		al.add( "A" );
		al.add( "B" );
		ll.add( "A" );
		ll.add( "C" );

		assertTrue( al.equals( ll ) == false );
		assertTrue( ll.equals( al ) == false );
	}
	
	/**
	 * GIVEN: an ArrayList with elements
	 * THEN: is equals to itself
	 */
	@Test
	public void checkArrayListSelfEqualityWithElements() {
		List al = new ArrayList();
		al.add( "A" );
		al.add( "B" );
		
		assertTrue( al.equals( al ) );
	}
	
	/**
	 * GIVEN: an empty ArrayList
	 * THEN: is equals to itself
	 */
	@Test
	public void checkArrayListSelfEqualityEmpty() {
		List al = new ArrayList();
		
		assertTrue( al.equals( al ) );
	}
 
	/**
	 * GIVEN: a LinkedList with elements
	 * THEN: is equals to itself
	 */
	@Test
	public void checkLinkedListSelfEqualityWithElements() {
		List al = new LinkedList();
		al.add( "A" );
		al.add( "B" );
		
		assertTrue( al.equals( al ) );
	}
	
	/**
	 * GIVEN: an empty LinkedList
	 * THEN: is equals to itself
	 */
	@Test
	public void checkLinkedListSelfEqualityEmpty() {
		List al = new ArrayList();
		
		assertTrue( al.equals( al ) );
	}
}
