package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class RemoveObjectTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: remove() is invoked with an object as parameter
	 * Then: the first element is removed
	 */
	@Test
	public void removeObjectWithFirstObjectParamTest() {
		list.add("A");
		list.add("B");
		
		assertTrue(list.remove("A"));
		
		assertFalse(list.contains("A"));
		assertEquals(1, list.size());
	}
	
	/**
	 * GIVEN: una lista
	 * WHEN: se llama al m�todo removeObject con par�metro un objeto que no
	 * est� en la lista
	 * THEN: no hay cambios en la lista
	 */
	@Test
	public void removeObjectWithNonExistingObjectInListTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );
		assertEquals(4, list.size());
		assertFalse(list.remove("E"));
		assertEquals(4, list.size());
	}
	
	/**
	 * GIVEN: Una lista con 1 objeto
	 * WHEN: Llamas al metodo removeObject, con el objeto
	 * THEN: Devuelve true y la lista queda vacia
	 */
	@Test
	public void removeObjectWithOnlyOneObjectTest() {
		Object o=new Object();
		
		list.add(o);
		
		boolean result = list.remove(o);
		
		assertTrue(result);
		assertEquals(list.size(),0);
	}

}
