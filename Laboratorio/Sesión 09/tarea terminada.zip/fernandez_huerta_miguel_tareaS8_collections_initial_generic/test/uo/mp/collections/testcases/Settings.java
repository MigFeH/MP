package uo.mp.collections.testcases;

import uo.mp.collections.List;

public class Settings {
	
	public static List list;
	public static List other;  

}
