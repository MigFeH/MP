package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class SetTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: an empty list
	 * When: set() is invoked with 0 as parameter
	 * Then: throws IllegalArgumentException... si partimos de una lista vac�a
	 * y le hacemos el set en la posici�n 0 el elemento pasado como par�metro
	 * se a�adir� en la posici�n 0 de la lista; NO SALTAR� EXCEPCI�N
	 */
	@Test
	public void setInZeroPositionWithEmptyListTest() {

			list.set(0, "a");
	}
	
	/**
	 * GIVEN: un �ndice negativo
	 * WHEN: se llama al m�todo set
	 * THEN: salta excepci�n
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void setInNegativePositionTest() {
		list.set(-1, "A");
	}
	
	/**
	 * Given: an empty list
	 * When: set is invoked with index size
	 * Then: throws IndexOutOfBoundsException
	 */
	@Test
	public void setPositionWithTooHighPositionParamTest() {
		try {
			list.set(list.size(), "A");
			//fail();
		}
		catch(Exception e){
			assertEquals("Index out of bounds", e.getMessage());
		}
	}
	
	/**
	 * Given: una lista
	 * When: se a�ade un elemento valido en la posici�n 0
	 * Then: Se a�ade el elemento en la posici�n 0 y devuelve el elemento que 
	 * ocupaba anteriormente esa posici�n
	 */
	@Test
	public void setPositionInZeroPositionTest() {
		Object object1 = new Object();
		Object object2 = new Object();
		
		list.add(0, object1);
		
		assertEquals(object1, list.set(0,object2));
		assertEquals(object2, list.get(0));
	}
	
	/**
	 * GIVEN: Una lista con 3 objetos
	 * WHEN: Llamas al metodo set, con 1 objeto y una posicion
	 * THEN: Devuelve el objeto que estaba en la posicion y mete el que le
	 * pasamos en la lista
	 */
	@Test
	public void setWithCorrectObjectsTest() {
		Object o=new Object();
		Object p=new Object();
		Object q=new Object();
		
		list.add(o);
		list.add(p);
		list.add(q);
		
		Object result = list.set(2,o);
		
		assertEquals(result,q);
		assertEquals(list.get(2),o);
		assertEquals(list.size(),3);
	}
}
