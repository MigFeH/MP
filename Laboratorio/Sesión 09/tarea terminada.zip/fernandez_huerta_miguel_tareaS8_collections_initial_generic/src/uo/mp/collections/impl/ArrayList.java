package uo.mp.collections.impl;

import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.collections.List;
import uo.mp.util.ArgumentsCheck;

public class ArrayList<T> extends AbstractList<T> {
	
	private static final int INITIAL_CAPACITY = 20; /* capacidad inicial del 
														vector interno */
	
	private T[] elements; // vector de objetos object
	
	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param la capacidad inicial del vector interno
	 */
	@SuppressWarnings("unchecked")
	public ArrayList(int capacity)
	{
		ArgumentsCheck.isTrue(capacity > 0, "Capacidad inicial no v�lida");
		
		elements = (T[]) new Object[capacity];
		setNumberOfElements(0);
	}
	
	/**
	 * Constructor de la clase sin par�metros
	 */
	public ArrayList()
	{
		this(INITIAL_CAPACITY);
	}

	/**
	 * Busca en la lista un objeto no nulo y retorna true si dicho objeto est�
	 * en la lista o false si no lo est�
	 * 
	 * @return true o false dependiendo de lo antes mencionado
	 */
	@Override
	public boolean contains(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscar pero fue null");
		
		if (! isEmpty()) // lista no vac�a...
		{
			for (int i = 0; i < size(); i++)
			{
				if (elements[i].equals(o)) // son iguales...
				{
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * A�ade un elemento no nulo a la lista de objetos en la �ltima posici�n de 
	 * �sta y retorna true porque �ste tipo de lista no admite elementos 
	 * repetidos
	 * 
	 * @param el objeto a a�adir
	 * @return true por no permitir elementos repetidos
	 */
	@Override
	public boolean add(T element) {
		ArgumentsCheck.isTrue(element != null, 
				"Esperaba elemento a a�adir en la lista en la �ltima posici�n "
				+ "pero fue null");
		
		if (size() == 0) // si no hay elementos en la lista...
		{
			elements[0] = element;
			setNumberOfElements(1);
			
			return true;
		}
		
		setNumberOfElements(getNumberOfElements() + 1);
		elements[size() - 1] = element;
		
		return true;
	}

	/**
	 * Borra un elemento no nulo de la lista de objetos y retorna true si el 
	 * elemento que se iba a borrar estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a borrar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean remove(T o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a borrar de la lista en la �ltima posici�n "
				+ "pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			remove(indexOf(o));
			return true;
		}
		return false;
	}

	/**
	 * Limpia la lista por completo borrando todos los objetos que la contienen
	 */
	@Override
	public void clear() {
		for (int i = 0; i < size(); i++)
		{
			elements[i] = null;
		}
		setNumberOfElements(0);
	}

	/**
	 * Retorna un objeto de la lista de una posici�n dada como par�metro
	 * 
	 * @param la posici�n o �ndice en el que se encuentra el objeto
	 * @return el objeto que se ha encontrado en esa posici�n
	 */
	@Override
	public T get(int index) {
		ArgumentsCheck.isValid(index, size());
		
		if (! isEmpty()) // lista no vac�a...
		{
			T copy = elements[index];
			
			return copy;
		}
		
		throw new NullPointerException();
	}

	/**
	 * Sustituye en la lista a un objeto que estaba en una posici�n dada como
	 * par�metro por otro objeto dado como par�metro no nulo
	 * 
	 * Retorna el objeto de antes de haber sido sustituido por el del par�metro
	 * 
	 * @param el �ndice a colocar el objeto
	 * @param el elemento a colocar en la lista
	 * @return el anterior objeto en la posici�n de la lista
	 */
	@Override
	public T set(int index, T element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba el objeto a cambiar "
				+ "pero fue null");
		
		if (! isEmpty()) // lista no vac�a...
		{
			T aux = elements[index];
			elements[index] = element;
			
			return aux;
		}
		
		add(element);
		return null;
	}

	
	/**
	 * A�ade un objeto no nulo a la lista de elementos en un �ndice v�lido en la
	 * lista
	 * 
	 * @param el �ndice
	 * @param el elemento a a�adir
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void add(int index, T element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba elemento a a�adir en "
				+ "la lista pero fue null");
			
		if (index == size() - 1 || size() == 0) /* si es el �ltimo �ndice o 
		si no hay elementos en la tabla... */
		{
			add(element);
		}
		else {
			setNumberOfElements(getNumberOfElements() + 1); /* se incrementa en una unidad el n�mero de 
			elementos en la lista */
			
			
			T[] aux = (T[]) new Object[size()]; // lista de objetos auxiliar
			
			for (int i = index + 1; i < size(); i++)
			{
				aux[i] = elements[i - 1]; /* cada objeto que est� en las
				siguientes posiciones de index ser� desplazado una posici�n */
			}
			aux[index] = element; /* se le asigna a la posici�n par�metro el 
			objeto par�metro */
			
			elements = aux; /* la lista de objetos ahora es la misma que la
			auxiliar con el nuevo objeto a�adido en la posici�n que deseaba */
		}
	}

	/**
	 * Borra de la lista de objetos un objeto de �sta en un �ndice dado como
	 * par�metro y retorna el objeto que ha sido borrado
	 * 
	 * @param el �ndice del objeto que se quiere borrar
	 * @return el objeto que ha sido borrado
	 */
	@Override
	public T remove(int index) {
		ArgumentsCheck.isValid(index, size());
		
		if (! isEmpty())
		{
			T copy = elements[index]; // salvamos el elemento que se borra

			if (index == size() - 1) // si es la �ltima posici�n...
			{
				elements[index] = null; // borramos elemento

				setNumberOfElements(getNumberOfElements() - 1); // decrementamos n�mero de objetos

				return copy; // retornamos objeto que ha sido borrado
			}

			elements[index] = null; // borramos elemento

			setNumberOfElements(getNumberOfElements() - 1); // decrementamos n�mero de objetos

			T[] aux = elements;

			int i = 0; /* posiciones a recorrer en aux (se le a�adir�n aquellos
			elementos de la lista "elements" que no sean null) */
			int j = 0; /* posiciones a recorrer en la lista */

			for (T theObject: elements)
			{
				if (theObject != null) // si el objeto no es null...
				{
					aux[i] = elements[j];
					i++; // siguiente posici�n en la auxiliar
				}
				j++; // siguiente posici�n en la lista
			}

			return copy; // retornamos el objeto que hab�a sido borrado
		}
		
		throw new NullPointerException();
	}

	/**
	 * Retorna el �ndice de un objeto no nulo en la lista, si el objeto no est�
	 * en la lista de objetos retorna -1
	 * 
	 * @param el objeto a buscarle el �ndice de su posici�n
	 * @return la posici�n en la que se encuentra el objeto
	 */
	@Override
	public int indexOf(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscarle el �ndice pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			for (int i = 0; i < size(); i++)
			{
				if (elements[i].equals(o)) /* si el objeto de la lista es el 
				mismo que el objeto par�metro... */
				{
					return i;
				}
			}
		}
		
		return -1;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public boolean equals(Object o) {
	if (o == null) return false;
	if (o == this) return true;
	if (!(o instanceof List)) return false;


	List<T> that = (List<T>) o;
	if ( this.size() != that.size() ) return false;

	for(int i = 0; i < size(); i++) {
	T e1 = this.get( i );
	T e2 = (T) that.get( i );
	if (!(e1.equals(e2)))
	return false;
	}
	return true;
	}
	
	@Override
	public int hashCode() {
	int result = 1;
	for (int i = 0; i < size(); i++) {
	T element = this.get( i );
	result = 31 * result + (element.hashCode());
	}
	return result;
	}

	@Override
	public String toString() {
		String data = "";
		
		for (int i = 0; i < size(); i++)
		{
			if (i == size() - 1)
			{
				data = data + elements[i];
				break;
			}
			
			data = data + elements[i] + ",";
		}
		
		return data;
	}

	@Override
	public Iterator<T> iterator() {
		return new ArrayListIterator();
	}
	
	
	private class ArrayListIterator implements Iterator<T>
	{
		private int index;
		private T lastReturned;
		
		ArrayListIterator()
		{
			index = 0;
			lastReturned = null;
		}
		
		@Override
		public boolean hasNext() {
			return index < size();
		}

		@Override
		public T next() {
			
			if (hasNext())
			{
				lastReturned = elements[index];
				index++;
				return lastReturned;
			} else {
				throw new NoSuchElementException();
			}
			
			
		}
		
	}

}
