package uo.mp2122;

import uo.mp2122.newsstand.ui.UserInterface;

public class Main {

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		new UserInterface().show();
	}

}
