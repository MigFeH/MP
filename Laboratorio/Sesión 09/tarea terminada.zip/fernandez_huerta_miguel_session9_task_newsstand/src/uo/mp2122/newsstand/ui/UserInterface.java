package uo.mp2122.newsstand.ui;

import java.io.IOException;
import java.util.List;

import uo.mp2122.newsstand.domain.Publication;
import uo.mp2122.newsstand.service.Newsstand;
import uo.mp2122.newsstand.service.NewsstandException;
import uo.mp2122.newsstand.ui.console.Console;
import uo.mp2122.util.log.Logger;

/**
 * It is in charge of interacting with the user:
 * 	- Shows the menu of options
 *  - Process the option chosen by the user
 *  	- For that it asks the user the necessary data to fulfill the request
 *  	- Shows the result of the request
 *  - In case of error shows an explaining message
 *  
 *  Note: This is the unique class allowed to show information to the user
 */
public class UserInterface {
	private static final int EXIT = 0;

	private Menu menu = new Menu();
	private Newsstand newsStand = new Newsstand();
	
	public void show()  {
		try {
			int option = EXIT;
			do {
				menu.show();
				option = menu.readOption();
				processOption(option);
			} while (option != EXIT);
		} catch (RuntimeException e)
		{
			Logger.log("Se ha producido un error interno");
			//Logger.log(e.getStackTrace());
		} catch (IOException e)
		{
			Logger.log("Se ha producido un error interno");
		}
		
	}

	private void processOption(int option) throws IOException {
		switch( option ) {
			case EXIT: return;
			case 1: loadFile(); break;
			case 2: showPublications(); break;				
			case 3: addPublication(); break;
			case 4: removePublication(); break;				
			case 5: createOrders(); break; 				
			case 6: saveOrdersToFile(); break;
			case 7: importFromZip(); break;
			case 8: exportToZip(); break;
		}
	}

	private void loadFile() throws IOException {
		String fileName = Console.readString("File name?");
		int attempts = 1;
		if (fileName.length() < 5) // nombre con menos de 5 caracteres...
		{
			while (fileName.length() < 5)
			{
				System.err.println("Nombre no válido por tener menos de 5 carácteres, prueba con otro nombre");
				String fileName2 = Console.readString("File name?");
				fileName = fileName2;
				attempts++;
				if (attempts == 5) // si ya no quedan intentos..
				{
					show();
					break;
				}
			}
		}
		try {
			newsStand.loadFile( fileName );
		} catch (NewsstandException e)
		{
			Logger.log(e.getMessage());
		}
		
	}
	
	private void addPublication() {
		Publication p = new PublicationForm().askForPublication();
		try {
			newsStand.addPublication( p );
		} catch (NewsstandException e)
		{
			Logger.log("RECOVERABLE ERROR. <" + e.getMessage() + ">");
		} catch (IllegalArgumentException e)
		{
			Logger.log(e.getMessage());
		}
		
	}

	private void removePublication() {
		String name = Console.readString("publication name?");
		try {
			newsStand.removePublication( name );
		} catch (NewsstandException e)
		{
			Logger.log(e.getMessage());
		}
		
	}
	
	private void showPublications() {
		List<Publication> publications = newsStand.getPublications();
		listPublications( publications );
	}

	private void createOrders() {
		newsStand.createOrders();
	}

	private void listPublications(List<Publication> publications) {
		Console.println("\nList of publications");
		Console.println("------------------");
		for (Publication p: publications) {
			System.out.println( p );
		}
	
		Console.println("------------------");
   }	
	
	private void saveOrdersToFile() throws IOException {
		String fileName = Console.readString("output file name?");
		try {
			newsStand.saveOrdersToFile( fileName );
		} catch(NewsstandException e)
		{
			Logger.log(e.getMessage());
		}
	}
	
	private void importFromZip() {
		String fileName = Console.readString("input zip file name?");
		newsStand.importPublicationsFromZipFile( fileName );
	}
	
	private void exportToZip() throws IOException {
		String fileName = Console.readString("output file name?");
		newsStand.exportPublicationsToZipFile( fileName );
	}

}
