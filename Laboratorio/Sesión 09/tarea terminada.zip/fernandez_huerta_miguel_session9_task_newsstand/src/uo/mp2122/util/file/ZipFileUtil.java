package uo.mp2122.util.file;



import java.io.IOException;
import java.util.List;

import uo.mp2122.newsstand.exception.NotYetImplementedException;

/**
 * A utility class to read/write text lines 
 * from/to a compressed text file (.txt.gz) 
 */
public class ZipFileUtil {

	public List<String> readLines(String inFileName) throws IOException {
		if (inFileName == null || inFileName.isEmpty()) // nombre de fichero no válido...
		{
			throw new IOException();
		}
		throw new NotYetImplementedException();
	}

	public void writeLines(String outZippedFileName, List<String> lines) throws IOException {
		if (outZippedFileName == null || outZippedFileName.isEmpty()) // nombre de fichero no válido...
		{
			throw new IOException();
		}
		throw new NotYetImplementedException();
	}

}
