package uo.mp.newsstand.service.newsstand;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CreateOrdersTest.class })
public class AllTests {

}
