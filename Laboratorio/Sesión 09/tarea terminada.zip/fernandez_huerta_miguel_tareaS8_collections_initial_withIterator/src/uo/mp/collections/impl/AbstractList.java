package uo.mp.collections.impl;

import uo.mp.collections.List;
import uo.mp.util.ArgumentsCheck;

public abstract class AbstractList implements List{
	
	private int numberOfElements; // n�mero de elementos en la lista

	
	
	public int getNumberOfElements() {
		int copy = numberOfElements;
		return copy;
	}

	protected void setNumberOfElements(int numberOfElements) {
		ArgumentsCheck.isTrue(numberOfElements >= 0);
		this.numberOfElements = numberOfElements;
	}

	/**
	 * Retorna el n�mero de elementos que hay en la lista
	 * 
	 * @return el n�mero de elementos
	 */
	@Override
	public int size() {
		int copy = getNumberOfElements();
		return copy;
	}
	
	/**
	 * Retorna true si la lista est� vac�a (n�mero de elementos = 0),
	 * retorna false en caso contrario
	 * 
	 * @return true o false dependiendo de lo antes mencionado
	 */
	@Override
	public boolean isEmpty() {
		return size() == 0; // retorna true si size() es igual a 0; false si no
	}
	
	public abstract boolean contains(Object o);
	
	public abstract boolean add(Object element);
	
	public abstract boolean remove(Object o);
	
	public abstract void clear();
	
	public abstract Object get(int index);
	
	public abstract Object set(int index, Object element);
	
	public abstract void add(int index, Object element);
	
	public abstract Object remove(int index);
	
	public abstract int indexOf(Object o);
	
	public abstract String toString();

}
