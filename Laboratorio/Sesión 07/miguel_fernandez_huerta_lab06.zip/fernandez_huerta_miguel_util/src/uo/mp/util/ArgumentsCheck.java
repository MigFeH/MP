package uo.mp.util;

public class ArgumentsCheck {
	
	/**
	 * Si no cumple la condici�n recibida, salta excepci�n 
	 * IllegalArgumentException con el mensaje recibido
	 * @param condition
	 * @param msg
	 */
	public static void isTrue(boolean condition, String msg)
	{
		if(!condition)
		{
			throw new IllegalArgumentException(msg);
		}
	}
	
	/**
	 * Si no cumple la condici�n recibida, salta excepci�n 
	 * IllegalArgumentException con el mensaje recibido
	 * @param condition
	 */
	public static void isTrue(boolean condition)
	{
		if(!condition)
		{
			throw new IllegalArgumentException();
		}
	}
	
	
	/**
	 * Si el index es menor que cero o mayor que size, 
	 * salta una excepci�n indexOutOfBounds
	 * @param index
	 * @param size
	 */
	public static void isValid(int index, int size)
	{
		if(index < 0 || index > size)
		{
			throw new IndexOutOfBoundsException();
		}
	}
}
