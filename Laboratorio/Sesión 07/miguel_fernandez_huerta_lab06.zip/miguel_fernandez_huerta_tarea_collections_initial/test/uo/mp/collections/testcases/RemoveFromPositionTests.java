package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class RemoveFromPositionTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: remove() is invoked with a position (0) as parameter
	 * Then: the first element is removed
	 */
	@Test
	public void removeFromPositionInFirstPositionTest() {
		list.add("A");
		list.add("B");
		
		assertEquals("A", list.remove(0));
		
		assertFalse(list.contains("A"));
		assertEquals(1, list.size());
	}

	/**
	 * Given: 
	 * When: se invoca al m�todo removeFromPosition en una posici�n cualquiera
	 * v�lida
	 * Then: se borra el elemento de la posici�n se�alada
	 */
	@Test
	public void removeFromPositionWithCorrectPositionTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );
		assertEquals(4, list.size());
		assertEquals( "D" , list.remove(3));
		assertEquals(3, list.size());
	}
	
	/**
	 * Given: a list
	 * When: remove() is invoked
	 * Then: throws IndexOutOfBoundsException
	 */
	@Test
	public void removeFromPositionWithNegativePositionParamTest() {
		try {
			list.remove(-1);
			fail();
		}
		catch(Exception e){
			assertEquals("Index out of bounds", e.getMessage());
		}
	}
	
	/**
	 * Given: an empty list 
	 * When: try to invoke remove(0) 
	 * Then: launch IndexOutOfBoundsException
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void removeFromPositionWithAlreadyEmptyListTest() {
		list.remove(0);
	}
	
	/**
	 * Given: an empty list
	 * When: remove(size()) is invoked
	 * Then: throw  IndexOutOfBoundsException
	 */
	@Test
	public void removeFromPositionWhithAlreadyEmptyListAndInvalidParamTest() {
		
		list.clear();
		
		try {
			list.remove(list.size());
			fail();
			
		} catch (Exception e) {
			throw new  IndexOutOfBoundsException();
		}
	}
	
}
