package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class ContainsTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: contains() is invoked with an object that does not contain
	 * Then: returns false
	 */
	@Test
	public void containsWithNonExistingParamInListTest()
	{
		list.add("A");
		list.add("B");
		
		assertFalse(list.contains("C"));
	}
	
	/**
	 * GIVEN: una solo elemento
	 * WHEN: el m�todo contains es invocado con el elemento a�adido 
	 * anteriormente como par�metro
	 * THEN: retorna true
	 */
	@Test
	public void containsOneElementTest() {
		list.add("A");
		assertEquals("A", list.get(0));
	}
	
	/**
	 * Given: a list with several elements
	 * When: contains() is invoked
	 * Then: returns true if list contains the element
	 */
	@Test
	public void containsWithAlreadyFullListTest() {
		list.add( "A" );
		list.add( "B" );
		list.add( "C" );
		list.add( "D" );
		assertTrue( list.contains( "A" ) == true );
	}
	
	/**
	 * Given: an empty list
	 * When: contains(Object element) is invoked on null
	 * Then: the method returns false
	 */
	@Test
	public void containsWithAlreadyEmptyListTest() {
		assertFalse(list.contains(null));
		assertTrue(list.isEmpty());
		assertTrue(list.size() == 0);
		assertEquals( "[]" , list.toString());
	}

}
