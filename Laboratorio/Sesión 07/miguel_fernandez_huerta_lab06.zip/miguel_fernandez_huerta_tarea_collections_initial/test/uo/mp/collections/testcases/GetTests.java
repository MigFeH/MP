package uo.mp.collections.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;

public class GetTests {
	
	private List list;

	@Before
	public void setUp() throws Exception {
		list = Settings.list;
		list.clear();
	}

	/**
	 * Given: a list
	 * When: get() is invoked with index -1
	 * Then: throws IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void getWithInvalidPositionTest() {
		try
		{
			list.get(-1);
		}
		catch (IllegalArgumentException e)
		{
			// assertEquals("mensaje", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: posici�n negativa
	 * WHEN: se llama al m�todo getPosition
	 * THEN: salta excepci�n
	 */
	@Test
	(expected = IndexOutOfBoundsException.class)
	public void getPositionWithNegativeParamTest() {
		list.get(-1);
	}
	
	
	/**
	 * Given: an empty list
	 * When: get is invoked with index size
	 * Then: throws IndexOutOfBoundsException
	 */
	@Test
	public void getPositionWithTooHighIndexTest() {
		try {
			list.get(list.size());
			fail();
		}
		catch(Exception e){
			assertEquals("Index out of bounds", e.getMessage());
		}
	}
	
	/**
	 * GIVEN: Una lista vacia
	 * WHEN: Llamas al metodo get() en posicion 0
	 * THEN: Salta una excepcion y la lista se queda igual
	 */
	@Test
	public void getWithAlreadyEmptyListTest() {
			String ini = list.toString();
			int inisize = list.size();
			try {
				list.get(0);
				
			}
			catch(IndexOutOfBoundsException e) {
				String fin = list.toString();
				int finsize = list.size();
				assertEquals(fin,ini);
				assertEquals(inisize,finsize);
			}
		
	}
}
