package uo.mp.collections.impl;

import uo.mp.collections.List;
import uo.mp.util.ArgumentsCheck;

public class ArrayList extends AbstractList implements List {
	
	private static final int INITIAL_CAPACITY = 20; /* capacidad inicial del 
														vector interno */
	
	private Object[] elements; // vector de objetos object
	private int numberOfElements; // n�mero de elementos en la lista

	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param la capacidad inicial del vector interno
	 */
	public ArrayList(int capacity)
	{
		ArgumentsCheck.isTrue(capacity > 0, "Capacidad inicial no v�lida");
		
		elements = new Object[capacity];
		numberOfElements = 0;
	}
	
	/**
	 * Constructor de la clase sin par�metros
	 */
	public ArrayList()
	{
		this(INITIAL_CAPACITY);
	}
	
	/**
	 * Retorna el n�mero de elementos que hay en la lista
	 * 
	 * @return el n�mero de elementos
	 */
	@Override
	public int size() {
		int copy = this.numberOfElements;
		return copy;
	}

	/**
	 * Retorna true si la lista est� vac�a (n�mero de elementos = 0),
	 * retorna false en caso contrario
	 * 
	 * @return true o false dependiendo de lo antes mencionado
	 */
	@Override
	public boolean isEmpty() {
		return size() == 0; // retorna true si size() es igual a 0; false si no
	}

	/**
	 * Busca en la lista un objeto no nulo y retorna true si dicho objeto est�
	 * en la lista o false si no lo est�
	 * 
	 * @return true o false dependiendo de lo antes mencionado
	 */
	@Override
	public boolean contains(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscar pero fue null");
		
		if (isEmpty()) // si la lista est� vac�a...
		{
			return false;
		}
		
		for (int i = 0; i < size(); i++)
		{
			if (get(i).equals(o)) /* si el m�todo get devuelve un objeto igual 
			al del par�metro... */
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * A�ade un elemento no nulo a la lista de objetos en la �ltima posici�n de 
	 * �sta y retorna false porque �ste tipo de lista no admite elementos 
	 * repetidos
	 * 
	 * @param el objeto a a�adir
	 * @return false por no permitir elementos repetidos
	 */
	@Override
	public boolean add(Object element) {
		ArgumentsCheck.isTrue(element != null, 
				"Esperaba elemento a a�adir en la lista en la �ltima posici�n "
				+ "pero fue null");
		
		elements[size() - 1] = element;
		numberOfElements++;
		return false;
	}

	/**
	 * Borra un elemento no nulo de la lista de objetos y retorna true si el 
	 * elemento que se iba a borrar estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a borrar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean remove(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a borrar de la lista en la �ltima posici�n "
				+ "pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			int aux = indexOf(o); /* guarda el resultado de la ejecuci�n del 
			m�todo indexOf */
			
			if (aux != -1) /* si el resultado del m�todo indexOf es 
			distinto de -1... */
			{
				if (aux == size() - 1) // si es el �ltimo �ndice de la lista...
				{
					elements[aux] = null;
					numberOfElements--;
					
					return true;
				} else {
					
					elements[aux] = null;
					Object[] copy = new Object[size()];
					
					for (int i = 0; i < size(); i++)
					{
						if (elements[i] != null) // si el elemento no es null...
						{
							copy[i] = elements[i];
						}
					}
					numberOfElements--;
					elements = copy;
					
					return true;
				}
			}
			return false;
		}
		return false;
	}

	/**
	 * Limpia la lista por completo borrando todos los objetos que la contienen
	 */
	@Override
	public void clear() {
		for (int i = 0; i < size(); i++)
		{
			elements[i] = null;
		}
		numberOfElements = 0;
	}

	/**
	 * Retorna un objeto de la lista de una posici�n dada como par�metro
	 * 
	 * @param la posici�n o �ndice en el que se encuentra el objeto
	 * @return el objeto que se ha encontrado en esa posici�n
	 */
	@Override
	public Object get(int index) {
		ArgumentsCheck.isValid(index, size());
		
		Object copy = elements[index];
		
		return copy;
	}

	/**
	 * Sustituye en la lista a un objeto que estaba en una posici�n dada como
	 * par�metro por otro objeto dado como par�metro no nulo
	 * 
	 * Retorna el objeto de antes de haber sido sustituido por el del par�metro
	 * 
	 * @param el �ndice a colocar el objeto
	 * @param el elemento a colocar en la lista
	 * @return el anterior objeto en la posici�n de la lista
	 */
	@Override
	public Object set(int index, Object element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba el objeto a cambiar "
				+ "pero fue null");
		
		Object aux = elements[index];
		elements[index] = element;
		
		return aux;
	}

	
	/**
	 * A�ade un objeto no nulo a la lista de elementos en un �ndice v�lido en la
	 * lista
	 * 
	 * @param el �ndice
	 * @param el elemento a a�adir
	 */
	@Override
	public void add(int index, Object element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba elemento a a�adir en "
				+ "la lista pero fue null");
			
		if (index == size() - 1) // si es el �ltimo �ndice...
		{
			add(element);
		}
		else {
			Object[] aux = elements; // lista de objetos auxiliar
			
			for (int i = index; i < size() + 1; i++)
			{
				aux[i + 1] = elements[i]; /* cada objeto que est� en las
				siguientes posiciones de index ser� desplazado una posici�n */
			}
			aux[index] = element; /* se le asigna a la posici�n par�metro el 
			objeto par�metro */
			
			elements = aux; /* la lista de objetos ahora es la misma que la
			auxiliar con el nuevo objeto a�adido en la posici�n que deseaba */
			
			numberOfElements++; /* se incrementa en una unidad el n�mero de 
			elementos en la lista */
		}
	}

	/**
	 * Borra de la lista de objetos un objeto de �sta en un �ndice dado como
	 * par�metro y retorna el objeto que ha sido borrado
	 * 
	 * @param el �ndice del objeto que se quiere borrar
	 * @return el objeto que ha sido borrado
	 */
	@Override
	public Object remove(int index) {
		ArgumentsCheck.isValid(index, size());
		
		Object aux = elements[index];
				
		if (index == size() - 1) // si es el �ltimo �ndice de la lista...
		{
			elements[index] = null;
			numberOfElements--;
			
			return aux;
		} else {
			
			Object[] copy = new Object[size()];
			elements[index] = null;
			
			for (int i = 0; i < size(); i++)
			{
				if (elements[i] != null) // si el elemento no es null...
				{
					copy[i] = elements[i];
				}
			}
			numberOfElements--;
			elements = copy;
			
			return aux;
		}
	}

	/**
	 * Retorna el �ndice de un objeto no nulo en la lista, si el objeto no est�
	 * en la lista de objetos retorna -1
	 * 
	 * @param el objeto a buscarle el �ndice de su posici�n
	 * @return la posici�n en la que se encuentra el objeto
	 */
	@Override
	public int indexOf(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscarle el �ndice pero fue null");
		
		for (int i = 0; i < size(); i++)
		{
			if (elements[i].equals(o)) /* si el objeto de la posici�n es el 
			mismo que el del par�metro... */
			{
				int copy = i;
				return copy;
			}
		}
		return -1;
	}

}
