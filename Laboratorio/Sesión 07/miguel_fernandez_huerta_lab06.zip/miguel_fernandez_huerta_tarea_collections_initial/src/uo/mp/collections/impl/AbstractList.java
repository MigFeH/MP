package uo.mp.collections.impl;

public abstract class AbstractList {
	
	public abstract int size();
	
	public abstract boolean isEmpty();
	
	public abstract boolean contains(Object o);
	
	public abstract boolean add(Object element);
	
	public abstract boolean remove(Object o);
	
	public abstract void clear();
	
	public abstract Object get(int index);
	
	public abstract Object set(int index, Object element);
	
	public abstract void add(int index, Object element);
	
	public abstract Object remove(int index);
	
	public abstract int indexOf(Object o);

}
