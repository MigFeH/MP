package uo.mp.collections.impl;

import uo.mp.collections.List;
import uo.mp.util.ArgumentsCheck;

public class LinkedList extends AbstractList implements List {
	
	private Node head; // la cabecera que apunta al primer nodo de la lista
	private int numberOfElements; // el n�mero de elementos que hay en la lista
	
	
	/**
	 * Clase Node dentro de la LinkedList
	 */
	class Node
	{
		Node next;
		Object value;
		
		/**
		 * Constructor con par�metros de la clase Node
		 * 
		 * @param el valor a almacenar en el nodo
		 * @param la referencia a un nodo
		 */
		private Node(Object value, Node next)
		{
			this.value = value;
			this.next = next;
		}
	}

	
	/**
	 * Retorna el n�mero de elementos que hay en la lista
	 * 
	 * @return el n�mero de elementos que hay en la lista
	 */
	@Override
	public int size() {
		int copy = this.numberOfElements;
		return copy;
	}

	/**
	 * Retorna true si la lista est� vac�a (n�mero de elementos = 0) o false en 
	 * caso contrario
	 * 
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean isEmpty() {
		return size() == 0; // retorna true si size() == 0, sino retorna false
	}

	/**
	 * Busca en la lista un objeto no nulo dado como par�metro y retorna true si
	 * el objeto estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a buscar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean contains(Object o) {
		ArgumentsCheck.isTrue(o != null, "Esperaba objeto pero fue null");
		
		Node aux = head;
		
		for (int i = 0; i < size(); i++)
		{
			if (aux.value.equals(o))
			{
				return true;				/// NO LO TENGO CLARO
			}
			aux = head.next;
		}
		return false;
	}

	/**
	 * A�ade un elemento no nulo a la lista de objetos en el �ltimo nodo de 
	 * �sta y retorna true porque �ste tipo de lista admite elementos 
	 * repetidos
	 * 
	 * @param el objeto a a�adir
	 * @return true por permitir elementos repetidos
	 */
	@Override
	public boolean add(Object element) {
		ArgumentsCheck.isTrue(element != null, 
				"Esperaba elemento a a�adir pero fue null");
		
		Node aux = getNode(size() - 1);
		aux.next = new Node(element, null);
		
		numberOfElements++;
		
		return true;
		
	}

	/**
	 * Borra un elemento no nulo de la lista de objetos y retorna true si el 
	 * elemento que se iba a borrar estaba en la lista o false en caso contrario
	 * 
	 * @param el objeto a borrar
	 * @return true o false en funci�n de lo antes mencionado
	 */
	@Override
	public boolean remove(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a borrar pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			int elementIndex = indexOf(o);
			
			if (elementIndex == 0) // si el objeto a borrar es el primero...
			{
				head = head.next;
				numberOfElements--;
				
				return true;
			}
			if (elementIndex == size() - 1) // si el elemento a borrar es el �ltimo...
			{
				Node aux = getNode(elementIndex - 1);
				aux.next = null;
				numberOfElements--;
				
				return true;
			} else { // sino...
				
				Node aux = getNode(elementIndex - 1);
				aux.next = aux.next.next;
				numberOfElements--;
				
				return true;
			}
		}
		return false;
	}

	/**
	 * Limpia la lista por completo borrando todos los objetos que la contienen
	 */
	@Override
	public void clear() {
		head = null;
		numberOfElements = 0;

	}

	/**
	 * Retorna un objeto de la lista de una posici�n dada como par�metro
	 * 
	 * @param la posici�n o �ndice en el que se encuentra el objeto
	 * @return el objeto que se ha encontrado en esa posici�n
	 */
	@Override
	public Object get(int index) {
		ArgumentsCheck.isValid(index, size());
		
		Node aux = head;
		
		if (index == size() - 1) // si es el �ndice de la �ltima posici�n...
		{
			for (int i = 0; i < size(); i++)
			{
				aux = aux.next;
			}
		}
		if (index == 0) // si es el �ndice de la primera posici�n...
		{
			return head.value;
		} else { // sino...
			for (int i = 0; i < index + 1; i++)
			{
				aux = aux.next;
			}
		}
		
		return aux.value;
	}

	/**
	 * Sustituye en la lista a un objeto que estaba en una posici�n dada como
	 * par�metro por otro objeto dado como par�metro no nulo
	 * 
	 * Retorna el objeto de antes de haber sido sustituido por el del par�metro
	 * 
	 * @param el �ndice a colocar el objeto
	 * @param el elemento a colocar en la lista
	 * @return el anterior objeto en la posici�n de la lista
	 */
	@Override
	public Object set(int index, Object element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null, "Esperaba elemento para que "
				+ "sustituyese a otro pero fue null");
		
		if (index == 0) // si el �ndice es el primero de la lista...
		{
			Node previous = head;
			head = new Node(element, head.next);
			
			return previous.value;
		}
		
		if (index == size() - 1)
		{
			Node previous = getNode(index);
			Node aux = getNode(index - 1);
			
			aux.next = new Node(element, null);
			
			return previous.value;
		}
		
		Node previous = getNode(index);
		Node aux = getNode(index - 1);
		
		aux.next = new Node(element, aux.next);
		
		return previous.value;
	}

	/**
	 * A�ade un objeto no nulo a la lista de elementos en un �ndice v�lido en la
	 * lista
	 * 
	 * @param el �ndice
	 * @param el elemento a a�adir
	 */
	@Override
	public void add(int index, Object element) {
		ArgumentsCheck.isValid(index, size());
		ArgumentsCheck.isTrue(element != null,
				"Esperaba elemento a a�adir en la lista pero fue null");
		
		if (index == size() - 1) // si el �ndice es el del �ltimo de la lista...
		{
			add(element);
		} 
		else if (index == 0) // si el �ndice es del primero de la lista...
		{
			head = new Node(element, head);
			numberOfElements++;
		}
		
		Node previous = getNode(index - 1);
		previous.next = new Node(element, previous.next);
		numberOfElements++;
		
	}

	/**
	 * Borra de la lista de objetos un objeto de �sta en un �ndice dado como
	 * par�metro y retorna el objeto que ha sido borrado
	 * 
	 * @param el �ndice del objeto que se quiere borrar
	 * @return el objeto que ha sido borrado
	 */
	@Override
	public Object remove(int index) {
		ArgumentsCheck.isValid(index, size());
		
		if (index == 0) // si el �ndice es el del primer elemento...
		{
			Node previous = head;
			head = head.next;
			
			numberOfElements--;
			return previous.value;
		}
		
		if (index == size() - 1)
		{
			Node previous = getNode(size() - 1);
			Node aux = getNode(size() - 2);
			
			aux.next = null;
			numberOfElements--;
			
			return previous.value;
		}
		
		Node previous = getNode(index);
		Node aux = getNode(index - 1);
		
		aux.next = aux.next.next;
		
		numberOfElements--;
		
		return previous.value;
	}

	/**
	 * Retorna el �ndice de un objeto no nulo en la lista, si el objeto no est�
	 * en la lista de objetos retorna -1
	 * 
	 * @param el objeto a buscarle el �ndice de su posici�n
	 * @return la posici�n en la que se encuentra el objeto
	 */
	@Override
	public int indexOf(Object o) {
		ArgumentsCheck.isTrue(o != null, 
				"Esperaba objeto a buscarle el �ndice pero fue null");
		
		if (contains(o)) // si el objeto est� en la lista...
		{
			Node aux = head;
			
			for (int i = 0; i < size(); i++)
			{
				if (aux.value.equals(o))
				{
					return i;
				}
				aux = aux.next;
			}
		}
		
		return -1;
	}

	/**
	 * Retorna el nodo de una posici�n dada como par�metro
	 * 
	 * @param la posici�n
	 * @return el nodo
	 */
	private Node getNode(int index)
	{
		ArgumentsCheck.isValid(index, size());
		
		if (index == 0) // si el �ndice es el primero de la lista...
		{
			return head;
		}
		if (index == size() - 1) // si el �ndice es el �ltimo de la lista...
		{
			Node aux = head;
			
			for (int i = 0; i < size(); i++)
			{
				aux = aux.next;
			}
			return aux;
		} else { // si el �ndice no es el primero ni el �ltimo...
			
			Node aux = head;
			
			for (int i = 0; i < index + 1; i++)
			{
				aux = aux.next;
			}
			return aux;
		}
	}
}
