package uo.mp.s5.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s5.dome.model.Book;
import uo.mp.s5.dome.model.Borrowable;
import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.service.MediaLibrary;

public class giveBackTest {

	private MediaLibrary ml;
	
	private String title;
	private double basePrice;
	
	private String author;
	private String editorial;
	private String ISBN;
	
	private String artist;
	private int numberOfTracks;
	private int playingTime;
	
	
	@Before
	public void setUp()
	{
		ml = new MediaLibrary();
		
		title = "The title";
		basePrice = 20.0;
		
		author = "The author";
		editorial = "The editorial";
		ISBN = "The ISBN";
		
		artist = "The artist";
		numberOfTracks = 12;
		playingTime = 5;
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable null
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testGiveBackWithNullParam()
	{
		ml.borrow(null);
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que ya estaba prestado
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna true
	 */
	@Test
	public void testGiveBackWithAlreadyBorrowedBookParam()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		book.setBorrowable(true);
		ml.addBorrowable(book);
		
		assertTrue(ml.giveBack(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo cd que ya estaba prestado
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna true
	 */
	@Test
	public void testGiveBackWithAlreadyBorrowedCdParam()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		cd.setBorrowable(true);
		ml.addBorrowable(cd);
		
		assertTrue(ml.giveBack(cd));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que est� sin prestar
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna false
	 */
	@Test
	public void testGiveBackWithNotBorrowedBookParam()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		ml.addBorrowable(book);
		
		assertFalse(ml.giveBack(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo Cd que est� sin prestar
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna false
	 */
	@Test
	public void testGiveBackWithNotBorrowedCdParam()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		ml.addBorrowable(cd);
		
		assertFalse(ml.giveBack(cd));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que 
	 * NO est� en la lista de prestables
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna false
	 */
	@Test
	public void testGiveBackWithNotBookParamInListOfBorrowables()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		assertFalse(ml.giveBack(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo cd que 
	 * NO est� en la lista de prestables
	 * WHEN: Llamada al m�todo giveBack
	 * THEN: Retorna false
	 */
	@Test
	public void testGiveBackWithNotCdParamInListOfBorrowables()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		assertFalse(ml.giveBack(cd));
	}
}
