package uo.mp.s5.dome.model.dvd;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s5.dome.model.Dvd;

public class DvdTest {

	private Dvd aDvd;
	private String theTitle;
	private String theDirector;
	private int theTime;
	private double theBasePrice;
	
	
	
	@Before
	public void setUp() {
		theTitle = "La guerra de las Galaxias";
		theDirector = "George Lucas";
		theTime = 125;
		theBasePrice = 10.0;
	}
		
	/**
	 * GIVEN:
	 * WHEN: Se crea con par�metros v�lidos
	 * THEN: se crea y los valores se asignan a los atributos
	 */
	@Test
	public void testValidParams() {
		aDvd = new Dvd(theTitle, theDirector, theTime, theBasePrice);

		assertEquals(theTitle, aDvd.getTitle());
		assertEquals(theDirector, aDvd.getDirector());
		assertEquals(theTime, aDvd.getPlayingTime());
		assertEquals(theBasePrice, aDvd.getBasePrice(),0.0);
		assertEquals(false, aDvd.getOwn());
		assertEquals("No comment", aDvd.getComment());
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con t�tulo null
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNullTitle()
	{
		new Dvd(null, theDirector, theTime, theBasePrice);
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con director null
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNullDirector()
	{
		new Dvd(theTitle, null, theTime, theBasePrice);
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con tiempo de reproducci�n negativo
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNegativePlayingTime()
	{
		new Dvd(theTitle, theDirector, -1, theBasePrice);
	}

}
