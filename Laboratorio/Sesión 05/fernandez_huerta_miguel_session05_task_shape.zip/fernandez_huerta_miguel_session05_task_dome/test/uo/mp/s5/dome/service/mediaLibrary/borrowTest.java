package uo.mp.s5.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s5.dome.model.Borrowable;
import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.model.Book;
import uo.mp.s5.dome.service.MediaLibrary;

public class borrowTest {
	
	private MediaLibrary ml;
	
	private String title;
	private double basePrice;
	
	private String author;
	private String editorial;
	private String ISBN;
	
	private String artist;
	private int numberOfTracks;
	private int playingTime;
	
	
	@Before
	public void setUp()
	{
		ml = new MediaLibrary();
		
		title = "The title";
		basePrice = 20.0;
		
		author = "The author";
		editorial = "The editorial";
		ISBN = "The ISBN";
		
		artist = "The artist";
		numberOfTracks = 12;
		playingTime = 5;
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable null
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testBorrowWithNullParam()
	{
		ml.borrow(null);
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que ya estaba prestado
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna null
	 */
	@Test
	public void testBorrowAlreadyBorrowedBookParam()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		book.setBorrowable(true);
		ml.addBorrowable(book);
		
		assertNull(ml.borrow(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo cd que ya estaba prestado
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna null
	 */
	@Test
	public void testBorrowAlreadyBorrowedCdParam()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		cd.setBorrowable(true);
		ml.addBorrowable(cd);
		
		assertNull(ml.borrow(cd));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que est� sin prestar
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna el libro ahora prestado
	 */
	@Test
	public void testBorrowWithBookParam()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		ml.addBorrowable(book);
		
		assertEquals(book, ml.borrow(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo Cd que est� sin prestar
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna el cd ahora prestado
	 */
	@Test
	public void testBorrowWithCdParam()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		ml.addBorrowable(cd);
		
		assertEquals(cd, ml.borrow(cd));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo book que 
	 * NO est� en la lista de prestables
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna null
	 */
	@Test
	public void testBorrowWithNotBookParamInListOfBorrowables()
	{
		Borrowable book = new Book
				(title, author, editorial, ISBN, basePrice);
		
		assertNull(ml.borrow(book));
	}
	
	
	/**
	 * GIVEN: Par�metro borrowable de tipo cd que 
	 * NO est� en la lista de prestables
	 * WHEN: Llamada al m�todo borrow
	 * THEN: Retorna null
	 */
	@Test
	public void testBorrowWithNotCdParamInListOfBorrowables()
	{
		Borrowable cd = new Cd
				(title, artist, numberOfTracks, playingTime, basePrice);
		
		assertNull(ml.borrow(cd));
	}
}
