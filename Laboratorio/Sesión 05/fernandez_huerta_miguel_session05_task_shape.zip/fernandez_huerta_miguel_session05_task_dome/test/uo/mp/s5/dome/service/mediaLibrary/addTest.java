package uo.mp.s5.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.model.Dvd;
import uo.mp.s5.dome.model.Platform;
import uo.mp.s5.dome.model.VideoGame;
import uo.mp.s5.dome.service.MediaLibrary;

public class addTest {
	
	/**
	 * GIVEN: Par�metro item null
	 * WHEN: Se llama al m�todo add
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testAddWithNullParam()
	{
		MediaLibrary md = new MediaLibrary();
		md.add(null);
	}

	
	/**
	 * GIVEN: Par�metro CD
	 * WHEN: Se llama al m�todo add
	 * THEN: A�ade objeto al ArrayList de MediaLibrary
	 */
	@Test
	public void testAddWithCdParam()
	{
		MediaLibrary md = new MediaLibrary();
		Cd cd = new Cd(
				"One", "Metallica", 1, 1, 12);
		md.add(cd);
		assertEquals(cd,md.getItems().get(0));
	}
	
	
	/**
	 * GIVEN: Par�metro DVD
	 * WHEN: Se llama al m�todo add
	 * THEN: A�ade objeto al ArrayList de MediaLibrary
	 */
	@Test
	public void testAddWithDvdParam()
	{
		MediaLibrary md = new MediaLibrary();
		Dvd dvd = new Dvd(
				"Torrente 4 la pel�cula", "Mi t�o", 3, 11);
		md.add(dvd);
		assertEquals(dvd,md.getItems().get(0));
	}
	
	
	/**
	 * GIVEN: Par�metro VideoGame
	 * WHEN: Se llama al m�todo add
	 * THEN: A�ade objeto al ArrayList de MediaLibrary
	 */
	@Test
	public void testAddWithVideoGameParam()
	{
		MediaLibrary md = new MediaLibrary();
		VideoGame vd = new VideoGame(
				"COD", "Activision", 200, Platform.XBOX, 14);
		md.add(vd);
		assertEquals(vd,md.getItems().get(0));
	}
	
}
