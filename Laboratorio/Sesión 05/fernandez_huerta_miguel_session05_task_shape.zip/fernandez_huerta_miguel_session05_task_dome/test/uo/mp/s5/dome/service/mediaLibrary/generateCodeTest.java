package uo.mp.s5.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.service.MediaLibrary;

public class generateCodeTest {

	/**
	 * GIVEN: Lista no vac�a de items
	 * WHEN: Se llama al m�todo generateCode
	 * THEN: Se retorna la cadena correctamente
	 */
	@Test
	public void testGenerateCode()
	{
		MediaLibrary md = new MediaLibrary();
		Cd cd1 = new Cd("Yesterday", "The artist 1", 3, 8, 10.0);
		Cd cd2 = new Cd("All you need is Love", "The artist 2", 3, 8, 10.0);
		
		md.add(cd1);
		md.add(cd2);
		
		assertEquals("Yes0-All1", md.generateCode());
	}
	
	
	/**
	 * GIVEN: Lista vac�a de items
	 * WHEN: Se llama al m�todo generateCode
	 * THEN: Se retorna ""
	 */
	@Test
	public void testGenerateCodeWithVoidList()
	{
		MediaLibrary md = new MediaLibrary();
		assertEquals("", md.generateCode());
	}

}
