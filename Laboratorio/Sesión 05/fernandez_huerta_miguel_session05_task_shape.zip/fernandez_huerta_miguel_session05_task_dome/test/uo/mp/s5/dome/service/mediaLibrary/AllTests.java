package uo.mp.s5.dome.service.mediaLibrary;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ addTest.class,
	getItemsTest.class,
	getNumberOfItemsOwnedTest.class,
	searchItemTest.class,
	searchTest.class,
	getFinalPriceTest.class,
	generateCodeTest.class,
	borrowTest.class,
	giveBackTest.class})
public class AllTests {

}
