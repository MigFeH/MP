package uo.mp.s5.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.model.Dvd;
import uo.mp.s5.dome.model.Platform;
import uo.mp.s5.dome.model.VideoGame;
import uo.mp.s5.dome.service.MediaLibrary;

public class getFinalPriceTest {

	/**
	 * GIVEN: 
	 * WHEN: Se llama al m�todo getFinalPrice
	 * THEN: Retorna la suma de los precios finales de todos los items de la 
	 * librer�a
	 */
	@Test
	public void testGetFinalPrice()
	{
		Cd cd = new Cd(
				"T�tulo cd", "Artista cd",3,4,4.0);
		
		Dvd dvd = new Dvd(
				"T�tulo dvd","Director dvd",14,9.0);
		
		VideoGame vd = new VideoGame(
				"T�tulo game", "Artista game", 4, Platform.PLAYSTATION, 9.0);
		
		MediaLibrary md = new MediaLibrary();
		
		md.add(cd);
		md.add(dvd);
		md.add(vd);
		
		assertEquals(24.9, md.getFinalPrice(), 0.0);
		
	}
	

}
