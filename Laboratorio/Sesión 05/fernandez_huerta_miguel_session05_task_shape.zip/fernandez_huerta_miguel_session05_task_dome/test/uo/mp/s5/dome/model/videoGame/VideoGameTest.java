package uo.mp.s5.dome.model.videoGame;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s5.dome.model.Platform;
import uo.mp.s5.dome.model.VideoGame;

public class VideoGameTest {
	
	private String theTitle;
	private String theAuthor;
	private int thePlayers;
	private Platform thePlatform;
	private double theBasePrice;
	
	@Before
	public void setUp()
	{
		theTitle = "Call of Duty";
		theAuthor = "Activision";
		thePlayers = 200;
		thePlatform = Platform.XBOX;
		theBasePrice = 10;
	}
	
	
	/**
	 * GIVEN: Par�metro t�tulo null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullTitle()
	{
		new VideoGame(
				null, theAuthor, thePlayers, thePlatform, theBasePrice);
	}
	
	
	/**
	 * GIVEN: Par�metro autor null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullAuthor()
	{
		new VideoGame(
				theTitle, null, thePlayers, thePlatform, theBasePrice);
	}
	
	
	/**
	 * GIVEN: Par�metro players no v�lido
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithIncorrectPlayersParam()
	{
		new VideoGame(
				theTitle, theAuthor, -1, thePlatform, theBasePrice);
	}
	
	
	/**
	 * GIVEN: Par�metro platform null
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNullPlatform()
	{
		new VideoGame(
				theTitle, theAuthor, thePlayers, null, theBasePrice);
	}
	
	
	/**
	 * GIVEN: Par�metro basePrice negativo
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithNegativeBasePrice()
	{
		new VideoGame(
				theTitle, theAuthor, thePlayers, thePlatform, -1);
	}
	
	
	/**
	 * GIVEN: Par�metro basePrice no v�lido
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testConstructorWithIncorrectBasePrice()
	{
		new VideoGame(
				theTitle, theAuthor, thePlayers, thePlatform, 10001);
	}
	
	/**
	 * GIVEN: Par�metros correctos
	 * WHEN: Se llama al constructor de la clase
	 * THEN: Se crea el objeto correctamente
	 */
	@Test
	public void testConstructorWithCorrectParams()
	{
		VideoGame vd = new VideoGame(
				theTitle, theAuthor, thePlayers, thePlatform, theBasePrice);
		
		assertEquals(theTitle, vd.getTitle());
		assertEquals(theAuthor, vd.getAuthor());
		assertEquals(thePlayers, vd.getPlayers());
		assertEquals(thePlatform, vd.getPlatform());
		assertEquals(theBasePrice, vd.getBasePrice(),0.0);
	}
}