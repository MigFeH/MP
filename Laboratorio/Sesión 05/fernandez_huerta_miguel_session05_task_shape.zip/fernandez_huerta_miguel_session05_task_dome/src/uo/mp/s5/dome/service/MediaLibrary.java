package uo.mp.s5.dome.service;

import java.io.PrintStream;
import java.util.ArrayList;

import uo.mp.s5.dome.model.Borrowable;
import uo.mp.s5.dome.model.Item;
import uo.mp.util.ArgumentsCheck;

public class MediaLibrary {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */
	
	private ArrayList<Item> items = new ArrayList<>(); // lista de items
	private ArrayList<Borrowable> borrowables = new ArrayList<>(); // lista de items prestables
	
	
	/**
	 * A�ade un item a la lista no nulo
	 * 
	 * @param item a a�adir
	 */
	public void add(Item theItem)
	{
		ArgumentsCheck.isTrue(theItem != null);
		items.add(theItem);
	}
	
	
	/**
	 * A�ade un item PRESTABLE a la lista no nulo
	 * 
	 * @param item PRESTABLE a a�adir
	 */
	public void addBorrowable(Borrowable theBorrowable)
	{
		ArgumentsCheck.isTrue(theBorrowable != null);
		borrowables.add(theBorrowable);
	}
	
	/**
	 * Retorna el n�mero de items con propietario
	 * 
	 * @return n�mero de items con propietario
	 */
	public int getNumberOfItemsOwned()
	{
		int numberOfItems = 0;
		for(Item theItem: items)
		{
			if(theItem.getOwn())
			{
				numberOfItems++;
			}
		}
		return numberOfItems;
	}
	
	/**
	 * Retorna una copia de la lista de items
	 * 
	 * @return la lista copia de items
	 */
	public ArrayList<Item> getItems()
	{
		ArrayList<Item> copy = new ArrayList<Item>();
		for (Item theItem: items)
		{
			copy.add(theItem);
		}
		return copy;
	}
	
	
	/**
	 * Busca en la lista un item recibido como par�metro (solo igualdad de 
	 * identidad no de contenido o estado) y devuelva la posici�n que ocupa, 
	 * si lo encuentra, o bien -1 si no lo ha encontrado
	 * 
	 * @param el item a devolver su posici�n en la lista
	 * @return la posici�n que ocupa el item recibido como par�metro, o -1
	 * si dicho item par�metro no se encuentra en la lista par�metro
	 */
	public int searchItem(Item theItem)
	{
		ArgumentsCheck.isTrue(theItem != null);
		
		for(Item item: items)
		{
			if (theItem.equals(item))
			{
				return this.items.indexOf(item);
			}
		}
		return -1;
	}
	
	
	/**
	 * Busca un objeto en la lista "igual " al recibido como par�metro
	 * 
	 * Si el recibido es un Cd ser� igual si son iguales el t�tulo y el artista
	 * Si el recibido es un Dvd ser� igual si son iguales el t�tulo y director
	 * Si el recibido es un Videogame ser� igual si son iguales el t�tulo y la plataforma
	 * 
	 * @param el objeto (item) a buscar en la lista
	 * @return el item encontrado "igual" al recibido o null si no lo ha encontrado
	 */
	public Item search(Item itemToSearch)
	{
		ArgumentsCheck.isTrue(itemToSearch != null, 
				"Esperaba objeto a buscar pero fue null");
		
		for(Item itemInList: items)
		{
			if(itemInList.equals(itemToSearch))
			{
				return itemInList;
			}
		}
		return null;
	}
	
	
	/** Retorna un String (posiblemente vac�o si no hay datos) que contiene la 
	 * persona responsable para cada �tem, separados por comas
	 *  
	 * En el caso de los CDs, el responsable es el artista
	 * En el caso de los DVDs el responsable es el director
	 * 
	 * @return el String con el responsable de cada item
	 */
	public String getResponsable()
	{
		if (items.get(0) == null)
		{
			return "";
		} else
		{
			String data = "";
			for (int i = 0; i < items.size(); i++)
			{
				if (i == items.size() - 1)
				{
					data = data + items.get(i).getResponsable() + "\n";
					break;
				}
				data = data + items.get(i).getResponsable() + ",";
			}
			return data;
		}
	}
	
	
	/**
	 * Retorna la suma de los precios finales de todos los �tems que tenga
	 * la librer�a
	 * 
	 * @return la suma de los precios finales
	 */
	public double getFinalPrice()
	{
		double finalPrice = 0.0;
		for (Item theItem: items)
		{
			finalPrice = finalPrice + theItem.getFinalPrice();
		}
		return finalPrice;
	}
	
	
	/**
	 * Devuelve una cadena con el c�digo de todos los �tems de la mediateca,
	 * separados por un guion
	 * El c�digo ser� una cadena formada por las tres primeras letras del t�tulo
	 * y un n�mero secuencial, comenzando en 0
	 * 
	 * Por ejemplo:
	 * 
	 * Si el t�tulo del primer elemento es �Yesterday, 
	 * y el del segundo es �All you need is Love�, 
	 * el c�digo que vuelca es �Yes0-All1�.
	 * 
	 * Si no hay �tems, devuelve ��.
	 */
	public String generateCode()
	{
		String data = "";
		int sequential = 0;
		for(int i = 0; i < items.size(); i++)
		{
			if (i == items.size() - 1)
			{
				data = data + items.get(i).generateCode() + sequential;
				break;
			}
			
			data = data + items.get(i).generateCode() + sequential + "-";
			sequential++;
		}
		return data;
	}
	
	
	/**
	 * Retorna un String con los items disponibles, que ahora mismo 
	 * se pueden prestar
	 * 
	 * @return el String con dichos items prestables
	 */
	public String listAvaiableItems()
	{
		String data = "";
		for (int i = 0; i < borrowables.size(); i++)
		{
			if (borrowables.get(i).isAvaiable())
			{
				data = data + borrowables.get(i).toString() + "\n";
			}
		}
		return data;
	}
	
	
	/**
	 * Retorna un String con los items prestables (todos los Books y Cds)
	 * 
	 * @return el String con dichos items prestables
	 */
	public String listBorrowableItems()
	{
		String data = "";
		for (int i = 0; i < borrowables.size(); i++)
		{
			data = data + borrowables.get(i).toString() + "\n";
		}
		return data;
	}
	
	
	/**
	 * Prestar un �tem
	 * Recibe un Item prestable como par�metro (diferente de null),
	 * 
	 * Busca uno igual en la lista y devuelve este �ltimo ya prestado, 
	 * o null si no se ha podido prestar
	 * 
	 * @param borrowableToSearch, el item a buscar
	 * @return el item que es igual al del par�metro o null si no se ha podido
	 * prestar
	 */
	public Borrowable borrow(Borrowable borrowableToSearch)
	{
		ArgumentsCheck.isTrue(borrowableToSearch != null, 
				"Esperaba item prestable a buscar pero fue null");
		
		for (int i = 0; i < borrowables.size(); i++)
		{
			/* Si el par�metro coincide con alg�n prestable de la lista...*/
			if (borrowables.get(i).equals(borrowableToSearch))
			{
				/* Si el prestable de la lista NO est� ya prestado... */
				if (borrowables.get(i).isBorrowable() == false)
				{
					/* Poner que ahora est� prestado */
					borrowables.get(i).setBorrowable(true);
					/* Retornar el prestable */
					return borrowables.get(i); 
				}
			}
		}
		return null;
	}
	
	
	/**
	 * Devolver un �tem
	 * Recibe un �tem igual a uno que exista (por tanto diferente de null),
	 * lo deja disponible y devuelve true si se ha podido devolver
	 * 
	 * @param borrowableToSearch, el item a buscar
	 * @return true si se ha podido devolver; false en caso contrario
	 */
	public boolean giveBack(Borrowable borrowableToSearch)
	{
		ArgumentsCheck.isTrue(borrowableToSearch != null, 
				"Esperaba item a devolver pero fue null");
		
		for (int i = 0; i < borrowables.size(); i++)
		{
			/* Si el par�metro coincide con alg�n prestable de la lista... */
			if (borrowables.get(i).equals(borrowableToSearch))
			{
				/* Si el prestable de la lista SI est� ya prestado... */
				if (borrowables.get(i).isBorrowable())
				{
					/* Poner que ahora no est� prestado */
					borrowables.get(i).setBorrowable(false);
					/* Retornar true (se ha podido devolver) */
					return true;
				}
			}
		}
		return false;
	}
	
	
	/**
	 * Imprime todos los items
	 */
	public void list(PrintStream out)
	{
		ArgumentsCheck.isTrue(out != null);
		out.println("========== Lista de Items en la librer�a ==========");
		for(Item theItem: items)
		{
			//theItem.print(out);
			out.println(theItem.toString());
		}
		out.println("========== C�digo generado por los Items ==========");
		out.println(generateCode());
		
	}

	
	/**
	 * Imprime todos los items
	 */
	public void list2(PrintStream out)
	{
		ArgumentsCheck.isTrue(out != null);
		for(Item theItem: items)
		{
			out.println(theItem.toString());
		}
	}
	
}
