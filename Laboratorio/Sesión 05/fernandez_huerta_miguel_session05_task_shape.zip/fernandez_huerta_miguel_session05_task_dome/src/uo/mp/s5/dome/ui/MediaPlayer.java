package uo.mp.s5.dome.ui;

import uo.mp.s5.dome.model.Book;
import uo.mp.s5.dome.model.Borrowable;
import uo.mp.s5.dome.model.Cd;
import uo.mp.s5.dome.model.Dvd;
import uo.mp.s5.dome.model.Item;
import uo.mp.s5.dome.model.Platform;
import uo.mp.s5.dome.model.VideoGame;
import uo.mp.s5.dome.service.MediaLibrary;

public class MediaPlayer {

	
	/**
	 * Muestra por pantalla los objetos de las subclases de:
	 * 
	 * Item
	 * Borrowable
	 * 
	 * 
	 * @author Miguel
	 * @version 18-02-2022
	 */
	public void run() 
	{
		MediaLibrary md = new MediaLibrary();
		
		Item dvd = new Dvd(
				"Thor", 
				"Marvel", 
				10, 
				100);
		
		Item cd = new Cd(
				"Panes y flautas", 
				"Mi amigo", 
				5, 
				2, 
				40);
		
		Item vg = new VideoGame(
				"God of War", 
				"Microsoft", 
				1, 
				Platform.PLAYSTATION, 
				60);
		
		Item book1 = new Book(
				"Luna de Plut�n", 
				"Yo", 
				"Editoriales A",
				"01010101", 
				20.0);
		
		Item book2 = new Book(
				"Pa�ses para viajar", 
				"Esteban", 
				"Editoriales B",
				"02020202", 
				20.0);
		
		Item book3 = new Book(
				"Top recetas de Chicote", 
				"Chicote", 
				"Editoriales C",
				"03030303", 
				20.0);
		
		Item book4 = new Book(
				"Mortadelo Y Filem�n", 
				"Francisco Ib��ez", 
				"Editoriales D", 
				"04040404",
				20.0);
		
		Item book5 = new Book(
				"Flipi y Flape", 
				"El t�o Melecio", 
				"Editoriales E", 
				"05050505", 
				20.0);
		
		Item cd1 = new Cd(
				"Beat it", 
				"Michael Jackson", 
				1, 
				3,
				12.0);
				
		Item cd2 = new Cd(
				"Black and white", 
				"Michael Jackson", 
				1, 
				3,
				12.0);
		
		Item cd3 = new Cd(
				"Never gona give you up", 
				"Rick Astley", 
				1, 
				3,
				12.0);
		
		
		book1.setOwn(true); // libro con propietario
		book2.setOwn(true); // libro con propietario
		
		cd1.setOwn(true); // cd con propietario
		cd2.setOwn(true); // cd con propietario
		
		
		md.add(dvd);
		md.add(cd);
		md.add(vg);
		
		md.addBorrowable((Borrowable)book1);
		md.addBorrowable((Borrowable)book2);
		md.addBorrowable((Borrowable)book3);
		md.addBorrowable((Borrowable)book4);
		md.addBorrowable((Borrowable)book5);
		
		md.addBorrowable((Borrowable)cd1);
		md.addBorrowable((Borrowable)cd2);
		md.addBorrowable((Borrowable)cd3);
		
		
		md.getNumberOfItemsOwned();
		md.getNumberOfItemsOwned();
		
		
		md.list(System.out);
		
		System.out.println();
		
		System.out.println(
				"========== Listado de items con toString ==========");
		
		md.list2(System.out);
		
		
		System.out.println(
				"========== Listado de items que se pueden prestar ==========");
		
		md.borrow((Borrowable)book1); // se presta un libro
		md.borrow((Borrowable)cd1); // se presta un cd
		
		System.out.print(md.listBorrowableItems());
		
		System.out.println(
				"========== Listado de items que est�n disponibles para ser "
				+ "prestados ==========");
		
		System.out.print(md.listAvaiableItems());
		
		
	}

}
