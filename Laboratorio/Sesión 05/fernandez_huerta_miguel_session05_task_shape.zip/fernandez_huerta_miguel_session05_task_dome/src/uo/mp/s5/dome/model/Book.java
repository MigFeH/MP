package uo.mp.s5.dome.model;

import java.io.PrintStream;

import uo.mp.util.ArgumentsCheck;

public class Book extends Item implements Borrowable {
	
	private static final int INCREMENT = 4; // incremento del precio base
	
	private String author; // el autor del libro
	private String editorial; // la editorial del libro
	private String ISBN; // International Standard Book Number
	private boolean borrowable; // Estado que indica si el libro est� prestado
	
	/**
	 * Constructor con par�metros de la clase
	 * 
	 * @param title, el t�tulo del libro 
	 * @param author, el autor del libro
	 * @param editorial, la editorial del libro
	 * @param ISBN, International Standard Book Number
	 * @param basePrice, el precio base del libro
	 */
	public Book(String title, String author, String editorial, String ISBN,
			double basePrice)
	{
		super(title, basePrice);
		setAuthor(author);
		setEditorial(editorial);
		setISBN(ISBN);
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor que almacena el atributo
	 */
	public boolean isBorrowable() {
		return borrowable;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * Ser� true si el libro est� prestado 
	 * Ser� false si el libro no est� prestado
	 * 
	 * @param el nuevo valor a almacenar en el atributo
	 */
	public void setBorrowable(boolean status) {
		this.borrowable = status;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor que almacena el atributo
	 */
	public String getAuthor() {
		return author;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor a almacenar en el atributo
	 */
	private void setAuthor(String author) {
		ArgumentsCheck.isTrue(author != null, "Esperaba autor pero fue null");
		this.author = author;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor que almacena el atributo
	 */
	public String getEditorial() {
		return editorial;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor a almacenar en el atributo
	 */
	private void setEditorial(String editorial) {
		ArgumentsCheck.isTrue(editorial != null, 
				"Esperaba editorial pero fue null");
		this.editorial = editorial;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor que almacena el atributo
	 */
	public String getISBN() {
		return ISBN;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor a almacenar en el atributo
	 */
	private void setISBN(String ISBN) {
		ArgumentsCheck.isTrue(ISBN != null, "Esperaba International Standard "
				+ "Book Number (ISBN) pero fue null");
		this.ISBN = ISBN;
	}


	@Override
	public void print(PrintStream out) {
		out.println("Book: " + getTitle());
		out.println("Author: " + getAuthor());
		out.println("Editorial: " + getEditorial());
		out.println("ISBN: " + getISBN());
		
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		
		out.println("Comment: " + getComment());
		out.println();
		
	}
	
	
	/**
	 * Retorna el escritor ("""responsable""") del libro
	 * 
	 * @return el escritor del libro
	 */
	@Override
	public String getResponsable() {
		return getAuthor();
	}
	
	
	@Override
	public boolean isLike(Item itemToSearch) {
		if(! (itemToSearch instanceof Book) )
		{
			return false;
		}
		Book bookToSearch = (Book) itemToSearch;
		if(bookToSearch.getTitle().equals(this.getTitle()) &&
				bookToSearch.getAuthor().equals(this.getAuthor()))
		{
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Devuelve un toString con los atributos de la clase
	 * 
	 * @return el String con dichos atributos
	 */
	@Override
	public String toString() 
	{
		String data = "";
		data = data + 
				("Book: " + getTitle() + "\n" + 
				"Author: " + getAuthor() + "\n" + 
				"Editorial: " + getEditorial() + "\n" + 
				"ISBN: " + getISBN() + "\n");
		data = data + super.toString();
		return data;
	}
	
	
	
	/**
	 * Operaci�n que compara dos libros y devolver� true si dos libros son 
	 * iguales
	 * 
	 * "Dos libros son iguales si tienen el mismo ISBN"
	 * 
	 * @param itemToSearch, el item con el que se compara
	 * @return true si son iguales; false en caso contrario
	 */
	public boolean equals(Item itemToSearch) {
		ArgumentsCheck.isTrue(itemToSearch != null, "Esperaba item a buscar "
				+ "pero fue null");
		// Si el item no es de la instancia de Book...
		if (!(itemToSearch instanceof Book))
		{
			return false;
		}
		// Sino...
		Book bookToSearch = (Book) itemToSearch;
		/* Si el libro que se compara tiene el mismo ISBN que el del atributo
		"original"...*/
		if (bookToSearch.getISBN().equals(this.getISBN()))
		{
			return true;
		} else { //sino...
			return false;
		}
	}


	/**
	 * Retorna true si el libro est� disponible para prestar
	 * Retorna false en caso contrario
	 * 
	 * Un item est� disponible cuando est� en propiedad y no est� prestado
	 */
	@Override
	public boolean isAvaiable() {
		/* Si est� en propiedad y no est� prestado... */
		if (getOwn() && this.borrowable == false)
		{
			return true;
		}
		return false;
	}

	
	/**
	 * Retorna el precio final obtenido de la suma del precio base mas el 
	 * incremento del precio
	 * 
	 * @return el precio final
	 */
	@Override
	public double getFinalPrice() {
		return getBasePrice() + ((INCREMENT * getBasePrice()) / 100);
	}


}
