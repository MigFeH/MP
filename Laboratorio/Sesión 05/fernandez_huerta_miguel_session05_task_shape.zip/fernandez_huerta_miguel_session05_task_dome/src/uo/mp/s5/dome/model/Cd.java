package uo.mp.s5.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public class Cd extends Item implements Borrowable {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */

	private static final double TAX = 2; // Impuesto a�adido al precio 
	
	private String artist; // el artista
	private int numberOfTracks; // el n�mero de canciones
	private int playingTime; // el tiempo de reproducci�n
	private boolean borrowable; // Estado que indica si el cd est� prestado
	
	
	/**
	 * Constructor con par�metros de la clase Cd
	 * 
	 * @param theTitle, el t�tulo del cd
	 * @param theArtist, el artista del cd
	 * @param tracks, el n�mero de canciones del cd
	 * @param time, el tiempo de reproducci�n
	 * @param basePrice, el precio base del cd
	 */
	public Cd(String theTitle, String theArtist, int tracks, int time,
			double basePrice)
	{
		super(theTitle, basePrice);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
		setPlayingTime(time);
		setBorrowable(false);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	@Override
	public void setBorrowable(boolean status)
	{
		this.borrowable = status;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	@Override
	public boolean isBorrowable()
	{
		return this.borrowable;
	}
	
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setArtist(String artist)
	{
		ArgumentsCheck.isTrue(artist != null);
		this.artist = artist;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setNumberOfTracks(int numberOfTracks)
	{
		ArgumentsCheck.isTrue(numberOfTracks > 0);
		this.numberOfTracks = numberOfTracks;
	}
	
	
	/**
	 * Modifica el valor guardado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setPlayingTime(int playingTime)
	{
		ArgumentsCheck.isTrue(playingTime > 0);
		this.playingTime = playingTime;
	}

	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public String getArtist()
	{
		return this.artist;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public int getNumberOfTracks()
	{
		return this.numberOfTracks;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public String getResponsable()
	{
		return this.artist;
	}
	
	
	/**
	 * Retorna el valor guardado en el atributo
	 * 
	 * @return el valor guardado
	 */
	public int getPlayingTime()
	{
		return this.playingTime;
	}
	
	
	public void print(PrintStream out) 
	{
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		
		out.println("Comment: " + getComment());
		out.println();
	}
	
	
	
	public void print2(PrintStream out)
	{
		super.print2(out); // es un up-cast; se puede poner esta instrucci�n en la primera l�nea o en la �ltima
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		out.println();
	}
	
	
	/**
	 * Devuelve en un toString los atributos de la clase
	 * 
	 * @return los atributos de la clase
	 */
	public String toString()
	{
		String data = "";
		data = data + ("CD: " + getTitle() + " (" + getPlayingTime() + " mins)" 
				+ "\n");
		data = data + ("Artist: " + getArtist()) + "\n";
		data = data + "Tracks: " + getNumberOfTracks() + "\n";
		data = data + super.toString();
		return data;
	}
	
	
	@Override
	public boolean isLike(Item itemToSearch)
	{
		if(! (itemToSearch instanceof Cd) )
		{
			return false;
		}
		Cd cdToSearch = (Cd) itemToSearch;
		if(cdToSearch.getTitle().equals(this.getTitle()) &&
				cdToSearch.getArtist().equals(this.getArtist()))
		{
			return true;
		} else {
			return false;
		}
	}
	
	
	public boolean equals(Item itemToSearch)
	{
		ArgumentsCheck.isTrue(itemToSearch != null, "Esperaba item a buscar "
				+ "pero fue null");
		if(! (itemToSearch instanceof Cd) )
		{
			return false;
		}
		Cd cdToSearch = (Cd) itemToSearch;
		if(cdToSearch.getTitle().equals(this.getTitle()) &&
				cdToSearch.getArtist().equals(this.getArtist()))
		{
			return true;
		} else {
			return false;
		}
	}


	/**
	 * Retorna true si el cd est� disponible para prestar
	 * Retorna false en caso contrario
	 * 
	 * Un item est� disponible cuando est� en propiedad y no est� prestado
	 */
	@Override
	public boolean isAvaiable() {
		/* Si est� en propiedad y no est� prestado... */
		if (getOwn() && this.borrowable == false)
		{
			return true;
		}
		return false;
	}

	/**
	 * Retorna el precio final que se obtiene de la suma del precio base 
	 * mas el impuesto a�adido al precio
	 * 
	 * @return el precio final que se obtiene
	 */
	@Override
	public double getFinalPrice() 
	{
		return getBasePrice() + TAX;
	}
	
}