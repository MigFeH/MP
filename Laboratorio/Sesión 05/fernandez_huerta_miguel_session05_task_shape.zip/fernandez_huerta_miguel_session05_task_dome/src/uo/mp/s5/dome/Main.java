package uo.mp.s5.dome;

import uo.mp.s5.dome.ui.MediaPlayer;

public class Main {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */

	public static void main(String[] args) {
		new MediaPlayer().run();
	}

}
