package uo.mp.s5.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public abstract class Item {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */

	private String title; // el t�tulo
	private boolean gotIt; // si lo tiene en propiedad
	private String comment; // comentario respecto del item
	private double basePrice; // precio base
	
	/**
	 * Constructor sin par�metros de la clase Item
	 */
	public Item() 
	{
		super();
	}
	
	
	/**
	 * Contructor con par�metros de la clase Item
	 * 
	 * @param el t�tulo del objeto
	 * @param el precio base
	 */
	public Item(String theTitle, double basePrice)
	{
			setTitle(theTitle);
			setOwn(false);
			setComment("No comment");
			setBasePrice(basePrice);
	}
	
	
	/**
	 * Modifica el valor guardado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setBasePrice(double basePrice)
	{
		ArgumentsCheck.isTrue(basePrice >= 0 && basePrice <= 10000, 
				"Precio base no v�lido");
		this.basePrice = basePrice;
	}
	
	
	/**
	 * Modifica el valor guardado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setTitle(String title)
	{
		ArgumentsCheck.isTrue(title != null);
		this.title = title;
	}

	
	/**
	 * Modifica el valor guardado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	public void setOwn(boolean ownIt)
	{
		gotIt = ownIt;
	}
	
	
	/**
	 * Modifica el valor guardado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	public void setComment(String comment)
	{
		ArgumentsCheck.isTrue(comment != null, 
				"Esperaba comentario pero fue null");
		this.comment = comment;
	}
	
	
	/**
	 * Retorna el valor guardado en el atributo
	 * 
	 * @return el valor guardado
	 */
	public String getComment()
	{
		return comment;
	}

	
	/**
	 * Retorna el valor guardado en el atributo
	 * 
	 * @return el valor guardado
	 */
	public boolean getOwn()
	{
		return gotIt;
	}

	
	/**
	 * Retorna el valor guardado en el atributo
	 * 
	 * @return el valor guardado
	 */
	public String getTitle()
	{
		return this.title;
	}
	
	
	/**
	 * M�todo com�n a las subclases para imprimir por pantalla
	 */
	public abstract void print(PrintStream out);
	
	
	/**
	 * M�todo com�n a las subclases que retorna su responsable correspondiente
	 * 
	 * @return el responsable correspondiente a la subclase
	 */
	public abstract String getResponsable();
	
	
	/**
	 * Retorna el valor guardado en el atributo
	 * 
	 * @return el valor guardado
	 */
	public double getBasePrice()
	{
		return basePrice;
	}
	
	
	/**
	 * Imprime los atributos de item
	 */
	public void print2(PrintStream out)
	{
		out.println("Tilte: " + getTitle());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
		out.println();
	}
	
	
	/**
	 * Retorna los atributos de item en formato toString
	 * 
	 * @return el toString con los atributos
	 */
	public String toString()
	{
		String data = "";
		
		if (getOwn()) {
			data = data + "You own it" + "\n";
		} else {
			data = data + "You do not own it" + "\n";
		}
		data = data + "Comment: " + getComment() + "\n";
		
		return data;
	}
	
	
	/**
	 * Retorna un c�digo que ser� una cadena formada por las tres primeras 
	 * letras del t�tulo
	 * 
	 * @return la cadena con las tres primeras letras del t�tulo
	 */
	public String generateCode()
	{	
		int lowerCut = 0; // �ndice desde el que parte el substring
		int higherCut = 3; // �ndice hasta el que llega el substring
		
		return getTitle().substring(lowerCut, higherCut);
	}
	
	
	public abstract double getFinalPrice();
	
	
	public abstract boolean isLike(Item itemToSearch);
}