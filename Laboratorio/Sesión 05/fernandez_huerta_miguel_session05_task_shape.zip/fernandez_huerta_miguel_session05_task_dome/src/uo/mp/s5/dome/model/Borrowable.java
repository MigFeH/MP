package uo.mp.s5.dome.model;

public interface Borrowable {
	boolean isAvaiable(); // retorna si est� disponible para prestar
	void setBorrowable(boolean status);
	boolean isBorrowable(); // retorna si est� prestado
}
