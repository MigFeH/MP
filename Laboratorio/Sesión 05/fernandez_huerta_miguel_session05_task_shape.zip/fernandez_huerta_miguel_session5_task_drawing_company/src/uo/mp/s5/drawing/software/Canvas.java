package uo.mp.s5.drawing.software;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import uo.mp.s5.drawing.interfacerepository.Drawable;

public class Canvas {
	private List< Drawable > drawables = new ArrayList<>();

	public void add(Drawable drawable) {
		drawables.add(drawable);
	}

	public void draw(PrintStream out) {
		for (Drawable drawable: drawables)
		{
			drawable.draw(out);
		}
	}
}
