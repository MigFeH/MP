package uo.mp.s5.drawing.interfacerepository;

import java.io.PrintStream;

public interface Drawable {
	void draw(PrintStream out);

}
