package uo.mp.s4.post;

import uo.mp.s4.post.app.*;

public class Main {
	
	public static void main(String args[])
	{
		new NetworkApplication().Run();
	}

}
