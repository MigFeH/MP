package uo.mp.s4.post.post;

public enum Fich {
	CAMPOS , MONTA�AS

}
