package uo.mp.s4.post.social.socialNetwork;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.post.post.Message;
import uo.mp.s4.post.social.SocialNetwork;

public class findPostByUserTest {

	/**
	 * GIVEN: Par�metro v�lido
	 * WHEN: Se llama al m�todo findPostByUser
	 * THEN: Devuelve la lista con los posts
	 */
	@Test
	public void testFindPostByUserWithCorrectParam()
	{
		SocialNetwork sm = new SocialNetwork();
		sm.addPost(new Message("Pablo", "El rojo es un color"));
		assertNotNull(sm.findPostsByUser("Pablo"));
	}
	
	
	/**
	 * GIVEN: Par�metro null
	 * WHEN: Se llama al m�todo findPostByUser
	 * THEN: Lanza excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testFindPostByUserWithNullParam()
	{
		SocialNetwork sm = new SocialNetwork();
		sm.addPost(new Message("Pablo", "El rojo es un color"));
		sm.findPostsByUser(null);
	}

}
