package uo.mp.s4.post.post.message;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.post.post.Message;

public class MessageTest {
	
	
	/**
	 * GIVEN: Par�metro de nombre de usuario null
	 * WHEN: Se llama al costructor
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testMessageWithNullUserName()
	{
		new Message(null,"");
	}
	
	
	/**
	 * GIVEN: Par�metro de mensaje null
	 * WHEN: Se llama al costructor
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testMessageWithNullMessage()
	{
		new Message("Paco",null);
	}
	
	
	/**
	 * GIVEN: Par�metros v�lidos
	 * WHEN: Se llama al costructor
	 * THEN: Se crea el objeto correctamente
	 */
	@Test
	public void testMessageWithCorrectParams()
	{
		Message mg = new Message("Paco","");
		
		assertNotNull(mg.getUserName());
		assertNotNull(mg.getMessages());
	}
}
