package uo.mp.s4.post.social.socialNetwork;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.post.post.Message;
import uo.mp.s4.post.social.SocialNetwork;

public class addPostTest {

	/**
	 * GIVEN: Par�metro null
	 * WHEN: Se llama al m�todo addPost
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testAddPostWithNullParam()
	{
		new SocialNetwork().addPost(null);
	}
	
	
	/**
	 * GIVEN: Par�metro v�lido
	 * WHEN: Se llama al m�todo addPost
	 * THEN: Se a�ade el post correctamente
	 */
	@Test
	public void testAddPostWithCorrectParam()
	{
		SocialNetwork sn = new SocialNetwork();
		sn.addPost(new Message("Pablo","El rojo es un color"));
		
		assertNotNull(sn.getPosts().get(0));	
	}
}
