package uo.mp.s4.post.post.photo;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.post.post.Fich;
import uo.mp.s4.post.post.Photo;

public class PhotoTest {

	/**
	 * GIVEN: Par�metro de nombre de usuario null
	 * WHEN: Se llama al costructor
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testPhotoWithNullUserName()
	{
		new Photo(null,Fich.MONTA�AS,"T�tulo");
	}
	
	
	/**
	 * GIVEN: Par�metro de foto null
	 * WHEN: Se llama al costructor
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testPhotoWithNullPhoto()
	{
		new Photo("Paco",null,"T�tulo");
	}
	
	
	/**
	 * GIVEN: Par�metro de t�tulo null
	 * WHEN: Se llama al costructor
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testPhotoWithNullTitle()
	{
		new Photo("Paco",Fich.MONTA�AS,null);
	}
	
	/**
	 * GIVEN: Par�metros v�lidos
	 * WHEN: Se llama al costructor
	 * THEN: Se crea el objeto correctamente
	 */
	@Test
	public void testPhotoWithCorrectParams()
	{
		Photo ft = new Photo("Paco",Fich.MONTA�AS,"T�tulo");
		
		assertNotNull(ft.getUserName());
		assertNotNull(ft.getPhoto());
		assertNotNull(ft.getTitle());
	}

}
