package uo.mp.s5.shapes;

public enum Colour {
	RED, GREEN, BLUE, WHITE, BLACK, YELLOW
}
