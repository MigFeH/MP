package uo.mp.s5.shapes;

import java.io.PrintStream;

import uo.mp.s5.drawing.interfacerepository.Drawable;
import uo.mp.util.ArgumentsCheck;

public class Circle extends Shape implements Drawable {

	private int radius;
	
	public Circle(int x, int y, int radius, Colour colour)
	{
		super(x,y,colour);

		ArgumentsCheck.isTrue(radius > 0);
		
		this.radius = radius;
	}


	public int getRadius()
	{
		return this.radius;
	}

	@Override
	public void draw(PrintStream out) {
		out.println("Dibujando un circulo (" + getX() + "," + getY() + ")" +
				" Radio: " + getRadius() + " Color: " + getColour());
	}
	
	
	
	
}
