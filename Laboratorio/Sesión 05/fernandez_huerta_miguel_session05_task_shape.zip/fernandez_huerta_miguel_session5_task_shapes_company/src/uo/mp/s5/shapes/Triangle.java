package uo.mp.s5.shapes;

import java.io.PrintStream;

import uo.mp.s5.drawing.interfacerepository.Drawable;
import uo.mp.util.ArgumentsCheck;

public class Triangle implements Drawable {
	
	private int x1;
	private int y1;
	
	private int x2;
	private int y2;
	
	private int x3;
	private int y3;
	
	private Colour colour;

	
	public Triangle(int x1, int y1, int x2, int y2, int x3, int y3, Colour colour) 
	{
		super();
		
		ArgumentsCheck.isTrue(x1 > 0);
		ArgumentsCheck.isTrue(y1 > 0);
		
		ArgumentsCheck.isTrue(x2 > 0);
		ArgumentsCheck.isTrue(y2 > 0);
		
		ArgumentsCheck.isTrue(x3 > 0);
		ArgumentsCheck.isTrue(y3 > 0);
		
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.x3 = x3;
		this.y3 = y3;
		this.colour = colour;
	}


	public int getX1() {
		return x1;
	}


	public int getY1() {
		return y1;
	}


	public int getX2() {
		return x2;
	}


	public int getY2() {
		return y2;
	}


	public int getX3() {
		return x3;
	}


	public int getY3() {
		return y3;
	}


	public Colour getColour() {
		return colour;
	}


	@Override
	public void draw(PrintStream out) {
		out.println("Dibujando un tri�ngulo (" + getX1() + "," + getY1() + ")" +
				"(" + getX2() + "," + getY2() + ")" + 
				"(" + getX3() + "," + getY3() + ")" + 
				" Colour: " + getColour());
		
	}
	
	
	
	
}
