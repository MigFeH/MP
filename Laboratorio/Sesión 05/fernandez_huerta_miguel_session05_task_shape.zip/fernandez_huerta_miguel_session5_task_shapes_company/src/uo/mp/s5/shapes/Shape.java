package uo.mp.s5.shapes;

import uo.mp.s5.drawing.interfacerepository.Drawable;
import uo.mp.util.ArgumentsCheck;

public abstract class Shape implements Drawable {

	protected int x;
	protected int y;
	protected Colour colour;

	public Shape(int x, int y , Colour colour) {
		super();
		
		ArgumentsCheck.isTrue(x > 0);
		ArgumentsCheck.isTrue(y > 0);
		
		this.x = x;
		this.y = y;
		this.colour = colour;
		
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public Colour getColour() {
		return colour;
	}

}