package uo.mp.s5.shapes;

import java.io.PrintStream;

import uo.mp.s5.drawing.interfacerepository.Drawable;
import uo.mp.util.ArgumentsCheck;

/**
 * A rectangle specifies an area in a coordinate space that is enclosed by the
 * the rectangle upper-left point (x, y) in the coordinate space, its width, and
 * its height.
 */
public class Rectangle extends Shape {

	/**
	 * The width of the rectangle, in pixels.
	 */
	private int width;

	/**
	 * The height of the rectangle, in pixels.
	 */
	private int height;

	public Rectangle(int x, int y, int width, int height, Colour colour) {
		super(x,y,colour);
		
		ArgumentsCheck.isTrue(width >= 0);
		ArgumentsCheck.isTrue(height >= 0);

		
		this.width = width;
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public void draw(PrintStream out) {
		out.println("Dibujando un rect�ngulo (" 
				+ getX() + "," + getY() + ") Alto: "
				+ getWidth() + " Ancho: "
				+ getHeight() + " Color: "
				+ getColour());
		
	}

}
