package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;


public class Game2048WithoutParamsTest {
	
	/**
	 * Prueba del constructor del tablero de juego de la clase Game2048 sin par�metros
	 */
	@Test
	public void testGame2048WithoutParams()
	{
		Game2048 board = new Game2048();
		
		assertEquals(Game2048.MIN_ROWS, board.getBoard().length);
		assertEquals(Game2048.MIN_COLUMNS, board.getBoard()[0].length);
	}
	
}
