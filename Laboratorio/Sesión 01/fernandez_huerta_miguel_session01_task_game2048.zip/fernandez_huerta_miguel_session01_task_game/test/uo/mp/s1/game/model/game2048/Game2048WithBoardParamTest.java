package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;

public class Game2048WithBoardParamTest {
	
	/*
	 * Casos de uso:
	 * 1-Que el par�metro sea null (excepci�n)
	 * 2-Que el par�metro supere el m�ximo de filas permitidas (excepci�n)
	 * 3-Que el par�metro supere el m�ximo de columnas permitidas (excepci�n)
	 * 4-Que el par�metro sea v�lido
	 */
	
	/**
	 * Prueba 1 del constructor
	 * Que el par�metro sea null (excepci�n)
	 */
	@Test
	public void testGame2048WithNullParam()
	{
		try
		{
			int[][] matriz = null;
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * Prueba 2 del constructor
	 * Que el par�metro supere el m�ximo de filas permitidas (excepci�n)
	 */
	@Test
	public void testGame2048WithTooMuchRowsParam()
	{
		try
		{
			int[][] matriz = {{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0}};
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * Prueba 3 del constructor
	 * Que el par�metro supere el m�ximo de columnas permitidas (excepci�n)
	 */
	@Test
	public void testGame2048WithTooMuchColumnsParam()
	{
		try
		{
			int[][] matriz = {{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0},{2,0,0,0,0,0,0,0,0,0,0,0}};
			Game2048 board = new Game2048(matriz);
			board.getBoard();
		} catch (IllegalArgumentException e)
		{
			assertEquals("Tablero inadecuado o null" ,e.getMessage());
		}	
	}
	
	/**
	 * Prueba 4 del constructor
	 * Que el par�metro sea v�lido
	 */
	@Test
	public void testGame2048WithCorrectParam()
	{
		int matriz[][] = {{2,0,0},{0,0,0},{2,0,2}};
		Game2048 board = new Game2048(matriz);
		
		assertArrayEquals(matriz, board.getBoard());
	}
	
}
