package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;

public class CompactUpTest {
	/*
	 * Casos de uso:
	 * 1- Matriz con un valor por columna en fila 2
	 * 2- Matriz con un valor por columna en fila 1
	 * 3- Matriz con un valor por columna en fila 0
	 * 
	 * 4- Matriz con 2 valores por columna (en 1 y 2)
	 * 5- Matriz con 2 valores por columna (en 0 y 1)
	 * 6- Matriz con 2 valores por columna (en 0 y 2)
	 * 
	 * 7- Matriz con 3 valores por columna
	 * 
	 */
	
	/**
	 * Casos de uso
	 * 1. Matriz con un valor por columna en fila 2
	 */
	@Test
	public void testOneValueForColumnInRow2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL33);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL3_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 2- Matriz con un valor por columna en fila 1
	 */
	@Test
	public void testOneValueForColumnInRow1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL32);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL3_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 3- Matriz con un valor por columna en fila 0
	 */
	@Test
	public void testOneValueForColumnInRow0() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL31);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL3_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 4- Matriz con 2 valores por columna (en 1 y 2)
	 *
	 */
	@Test
	public void testTwoValuesForColumnInRow1And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL41);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL4_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 5- Matriz con 2 valores por columna (en 0 y 1)
	 *
	 */
	@Test
	public void testTwoValuesForColumnInRow0And1() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL43);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL4_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 6- Matriz con 2 valores por columna (en 0 y 2)
	 *
	 */
	@Test
	public void testTwoValuesForRowInColumn0And2() {
		Game2048 game = new Game2048(CodeForTest.SEMIFULL42);
		game.compactUp();
		assertArrayEquals(CodeForTest.SEMIFULL4_UPCOMPACTED, game.getBoard());
	}
	
	/**
	 * Casos de uso
	 * 7- Matriz con 3 valores por columna
	 *
	 */
	@Test
	public void testThreeValuesForRow() {
		Game2048 game = new Game2048(CodeForTest.FULL);
		game.compactUp();
		assertArrayEquals(CodeForTest.FULL, game.getBoard());
	}	
}
