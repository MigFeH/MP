package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;


public class Game2048WithIntParamTest {
	/*
	 * Casos de uso:
	 * 1-Que el par�metro sea 0
	 * 2-Que el par�metro sea negativo
	 * 3-Que el par�metro sea mayor que 10
	 * 4-Que el par�metro sea correcto
	 */
	
	/**
	 * Prueba 1 del constructor
	 * Que el par�metro sea 0
	 */
	@Test
	public void testGame2048WithParam0()
	{
		Game2048 board = new Game2048(0);
		
		assertEquals(Game2048.MIN_ROWS, board.getBoard().length);
		assertEquals(Game2048.MIN_COLUMNS, board.getBoard()[0].length);
	}
	
	/**
	 * Prueba 2 del constructor
	 * Que el par�metro sea negativo
	 */
	@Test
	public void testGame2048WithNegativeParam()
	{
		Game2048 board = new Game2048(-10);
		
		assertEquals(Game2048.MIN_ROWS, board.getBoard().length);
		assertEquals(Game2048.MIN_COLUMNS, board.getBoard()[0].length);
	}
	
	/**
	 * Prueba 3 del constructor
	 * Que el par�metro sea mayor que 10
	 */
	@Test
	public void testGame2048WithHigherThan10Param()
	{
		Game2048 board = new Game2048(11);
		
		assertEquals(Game2048.MIN_ROWS, board.getBoard().length);
		assertEquals(Game2048.MIN_COLUMNS, board.getBoard()[0].length);
	}
	
	/**
	 * Prueba 4 del constructor
	 * Que el par�metro sea v�lido
	 */
	@Test
	public void testGame2048WithCorrectParam()
	{
		Game2048 board = new Game2048(5);
		
		assertEquals(5, board.getBoard().length);
		assertEquals(5, board.getBoard()[0].length);
	}
	
	
}
