package uo.mp.s1.game.model.game2048;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import uo.mp.s1.game.model.Game2048;

public class NextTest {
	
	/*
	 * Casos de uso:
	 * 1-Que la matriz est� vac�a
	 * 2-Que la matriz est� medio llena
	 * 3-Que la matriz est� llena
	 */

	/**
	 * Prueba 1 del m�todo next
	 * Que la matriz est� vac�a
	 */
	@Test
	public void testNextWithVoidBoard()
	{
		Game2048 board = new Game2048();
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(1,t);
	}
	
	/**
	 * Prueba 2 del m�todo next
	 * Que la matriz est� medio llena
	 */
	@Test
	public void testNextWithHalfEmptyBoard()
	{
		Game2048 board = new Game2048();
		
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				board.getBoard()[i][j] = 2;
			}
		}
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(7,t);
	}
	
	/**
	 * Prueba 3 del m�todo next
	 * Que la matriz est� llena
	 */
	@Test
	public void testNextWithFullBoard()
	{
		Game2048 board = new Game2048();
		
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				board.getBoard()[i][j] = 2;
			}
		}
		
		board.next();
		
		int t = 0;
		for (int i = 0; i < board.getBoard().length; i++)
		{
			for (int j = 0; j < board.getBoard()[0].length; j++)
			{
				if (board.getBoard()[i][j] != 0)
				{
					t = t + 1;
				}
			}
		}
		assertEquals(9,t);
	}
	
}
