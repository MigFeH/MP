package uo.mp.s1.game.model;

import java.util.Random;

/**
 * <p>
 * T�tulo: Clase Game2048
 * </p>
 * <p>
 * Descripci�n: A partir de un array bidimensional de n�meros y a trav�s de
 * diferentes operaciones se simula un juego llamado "2048"
 * </p>
 * <p>
 * Copyright: Copyright (c) 2022
 * </p>
 * <p>
 * Empresa: Escuela de Ingenier�a Inform�tica - Universidad de Oviedo
 * </p>
 * 
 * @author Miguel
 * @version 1/2/2022
 */
public class Game2048 {
	public static final int MIN_ROWS = 3; // N�mero m�nimo de filas del tablero
	public static final int MIN_COLUMNS = 3; // N�mero m�nimo de columnas del tablero
	
	public static final int MAX_ROWS = 10; // N�mero m�ximo de filas del tablero
	public static final int MAX_COLUMNS = 10; // N�mero m�ximo de columnas del tablero
	
	private int[][] board; // Tablero de juego

	/**
	 * Constructor sin par�metros con tablero por defecto de 3*3 Inicialmente 
	 * todas las posiciones con valor 0
	 */
	public Game2048() {
		this.board = new int[MIN_ROWS][MIN_COLUMNS];	// Tablero creado con las dimensiones m�nimas posibles
	}

	/**
	 *Constructor que recibe el tama�o del tablero
	 *
	 *@param size, el tama�o del tablero con longitudes limitadas entre [1,10]
	 */
	public Game2048(int size) {
		if (size <= 0 || size > 10) // Si el tama�o pasado por par�metro es menor o igual que 0, o mayor que 10...
		{
			this.board = new int[MIN_ROWS][MIN_COLUMNS]; // Crea el tablero con las dimensiones m�nimas posibles
		} else { // En caso contrario...
			this.board = new int[size][size]; // Crea el tablero con las dimensiones pasadas por par�metro
		}
	}
	
	/**
	 * Inicializa el tablero con la matriz pasada como par�metro
	 * 
	 * @param board, la matriz tablero
	 */
	public Game2048(int[][] board) {
		// Comprobaci�n de si el par�metro es null; de si el tablero par�metro tiene dimensiones inferiores a 0 o superiores a 10
		checkParam(board != null && board.length > 0 && board.length < 11, "Tablero inadecuado o null"); 
		
		int t = 0; /* Creaci�n de una variable local que guardar� el tama�o m�ximo de columnas del tablero par�metro y comprobar�
		que, a partir del tama�o guardado en la variable, el resto de columnas tienen el mismo tama�o */
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i].length >= t) // Si el tama�o de una columna es superior a t...
				{
					t = board[i].length; // t guardar� el tama�o de la columna
				}
			}
		}
		
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			checkParam(board[i].length == t, "Tablero inadecuado o null"); // Comprobaci�n de que todas las columnas son de igual tama�o
		}
		
		this.board = board; // Crea e inicializa un tablero con las dimensiones y valores de la matriz par�metro
	}

	/**
	 * Devuelve una copia de la matriz para poder usarla en las pruebas
	 * 
	 * @return board, el tablero
	 */
	public int[][] getBoard() {
		return board;
	}
	
	
	/**
	 * Reinicia todas las posiciones a 0 y llama a next para que incluya un
	 * 2 en una posici�n aleatoria
	 */
	public void restart() {
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				board[i][j] = 0; // Guarda en cada posici�n del tablero un 0
			}
		}
		this.next(); // Llamada al m�todo next para completar la funci�n del m�todo
	}
	
	
	/**
	 * A�ade un nuevo  2 en una posici�n aleatoria vac�a
	 * siempre que exista alguna
	 */
	public void next() {
		Random random = new Random(); // Creaci�n de un objeto random de la clase Random
		boolean t = this.isBoardFull(); // Creaci�n de una variable local que guarda el resultado de la ejecuci�n del m�todo isBoardFull()
		
		if (t == false) // Si el resultado de la ejecuci�n del m�todo isBoardFull() es false...
		{

			for (int i = 0; i < board.length; i++)
			{
				int a = random.nextInt(board.length); // Creaci�n de una variable local que tomar� valores aleatorios correspondientes a cada fila del tablero
				int b = random.nextInt(board[0].length); // Creaci�n de una variable local que tomar� valores aleatorios correspondientes a cada columna del tablero
					
				if (board[a][b] == 0) // Si el elemento en la fila a y columna b es 0...
				{
					board[a][b] = 2; // Que se guarde en esa posici�n un 2
					break; // Que rompa el bucle
				}
			}
		}
	}
	
	/**
	 * Comprueba si el tablero est� lleno. Esto ocurre cuando todas las celdas
	 * o posiciones del tablero tienen un n�mero distinto de cero
	 * 
	 * @return true (si el tablero est� lleno) o false (si el tablero no est� lleno)
	 */
	public boolean isBoardFull() {
		boolean p = true; // Creaci�n de una variable local inicializada a true; �sta variable ser� la que guarde el resultado de si el tablero est� lleno o no
		for(int i = 0; i < board.length; i++) // Recorrido por filas
		{
			for(int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i][j] != 0) // Si en la posici�n i,j no hay un 0...
				{
					p = true; 
				} else // En caso contrario...
				{
					return false;
				}
			}
		}
		return p;
	}
	
	/**
	 * Compacta el tablero a la izquierda, 
	 * dejando en cada fila todos los valores positivos consecutivos 
	 * en las primeras posiciones
	 * y todos los ceros en las �ltimas posiciones de la fila
	 */
	public void compactLeft() {
		int[][] copy = new int[board.length][board[0].length]; // Creaci�n de una matriz variable local con las dimensiones del tablero
		
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			int k = 0;
			for(int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{	
				if (board[i][j] != 0) // Si en la posici�n i,j no hay un 0...
				{
					copy[i][k++] = board[i][j];
				}
			}
		}
		this.board = copy; // board guarda el resultado de la ejecuci�n del m�todo
	}

	/**
	 * Compacta el tablero a la derecha, 
	 * dejando en cada fila todos los valores positivos consecutivos 
	 * en las �ltimas posiciones de la fila 
	 * y todos los ceros en las primeras posiciones de la fila
	 */
	public void compactRight() {
		int copy[][] = new int[board.length][board[0].length]; // Creaci�n de una matriz variable local con las dimensiones del tablero
		
		for (int i = 0; i < board.length; i++) // Recorrido por filas
		{
			int k = board.length - 1;
			for (int j = 0; j < board[i].length; j++) // Recorrido por columnas
			{
				if (board[i][j] != 0) // Si en la posici�n i,j no hay un 0...
				{
					copy[i][k--] = board[i][j];
				}
			}
		}
		this.board = copy; // board guarda el resultado de la ejecuci�n del m�todo
	}
	
	
	
	/**
	 * Compacta el tablero hacia arriba, 
	 * dejando en cada columna todos los valores positivos consecutivos 
	 * en las primeras posiciones 
	 * y todos los ceros en las �ltimas posiciones
	 */
	public void compactUp() {
		int copy[][] = new int[board.length][board[0].length];
		
		for (int j = 0; j < board[0].length; j++)
		{
			int k = 0;
			for (int i = 0; i < board.length; i++)
			{
				if (board[i][j] != 0)
				{
					copy[k++][j] = board[i][j]; 
				}
			}
		}
		this.board = copy;
	}
	
	/**
	 * Compacta el tablero hacia abajo, 
	 * dejando en cada columna todos los valores positivos consecutivos 
	 * en las �ltimas posiciones 
	 * y todos los ceros en las primeras posiciones
	 */
	public void compactDown() {
		int copy[][] = new int[board.length][board[0].length];
		
		for (int j = 0; j < board[0].length; j++)
		{
			int k = board.length - 1;
			for (int i = 0; i < board.length; i++)
			{
				if (board[i][j] != 0)
				{
					copy[k--][j] = board[i][j];
				}
			}
		}
		this.board = copy;
	}
	
	
	/**
	 * Devuelve un String con los datos de la matriz en formato para ser mostrado por pantalla
	 * Con un blanco entre dos elementos consecutivos de la fila
	 * Ejemplo:
	 *    2 2 0
	 *    2 0 0
	 *    2 0 2
	 *    
	 *	@return el toString con los datos de la matriz en el formato antes se�alado
	 */
	public String toString() {
		String data1 = "";
		for (int i = 0; i < board.length; i++)
		{
			for (int j = 0; j < board[i].length; j++)
			{
				data1 = data1 + board[i][j] + " ";
			}
			data1 = data1 + "\n";
		}
		return "\n" + data1;
	}
	
	
	/**
	 * Eval�a una condici�n y, si es falsa, lanza una excepci�n con un mensaje
	 * 
	 * @param condition, la condici�n a evaluar
	 * @param msg, el mensaje de la excepci�n
	 */
	private void checkParam(boolean condition, String msg)
	{
		if (!condition) // Si la condici�n no se cumple...
		{
			throw new IllegalArgumentException(msg); // Lanzar excepci�n con el mensaje pasado por par�metro
		}
	}
	
}
