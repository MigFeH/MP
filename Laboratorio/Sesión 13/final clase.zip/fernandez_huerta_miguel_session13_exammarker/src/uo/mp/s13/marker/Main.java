package uo.mp.s13.marker;

import uo.mp.s13.marker.simulator.Simulator;

public class Main {

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		new Simulator().start();	
	}
}
