package uo.mp.s13.marker.model.question;

import uo.mp.util.ArgumentsCheck;

public class ChoiceQuestion extends Question {

	private String rightAnswer;

	/**
	 * 
	 * @param weight
	 * @param rightAnswer
	 * @throws IllegalArgumentException if
	 * 			* weight <= 0
	 * 			* rightAnswer is null or blank
	 */
	public ChoiceQuestion(int number, double weight, String rightAnswer) {
		super( number, weight );
		ArgumentsCheck.isTrue(!rightAnswer.isBlank() || rightAnswer != null);
		this.rightAnswer = rightAnswer;
	}

	/**
	 * 
	 * @param answer
	 * @return
	 * @throws IllegalArgumentException if answer is null or blank
	 */
	@Override
	public double mark(String answer) {
		ArgumentsCheck.isTrue(!answer.isBlank() || answer != null);
		return getRightAnswer().equals( answer ) 
				? getWeight() 
				: getWeight() * -0.2;
	}

	public String getRightAnswer() {
		return rightAnswer;
	}

}
