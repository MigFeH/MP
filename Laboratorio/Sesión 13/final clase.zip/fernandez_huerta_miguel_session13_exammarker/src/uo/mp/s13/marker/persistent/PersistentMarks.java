package uo.mp.s13.marker.persistent;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import uo.mp.s13.marker.exception.ExamMarkerException;
import uo.mp.s13.marker.service.ExamMarker;

public class PersistentMarks implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private static final String databaseName = "marksDatabase.dat";

	private ExamMarker em = new ExamMarker();
	
	public void updateDatabase() throws ExamMarkerException {
		try
		{
			ObjectOutputStream os = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(databaseName)));
			try
			{
				os.writeObject(em);
			}finally
			{
				os.close();
			}
		}catch(IOException e)
		{
			throw new ExamMarkerException(e.getMessage());
		}
	}

}
