package uo.mp.s13.marker.parser.questionParser;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s13.marker.model.question.Question;
import uo.mp.s13.marker.parser.QuestionParser;

public class ParseTests {
	
	private List<String> nullList; // lista de preguntas null
	
	private List<String> emptyLineList; // lista con l�nea vac�a
	
	private List<String> typeUnknowedLineList; // lista con l�nea de pregunta de tipo desconocido
	
	private List<String> notValidChoiceQuestion; // lista con pregunta de tipo Choice con n� de campos incorrecto
	private List<String> notValidGapQuestion; // lista con pregunta de tipo Gap con el n� de campos incorrecto
	private List<String> notValidValueQuestion; // lista con pregunta de tipo Value con el n� de campos incorrecto
	
	private List<String> questionsList; // lista con preguntas v�lidas de tipo Choice, Gap y Value
	
	private List<String> choiceQuestionList; // lista con preguntas v�lidas de tipo Choice
	private List<String> gapQuestionList; // lista con preguntas v�lidas de tipo Gap
	private List<String> valueQuestionList; // lista con preguntas v�lidas de tipo Value
	
	
	/**
	 * 1- Lista de l�neas de preguntas null (IllegalArgumentException)
	 * 
	 * 2- L�nea vac�a de preguntas
	 * 
	 * 3- Tipo de pregunta distinto de los conocidos
	 * 
	 * 4- L�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Choice
	 * 5- L�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Gap
	 * 6- L�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Value
	 * 
	 * 7- Lista de preguntas v�lidas de tipo Choice, Gap y Value
	 * 
	 * 8- Lista de pregunta v�lida de tipo Choice
	 * 9- Lista de pregunta v�lida de tipo Gap
	 * 10- Lista de pregunta v�lida de tipo Value
	 */
	
	@Before
	public void setUp()
	{	
		nullList = null; // lista de preguntas null
		
		emptyLineList = new ArrayList<>(); // lista con l�nea vac�a
		
		emptyLineList.add("choice	1.0	a");
		emptyLineList.add(" ");
		emptyLineList.add("gap	0.5	stuff");
		
		typeUnknowedLineList = new ArrayList<>(); // lista con l�nea de pregunta de tipo desconocido
		
		typeUnknowedLineList.add("choice	1.0	a");
		typeUnknowedLineList.add("justifica la respuesta	2.0	b");
		
		notValidChoiceQuestion = new ArrayList<>(); // lista con pregunta de tipo Choice con n� de campos incorrecto
		
		notValidChoiceQuestion.add("choice	1.0	a");
		notValidChoiceQuestion.add("choice	1.0	a	b");
		
		notValidGapQuestion = new ArrayList<>(); // lista con pregunta de tipo Gap con el n� de campos incorrecto
		
		notValidGapQuestion.add("gap	0.5	stuff");
		notValidGapQuestion.add("gap	0.5	stuff	staff");
		
		notValidValueQuestion = new ArrayList<>(); // lista con pregunta de tipo Value con el n� de campos incorrecto
		
		notValidValueQuestion.add("value	1.5	12.5");
		notValidValueQuestion.add("value	1.5	12.5	19.11");
		
		questionsList = new ArrayList<>(); // lista con preguntas v�lidas de tipo Choice, Gap y Value
		
		questionsList.add("choice	1.0	a");
		questionsList.add("gap	0.5	stuff");
		questionsList.add("value	1.5	12.5");
		
		choiceQuestionList = new ArrayList<>(); // lista con preguntas v�lidas de tipo Choice
		
		choiceQuestionList.add("choice	1.0	a");
		choiceQuestionList.add("choice	1.0	b");
		
		gapQuestionList = new ArrayList<>(); // lista con preguntas v�lidas de tipo Gap
		
		gapQuestionList.add("gap	0.5	stuff");
		gapQuestionList.add("gap	0.5	computer");
		
		valueQuestionList = new ArrayList<>(); // lista con preguntas v�lidas de tipo Value
		
		valueQuestionList.add("value	1.5	12.5");
		valueQuestionList.add("value	1.5	100.0");
	}
	
	
	/**
	 * GIVEN: lista de l�neas de preguntas null
	 * WHEN: se invoca al m�todo parse()
	 * THEN: salta IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testParseWithNullListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		qp.parse(nullList);
	}
	
	/**
	 * GIVEN: lista con l�nea vac�a de preguntas
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos del tipo de pregunta
	 */
	@Test
	public void testParseWithEmptyListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(emptyLineList);
		
		assertEquals("Question [questionNumber=1, weight=1.0]", aux.get(0).toString());
		assertEquals("Question [questionNumber=3, weight=0.5]", aux.get(1).toString());
	}
	
	/**
	 * GIVEN: lista con una pregunta de un tipo distinto de los conocidos
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos del tipo de pregunta conocidos
	 */
	@Test
	public void testParseWithOneUnknowTypeQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(typeUnknowedLineList);
		
		assertEquals("Question [questionNumber=1, weight=1.0]", aux.get(0).toString());
	}
	
	/**
	 * GIVEN: lista con una l�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Choice
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos que tengan el n�mero de campos correcto
	 */
	@Test
	public void testParseWithNotValidChoiceQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(notValidChoiceQuestion);
		
		assertEquals("Question [questionNumber=1, weight=1.0]", aux.get(0).toString());
	}
	
	/**
	 * GIVEN: lista con una l�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Gap
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos que tengan el n�mero de campos correcto
	 */
	@Test
	public void testParseWithNotValidGapQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(notValidGapQuestion);
		
		assertEquals("Question [questionNumber=1, weight=0.5]", aux.get(0).toString());
	}
	
	/**
	 * GIVEN: lista con una l�nea de pregunta con un n�mero de campos no correspondiente con el de una pregunta de tipo Value
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos que tengan el n�mero de campos correcto
	 */
	@Test
	public void testParseWithNotValidValueQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(notValidValueQuestion);
		
		assertEquals("Question [questionNumber=1, weight=1.5]", aux.get(0).toString());
	}
	
	/**
	 * GIVEN: lista de preguntas v�lidas de tipo Choice, Gap y Value
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos de los tipos antes mencionados
	 */
	@Test
	public void testParseWithValidListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(questionsList);
		
		assertEquals("Question [questionNumber=1, weight=1.0]", aux.get(0).toString());
		assertEquals("Question [questionNumber=2, weight=0.5]", aux.get(1).toString());
		assertEquals("Question [questionNumber=3, weight=1.5]", aux.get(2).toString());
	}
	
	/**
	 * GIVEN: lista de pregunta v�lida de tipo Choice
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos de los tipos antes mencionados
	 */
	@Test
	public void testParseWithValidChoiceQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(choiceQuestionList);
		
		assertEquals("Question [questionNumber=1, weight=1.0]", aux.get(0).toString());
		assertEquals("Question [questionNumber=2, weight=1.0]", aux.get(1).toString());
	}
	
	/**
	 * GIVEN: lista de pregunta v�lida de tipo Gap
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos de los tipos antes mencionados
	 */
	@Test
	public void testParseWithValidGapQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(gapQuestionList);
		
		assertEquals("Question [questionNumber=1, weight=0.5]", aux.get(0).toString());
		assertEquals("Question [questionNumber=2, weight=0.5]", aux.get(1).toString());
	}
	
	/**
	 * GIVEN: lista de pregunta v�lida de tipo Value
	 * WHEN: se invoca al m�todo parse()
	 * THEN: se crean los objetos de los tipos antes mencionados
	 */
	@Test
	public void testParseWithValidValueQuestionListOfQuestions()
	{
		QuestionParser qp = new QuestionParser();
		
		List<Question> aux = qp.parse(valueQuestionList);
		
		assertEquals("Question [questionNumber=1, weight=1.5]", aux.get(0).toString());
		assertEquals("Question [questionNumber=2, weight=1.5]", aux.get(1).toString());
	}
}
