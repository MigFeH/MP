package uo.mp.s13.marker.parser.questionParser;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ParseTests.class })
public class AllTests {

}
