package uo.mp.s13.marker.service.examMarker;

import static org.junit.Assert.*;

import org.junit.Test;

public class SerializeTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
