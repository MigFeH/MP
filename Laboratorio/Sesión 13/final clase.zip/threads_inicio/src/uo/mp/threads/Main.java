package uo.mp.threads;

public class Main {
	public static void main(String[] args) {		
		Saludador s1 = new Saludador("Pepe", 20);
		Saludador s2 = new Saludador("Ana", 20);
		
		Thread t1 = new Thread(s1); // creaci�n de hilo para s1
		Thread t2 = new Thread(s2); // creaci�n de hilo para s2
		
		t1.start(); // llama al run y empieza el hilo
		t2.start(); // llama al run y empieza el hilo
		
		try 
		{
			t1.join(); // el hilo de ejecuci�n para hasta que t1 acaba
			t2.join(); // el hilo de ejecuci�n para hasta que t2 acaba
		} catch (InterruptedException e) 
		{
			// nada
		}
		
		System.out.println("Hemos sido suficientemente educados");
	}
}
