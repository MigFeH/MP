package numeros;

public class PairAndOdd {

	public static void main(String[] args)
	{
		Odd odd = new Odd();
		Pair pair = new Pair();
		
		Thread tOdd = new Thread(odd);
		
		pair.start();
		tOdd.start();
		
		try {
			pair.join();
			tOdd.join();
		} catch (InterruptedException e)
		{
			// nada
		}
		
		System.out.println("Se acab�");
	}

}
