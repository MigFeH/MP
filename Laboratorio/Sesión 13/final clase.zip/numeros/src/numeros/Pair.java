package numeros;

public class Pair extends Thread {
	
	private void showPair()
	{
		for(int i = 0; i <= 100; i = i + 2)
		{
			System.out.println("Par.................." + i);
		}
	}
	
	public void run()
	{
		showPair();
	}
}
