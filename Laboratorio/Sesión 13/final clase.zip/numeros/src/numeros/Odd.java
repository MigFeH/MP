package numeros;

public class Odd implements Runnable {
	
	private void showOdd()
	{
		for(int i = 1; i < 100; i = i + 2)
		{
			System.out.println("Impar......" + i);
		}
	}
	
	@Override
	public void run() 
	{
		showOdd();	
	}
	
	
}
