package uo.mp.s4.post.post.message;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.post.post.Message;

public class ToStringTest {

	/**
	 * GIVEN: Par�metros v�lidos
	 * WHEN: Se llama al toString
	 * THEN: Se ejecuta el m�todo correctamente
	 */
	@Test
	public void testToStringWithCorrectParams()
	{
		Message mg = new Message("Paco",
				"Los huevos de pascua de san andreas en particular tienen la "
				+ "facultad de ser oscuros, y muy... tetricos * clin *");
		
		assertEquals("Message User: Paco msg: Los huevos de pascua de san "
				+ "andreas en particular tienen la facultad de ser oscuros, "
				+ "y muy... tetricos * clin *", mg.toString());
	}
}
