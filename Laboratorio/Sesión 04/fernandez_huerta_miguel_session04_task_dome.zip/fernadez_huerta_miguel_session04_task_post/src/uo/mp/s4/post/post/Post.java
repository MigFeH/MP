package uo.mp.s4.post.post;

import java.util.ArrayList;

import uo.mp.util.ArgumentsCheck;

public abstract class Post{
	
	private int likes; // Likes por post
	private ArrayList<String> comments; // Lista de comentarios por post
	private String userName; // Nombre del usuario
	
	
	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param el nombre del usuario del post
	 */
	public Post(String userName)
	{
		setUserName(userName);
		comments = new ArrayList<String>();
		setLikes(0);
	}	

	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	private void setLikes(int likes) 
	{
		ArgumentsCheck.isTrue(likes >= 0, "N�mero de likes no v�lido");
		this.likes = likes;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en dicho atributo
	 */
	public int getLikes()
	{
		return likes;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	public void setComments(String comment) 
	{
		ArgumentsCheck.isTrue(comment != null, 
				"Esperaba comentario pero fue null");
		this.comments.add(comment);
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en dicho atributo
	 */
	public ArrayList<String> getComments()
	{
		return comments;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param nuevo valor para atributo
	 */
	private void setUserName(String name) 
	{
		ArgumentsCheck.isTrue(name != null, "Esperaba nombre pero fue null");
		this.userName = name;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public String getUserName()
	{
		return userName;
	}
	
	
	/**
	 * Retorna los atributos de las subclases
	 */
	public String toString()
	{
		return "";
	}
	
	public abstract String htmlFormat();
}
