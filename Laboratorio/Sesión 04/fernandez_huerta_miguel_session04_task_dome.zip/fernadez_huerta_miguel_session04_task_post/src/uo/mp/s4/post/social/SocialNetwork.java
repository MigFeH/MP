package uo.mp.s4.post.social;

import java.util.ArrayList;

import uo.mp.s4.post.post.Post;
import uo.mp.util.ArgumentsCheck;

public class SocialNetwork {
	
	private ArrayList<Post> posts = new ArrayList<Post>(); // Lista con los post
	
	
	/**
	 * A�ade el post a la red de un usuario
	 * 
	 * @param el post a a�adir
	 */
	public void addPost(Post post)
	{
		ArgumentsCheck.isTrue(post != null, "Esperaba post pero fue null");
		this.posts.add(post);
	}
	
	
	/**
	 * Retorna el ArrayList de posts
	 * 
	 * @return la lista de posts
	 */
	public ArrayList<Post> getPosts()
	{
		return posts;
	}
	
	
	/**
	 * Retorna los atributos de todos los post cada uno en una l�nea
	 * 
	 * @return los atributos de todos los post
	 */
	public String getAllPosts()
	{
		String data = "";
		
		for(Post thePost: posts)
		{
			data = data + thePost.toString() + "\n";
		}
		return data;
	}
	
	
	/**
	 * Recibe un usuario como par�metro y devuelve la lista de todos los post 
	 * correspondientes a dicho usuario
	 * 
	 * @param el usuario a buscarle los posts
	 * @return la lista con los posts correspondientes
	 */
	public ArrayList<Post> findPostsByUser(String userId)
	{
		ArgumentsCheck.isTrue(userId != null, "Esperaba usuario pero fue null");
		
		ArrayList<Post> p1 = new ArrayList<Post>();
		for(Post thePost: posts)
		{
			if (thePost.getUserName() == userId)
			{
				p1.add(thePost);
			}
		}
		return p1;
	}
	
	
	/**
	 * Devuelve una lista de cadenas con todos los post formateados en html, 
	 * teniendo en cuenta que:
	 * 
	 * a. En caso de que el post sea un mensaje el formato html que devuelve 
	 * ser�:
	 * 		<p> mensaje </p>.
	 * 
	 * b. En caso de que sea una foto devolver�:
	 * 		<img src= �nombrefichero�>t�tulo</img>
	 * 
	 * @return la lista de cadenas con todos los post en formato html
	 */
	public String toHtmlFormat()
	{
		String data = "";
		for(Post thePost: posts)
		{
			data = data + thePost.htmlFormat() + "\n";
		}
		return data;
	}
}
