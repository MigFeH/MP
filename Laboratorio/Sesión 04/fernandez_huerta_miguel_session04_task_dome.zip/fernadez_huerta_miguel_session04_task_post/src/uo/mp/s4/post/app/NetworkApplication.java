package uo.mp.s4.post.app;

import uo.mp.s4.post.post.*;
import uo.mp.s4.post.social.*;

public class NetworkApplication {

	public void Run()
	{	
		Post u1 = new Message("Pablo", "Pepega el meme del a�o");
		Post u2 = new Photo("Pablo",Fich.CAMPOS,"Mira estos campos");
		
		Post u3 = new Message("Pedro Paco Carlos Luis Jos�", 
				"Pepega el meme del a�o");
		Post u4 = new Photo("Pedro Paco Carlos Luis Jos�",
				Fich.CAMPOS,"Mira estos campos");
		
		SocialNetwork sn1 = new SocialNetwork();
		
		sn1.addPost(u1);
		sn1.addPost(u2);
		
		sn1.addPost(u3);
		sn1.addPost(u4);

		
		System.out.println(sn1.getAllPosts());
		
		System.out.println(sn1.findPostsByUser("Pablo"));
		System.out.println(sn1.findPostsByUser("Pedro Paco Carlos Luis Jos�"));
		
		System.out.println();
		
		System.out.println("Post en formato HTML");
		System.out.println(sn1.toHtmlFormat());
	}
}
