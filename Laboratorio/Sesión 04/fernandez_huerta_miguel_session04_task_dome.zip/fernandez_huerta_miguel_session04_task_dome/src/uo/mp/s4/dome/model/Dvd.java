package uo.mp.s4.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public class Dvd extends Item   {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */

	private String director;

	
	/**
	 * Constructor con par�metros de la clase Dvd
	 * 
	 * @param el t�tulo del dvd
	 * @param el director
	 * @param el tiempo del dvd
	 */
	public Dvd(String theTitle, String theDirector, int time, double basePrice)
	{
		super(theTitle,basePrice);
		setDirector(theDirector);
		setPlayingTime(time);
	}

	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setDirector(String director)
	{
		ArgumentsCheck.isTrue(director != null);
		this.director = director;
	}

	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado
	 */
	public String getDirector()
	{
		return this.director;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado
	 */
	public String getResponsable()
	{
		return this.director;
	}
	
	
	/**
	 * Devuelve en un toString los atributos de la clase
	 * 
	 * @return los atributos de la clase
	 */
	public String toString()
	{
		String data = "";
		data = data + ("DVD: " + getTitle() + " (" + getPlayingTime() + 
				" mins)" + "\n");
		data = data + ("Director: " + getDirector()) + "\n";
		super.toString();
		return data;
	}
	
	public void print(PrintStream out) {
		out.println("DVD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Director: " + getDirector());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
		out.println();
	}
	
	
	@Override
	public boolean isLike(Item itemToSearch)
	{
		if(! (itemToSearch instanceof Dvd) )
		{
			return false;
		}
		Dvd dvdToSearch = (Dvd) itemToSearch;
		if(dvdToSearch.getTitle().equals(this.getTitle()) &&
				dvdToSearch.getDirector().equals(this.getDirector()))
		{
			return true;
		} else {
			return false;
		}
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((director == null) ? 0 : director.hashCode());
		return result;
	}
	
	
	@Override
	public boolean equals(Item itemToSearch)
	{
		if(! (itemToSearch instanceof Dvd) )
		{
			return false;
		}
		Dvd dvdToSearch = (Dvd) itemToSearch;
		if(dvdToSearch.getTitle().equals(this.getTitle()) &&
				dvdToSearch.getDirector().equals(this.getDirector()))
		{
			return true;
		} else {
			return false;
		}
	}

}
