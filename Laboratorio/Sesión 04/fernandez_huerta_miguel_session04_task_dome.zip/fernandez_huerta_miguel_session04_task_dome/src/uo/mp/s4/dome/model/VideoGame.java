package uo.mp.s4.dome.model;

import java.io.PrintStream;

import uo.mp.util.ArgumentsCheck;

public class VideoGame extends Item{
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */
	
	private static final double EXTRA_PRICE = 10; /* Incremento del precio que
	se aplica en el precio base */
	
	private String author; // El autor
	private int players; // El número de jugadores
	private Platform platform; // La plataforma de juego
	
	
	/**
	 * Constructor con parámetros de la clase VideoGame
	 * 
	 * @param title, el título
	 * @param author, el autor
	 * @param players, el número de jugadores
	 * @param form, la plataforma de juego
	 * @param basePrice, el precio base del juego
	 */
	public VideoGame(String title, String author, int players, Platform form,
			double basePrice)
	{
		super(title,basePrice + (basePrice*(EXTRA_PRICE/100)));
		setTitle(title);
		setAuthor(author);
		setPlayers(players);
		setPlatform(form);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo author
	 * 
	 * @param el autor del juego
	 */
	private void setAuthor(String author)
	{
		ArgumentsCheck.isTrue(author != null);
		this.author = author;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo platform
	 * 
	 * @param la plataforma de juego
	 */
	private void setPlatform(Platform form) 
	{
		ArgumentsCheck.isTrue(form != null);
		this.platform = form;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo players
	 * 
	 * @param el número de jugadores
	 */
	private void setPlayers(int players) 
	{
		ArgumentsCheck.isTrue(players >= 0);
		this.players = players;
	}
	
	
	/**
	 * Retorna el valor almacenado en author
	 * 
	 * @return el valor
	 */
	public String getAuthor() 
	{
		return author;
	}
	
	
	/**
	 * Retorna el valor almacenado en platform
	 * 
	 * @return el valor
	 */
	public Platform getPlatform() 
	{
		return platform;
	}
	
	
	/**
	 * Retorna el valor almacenado en players
	 * 
	 * @return el valor
	 */
	public int getPlayers() 
	{
		return players;
	}
	
	/**
	 * Retorna el valor almacenado en autor
	 * 
	 * @return el valor
	 */
	public String getResponsable()
	{
		return this.author;
	}
	

	public void print(PrintStream out)
	{
		if (getOwn())
		{
			out.println("Título: " + getTitle());
			out.println("Número de jugadores: " + getPlayers());
			out.println("Plataforma: " + getPlatform());
			out.println(getOwn());
			out.print("Comentario: " + getComment());
		} else {
			out.println("Título: " + getTitle());
			out.println("Número de jugadores: " + getPlayers());
			out.println("Plataforma: " + getPlatform());
			out.println("You don't own it");
			out.print("Comentario: " + getComment());
		}
		out.println();
		
	}
	
	
	/**
	 * Devuelve en un toString los atributos de la clase
	 * 
	 * @return los atributos de la clase
	 */
	public String toString()
	{
		String data = "";
		data = data + ("Título: " + getTitle() + "\n");
		data = data + ("Número de jugadores: " + getPlayers() + "\n");
		data = data + ("Plataforma: " + getPlatform() + "\n");
		super.toString();
		return data;
	}

	
	@Override
	public boolean isLike(Item itemToSearch)
	{
		if(! (itemToSearch instanceof VideoGame) )
		{
			return false;
		}
		VideoGame gameToSearch = (VideoGame) itemToSearch;
		if(gameToSearch.getTitle().equals(this.getTitle()) &&
				gameToSearch.getPlatform().equals(this.getPlatform()))
		{
			return true;
		} else {
			return false;
		}
	}
	
	
	@Override
	public boolean equals(Item itemToSearch)
	{
		if(! (itemToSearch instanceof VideoGame) )
		{
			return false;
		}
		VideoGame gameToSearch = (VideoGame) itemToSearch;
		if(gameToSearch.getTitle().equals(this.getTitle()) &&
				gameToSearch.getPlatform().equals(this.getPlatform()))
		{
			return true;
		} else {
			return false;
		}
	}
}
