package uo.mp.s4.dome.model;

public enum Platform 
{
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */
	
	// Tipo enumerado que representa las plataformas de juego
	XBOX, PLAYSTATION, NINTENDO
}
