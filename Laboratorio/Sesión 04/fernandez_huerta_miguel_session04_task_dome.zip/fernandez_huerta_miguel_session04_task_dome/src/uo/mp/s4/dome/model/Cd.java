package uo.mp.s4.dome.model;

import java.io.PrintStream;
import uo.mp.util.ArgumentsCheck;

public class Cd extends Item  {
	
	/**
	 * @author Miguel
	 * @version 18-02-2022
	 */

	private static final double TAX = 2; // Impuesto a�adido al precio 
	
	private String artist;
	private int numberOfTracks;
	
	
	/**
	 * Constructor con par�metros de la clase Cd
	 * 
	 * @param el t�tulo del cd
	 * @param el artista del cd
	 * @param el n�mero de canciones del cd
	 * @param el tiempo de reproducci�n
	 * @param el precio base del cd
	 */
	public Cd(String theTitle, String theArtist, int tracks, int time,
			double basePrice)
	{
		super(theTitle,basePrice + TAX);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
		setPlayingTime(time);
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setArtist(String artist)
	{
		ArgumentsCheck.isTrue(artist != null);
		this.artist = artist;
	}
	
	
	/**
	 * Modifica el valor almacenado en el atributo
	 * 
	 * @param el nuevo valor para el atributo
	 */
	private void setNumberOfTracks(int numberOfTracks)
	{
		ArgumentsCheck.isTrue(numberOfTracks > 0);
		this.numberOfTracks = numberOfTracks;
	}

	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public String getArtist()
	{
		return this.artist;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public int getNumberOfTracks()
	{
		return this.numberOfTracks;
	}
	
	
	/**
	 * Retorna el valor almacenado en el atributo
	 * 
	 * @return el valor almacenado en el atributo
	 */
	public String getResponsable()
	{
		return this.artist;
	}
	
	
	
	public void print(PrintStream out) 
	{
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		if (getOwn()) {
			out.println("You own it");
		} else {
			out.println("You do not own it");
		}
		out.println("Comment: " + getComment());
		out.println();
	}
	
	
	
	public void print2(PrintStream out)
	{
		super.print2(out); // es un up-cast; se puede poner esta instrucci�n en la primera l�nea o en la �ltima
		out.println("CD: " + getTitle() + " (" + getPlayingTime() + " mins)");
		out.println("Artist: " + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		out.println();
	}
	
	
	/**
	 * Devuelve en un toString los atributos de la clase
	 * 
	 * @return los atributos de la clase
	 */
	public String toString()
	{
		String data = "";
		data = data + ("CD: " + getTitle() + " (" + getPlayingTime() + " mins)" 
				+ "\n");
		data = data + ("Artist: " + getArtist()) + "\n";
		data = data + "Tracks: " + getNumberOfTracks() + "\n";
		super.toString();
		return data;
	}
	
	
	@Override
	public boolean isLike(Item itemToSearch)
	{
		if(! (itemToSearch instanceof Cd) )
		{
			return false;
		}
		Cd cdToSearch = (Cd) itemToSearch;
		if(cdToSearch.getTitle().equals(this.getTitle()) &&
				cdToSearch.getArtist().equals(this.getArtist()))
		{
			return true;
		} else {
			return false;
		}
	}
	
	
	@Override
	public boolean equals(Item itemToSearch)
	{
		if(! (itemToSearch instanceof Cd) )
		{
			return false;
		}
		Cd cdToSearch = (Cd) itemToSearch;
		if(cdToSearch.getTitle().equals(this.getTitle()) &&
				cdToSearch.getArtist().equals(this.getArtist()))
		{
			return true;
		} else {
			return false;
		}
	}
}