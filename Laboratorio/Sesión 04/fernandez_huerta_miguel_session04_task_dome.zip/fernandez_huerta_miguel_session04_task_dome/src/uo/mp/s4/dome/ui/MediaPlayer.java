package uo.mp.s4.dome.ui;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Dvd;
import uo.mp.s4.dome.model.Item;
import uo.mp.s4.dome.model.Platform;
import uo.mp.s4.dome.model.VideoGame;
import uo.mp.s4.dome.service.MediaLibrary;

public class MediaPlayer {

	
	/**
	 * Muestra el resultado de la ejecuci�n de los m�todos 
	 * getNumberOfItemsOwned, getResponsable y list
	 * 
	 * 
	 * @author Miguel
	 * @version 18-02-2022
	 */
	public void run() 
	{
		MediaLibrary md = new MediaLibrary();
		
		Item dvd = new Dvd(
				"Thor", "Marvel", 10, 100);
		Item cd = new Cd(
				"Panes y flautas", "Mi amigo", 5, 2, 40);
		Item vg = new VideoGame(
				"God of War", "Santa M�nica Studios", 1, Platform.PLAYSTATION, 60);
		
		md.add(dvd);
		md.add(cd);
		md.add(vg);
		
		md.getNumberOfItemsOwned();
		md.getNumberOfItemsOwned();
		md.list(System.out);
		
		System.out.println();
		System.out.println("..... listado de items con LIST2");
		System.out.println();
		md.list2(System.out);
	}

}
