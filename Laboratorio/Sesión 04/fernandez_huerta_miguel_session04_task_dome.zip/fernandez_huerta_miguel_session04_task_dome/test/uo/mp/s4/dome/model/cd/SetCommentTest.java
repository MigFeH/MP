package uo.mp.s4.dome.model.cd;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Item;


public class SetCommentTest {
	private Item aCD;
	private String theTitle;
	private String theArtist;
	private int theTime;
	private int theTracks;
	private double theBasePrice;
	
	
	@Before
	public void setUp() {
		theTitle = "Come Together";
		theArtist = "Beatles";
		theTime = 70;
		theTracks = 4;
		theBasePrice = 10;
		aCD = new Cd(theTitle, theArtist, theTracks, theTime, theBasePrice);
	}

	/**
	 * GIVEN: 	cd con comentario vac�o
	 * WHEN: 	invoca setComment con cadena no vac�a como comentario
	 * THEN:	se cambia el comentario a la cadena
	 */
	
	@Test
	public void testSetComment() {
		aCD.setComment("Excellent");

		assertEquals("Excellent", aCD.getComment());
	}
	
	/**
	 * GIVEN: 	cd con comentario no vac�o
	 * WHEN: 	invoca setComment con null
	 * THEN:	permanece el comentario que hab�a
	 */
	@Test
	public void testSetInvalidComment() {
		aCD.setComment("Excellent");
		aCD.setComment(null);

		assertEquals("Excellent", aCD.getComment());
	}
}
