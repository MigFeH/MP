package uo.mp.s4.dome.model.dvd;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s4.dome.model.Dvd;

public class SetCommentTest {
	private Dvd aDVD;
	private String theTitle;
	private String theDirector;
	private int theTime;
	private double theBasePrice;
	
	
	@Before
	public void setUp() {
		theTitle = "La guerra de las Galaxias";
		theDirector = "George Lucas";
		theTime = 125;
		theBasePrice = 10;
		aDVD = new Dvd(theTitle, theDirector, theTime, theBasePrice);
	}
		

	/**
	 * GIVEN: 	dvd con comentario vac�o
	 * WHEN: 	invoca setComment cadena no vac�a como comentario
	 * THEN:	se cambia el comentario a la cadena
	 */
	@Test
	public void testRigthComment() {
		aDVD.setComment("Excellent");

		assertEquals("Excellent", aDVD.getComment());
	}
	
	/**
	 * GIVEN: 	dvd con comentario no vac�o
	 * WHEN: 	invoca setComment con null
	 * THEN:	permanece el comentario que hab�a
	 */
	@Test
	public void testInvalidComment() {
		aDVD.setComment("Excellent");
		aDVD.setComment(null);

		assertEquals("Excellent", aDVD.getComment());
	}

}