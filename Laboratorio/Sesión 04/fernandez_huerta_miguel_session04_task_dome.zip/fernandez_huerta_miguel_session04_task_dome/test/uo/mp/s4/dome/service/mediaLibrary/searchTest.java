package uo.mp.s4.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Item;
import uo.mp.s4.dome.service.MediaLibrary;

public class searchTest {
	
	/**
	 * GIVEN: Par�metro item null
	 * WHEN: Se llama al m�todo search
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testSearchWithNullItem()
	{
		MediaLibrary md = new MediaLibrary();
		md.search(null);
	}


	/**
	 * GIVEN: Par�metro item que existe en la librer�a
	 * WHEN: Se llama al m�todo search
	 * THEN: Devuelve el item
	 */
	@Test
	public void testSearch()
	{
		MediaLibrary md = new MediaLibrary();
		Item cd1 = new Cd("Beat it", "Michael Jackson",1,3,10.0);

		for(int i = 0; i < 4; i++)
		{
			md.add(cd1);
		}
		assertEquals(cd1,md.search(cd1));
	}


	/**
	 * GIVEN: Par�metro item que no existe en la librer�a
	 * WHEN: Se llama al m�todo search
	 * THEN: Devuelve null
	 */
	@Test
	public void testSearchWithNotFoundItem()
	{
		MediaLibrary md = new MediaLibrary();
		Item cd1 = new Cd("Beat it", "Michael Jackson",1,3,12.0);
		Item cd2 = new Cd("Sweet home la Chalana", "Los koordinaos",1,2,10.0);

		for(int i = 0; i < 4; i++)
		{
			md.add(cd1);
		}
		assertNull(md.search(cd2));
	}

}
