package uo.mp.s4.dome.model.videoGame;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ VideoGameTest.class })
public class AllTests {

}
