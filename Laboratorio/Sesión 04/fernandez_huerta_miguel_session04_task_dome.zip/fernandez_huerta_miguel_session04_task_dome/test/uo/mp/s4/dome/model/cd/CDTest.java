package uo.mp.s4.dome.model.cd;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s4.dome.model.Cd;


public class CDTest {
	 
	private String theTitle;
	private String theArtist;
	private int theTime;
	private int theTracks;
	private double theBasePrice;
	
	
	@Before
	public void setUp() {
		theTitle = "Come Together";
		theArtist = "Beatles";
		theTime = 70;
		theTracks = 4;
		theBasePrice = 10;
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con par�metros v�lidos
	 * THEN: se crea y los valores se asignan a los atributos
	 */
	@Test
	public void testValidParams() {
		Cd cd =  new Cd(theTitle, theArtist, theTracks, theTime, theBasePrice);

		assertEquals("Come Together", cd.getTitle());
		assertEquals("Beatles", cd.getArtist());
		assertEquals(70, cd.getPlayingTime());
		assertEquals(4, cd.getNumberOfTracks());
		assertEquals(12, cd.getBasePrice(),0.0);
		assertEquals(false, cd.getOwn());
		assertEquals("No comment", cd.getComment());
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con t�tulo null
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNullTitle() {
			new Cd(null, theArtist, theTracks, theTime, theBasePrice);
	}
		
	/**
	 * GIVEN:
	 * WHEN: Se crea con artista null
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNullArtist() {
			new Cd(theTitle, null, theTracks, theTime, theBasePrice);
	}

	/**
	 * GIVEN:
	 * WHEN: Se crea con tiempo de reproducci�n negativo
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNegativePlayingTime() {
			new Cd(theTitle, theArtist, theTracks, -1, theBasePrice);
	}

	/**	 
	 * GIVEN:
	 * WHEN: Se crea con n�mero de canciones negativo
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testNegativeNumberOfTracks() {
			new Cd(theTitle, theArtist, -1, theTime, theBasePrice);
	}

	
}
