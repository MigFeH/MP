package uo.mp.s4.dome.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({uo.mp.s4.dome.model.cd.AllTests.class,
	uo.mp.s4.dome.model.dvd.AllTests.class,
	uo.mp.s4.dome.service.mediaLibrary.AllTests.class,
	uo.mp.s4.dome.model.videoGame.AllTests.class})
public class AllTests {

}
