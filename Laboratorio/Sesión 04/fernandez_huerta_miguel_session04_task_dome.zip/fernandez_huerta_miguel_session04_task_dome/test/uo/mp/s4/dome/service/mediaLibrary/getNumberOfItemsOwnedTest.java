package uo.mp.s4.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Item;
import uo.mp.s4.dome.service.MediaLibrary;

public class getNumberOfItemsOwnedTest {
	
	/**
	 * GIVEN: 2 items con propietario
	 * WHEN: Se llama al m�todo add
	 * THEN: Retorna 2 (n�mero de items con propietario)
	 */
	@Test
	public void testGetNumberOfItemsOwnedWith2OwnedItems()
	{
		MediaLibrary md = new MediaLibrary();
		Item it = new Cd("T�tulo","Artista",9,2,8);
		it.setOwn(true);
		
		for(int i = 0; i < 2; i++)
		{
			md.add(it);
		}
		assertEquals(2,md.getNumberOfItemsOwned());
	}
	
	
	/**
	 * GIVEN: 0 items con propietario
	 * WHEN: Se llama al m�todo add
	 * THEN: Retorna 0 (n�mero de items con propietario)
	 */
	@Test
	public void testGetNumberOfItemsOwnedWith0OwnedItems()
	{
		MediaLibrary md = new MediaLibrary();
		Item it = new Cd("T�tulo","Artista",9,2,8);
		it.setOwn(false);
		
		for(int i = 0; i < 2; i++)
		{
			md.add(it);
		}
		assertEquals(0,md.getNumberOfItemsOwned());
	}

}
