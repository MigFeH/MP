package uo.mp.s4.dome.service.mediaLibrary;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ addTest.class,
	getItemsTest.class,
	getNumberOfItemsOwnedTest.class,
	searchItemTest.class,
	searchTest.class,
	getTotalValueTest.class,
	generateCodeTest.class})
public class AllTests {

}
