package uo.mp.s4.dome.service.mediaLibrary;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Dvd;
import uo.mp.s4.dome.model.Item;
import uo.mp.s4.dome.model.Platform;
import uo.mp.s4.dome.model.VideoGame;
import uo.mp.s4.dome.service.MediaLibrary;

public class searchItemTest {
	
	/**
	 * GIVEN: Par�metro item null
	 * WHEN: Se llama al m�todo searchItem
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testSearchItemWithNullItem()
	{
		MediaLibrary md = new MediaLibrary();
		md.searchItem(null);
	}


	/**
	 * GIVEN: Par�metro item de tipo din�mico Cd
	 * WHEN: Se llama al m�todo searchItem
	 * THEN: Devuelve la posici�n en la que se encuentra el item par�metro en la 
	 * lista de la clase MediaLibrary
	 */
	@Test
	public void testSearchItemWithCdItem()
	{
		MediaLibrary md = new MediaLibrary();
		Item cd1 = new Cd("Beat it", "Michael Jackson",1,3,7);
		Item cd2 = new Cd("Sweet home la Chalana", "Los koordinaos",1,2,6);

		for(int i = 0; i < 4; i++)
		{
			md.add(cd1);
		}
		md.add(cd2);
		assertEquals(4,md.searchItem(cd2));
	}


	/**
	 * GIVEN: Par�metro item de tipo din�mico Dvd
	 * WHEN: Se llama al m�todo searchItem
	 * THEN: Devuelve la posici�n en la que se encuentra el item par�metro en la 
	 * lista de la clase MediaLibrary
	 */
	@Test
	public void testSearchItemWithDvdItem()
	{
		MediaLibrary md = new MediaLibrary();
		Item dv1 = new Dvd("Pesadilla en la cocina especial frases de Chicote",
				"Chicote", 10,5);
		Item dv2 = new Dvd("Los monos, la especie infravalorada",
				"National Geographic", 2,4);

		for(int i = 0; i < 4; i++)
		{
			md.add(dv1);
		}
		md.add(dv2);
		assertEquals(4,md.searchItem(dv2));
	}
	
	
	/**
	 * GIVEN: Par�metro item de tipo din�mico VideoGame
	 * WHEN: Se llama al m�todo searchItem
	 * THEN: Devuelve la posici�n en la que se encuentra el item par�metro en la 
	 * lista de la clase MediaLibrary
	 */
	@Test
	public void testSearchItemWithVideoGameItem()
	{
		MediaLibrary md = new MediaLibrary();
		Item v1 = new VideoGame(
				"Gears of War", "Microsoft", 5000, Platform.XBOX,3);
		Item v2 = new VideoGame(
				"Call of Duty", "Activision", 2000, Platform.XBOX,2);
				
		for(int i = 0; i < 4; i++)
		{
			md.add(v1);
		}
		md.add(v2);
		assertEquals(4,md.searchItem(v2));
	}


	/**
	 * GIVEN: Par�metro item de tipo din�mico Cd
	 * WHEN: Se llama al m�todo searchItem con un par�metro item que no est� en
	 * la lista de la clase MediaLibrary
	 * THEN: Devuelve -1
	 */
	@Test
	public void testSearchItemWithNotFoundItem()
	{
		MediaLibrary md = new MediaLibrary();
		Item cd1 = new Cd("Beat it", "Michael Jackson",1,3,1);
		Item cd2 = new Cd("Sweet home la Chalana", "Los koordinaos",1,2,20);

		for(int i = 0; i < 4; i++)
		{
			md.add(cd1);
		}
		assertEquals(-1,md.searchItem(cd2));
	}

}
