package uo.mp.exam.parkandrepair;

import uo.mp.exam.parkandrepair.simulator.ParkAndRepairSimulator;

public class Main {
	
	private ParkAndRepairSimulator parkAndRepair;

	/**
	 * Main method that launches the application
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		new Main()
			.configure()
			.run();
	}

	/**
	 * Method that configures the application
	 * @return
	 */
	private Main configure() {
		parkAndRepair = new ParkAndRepairSimulator();
		return this;
	}

	/**
	 * Method that executes the application.
	 */
	private void run() {
		parkAndRepair.start();
	}
}
