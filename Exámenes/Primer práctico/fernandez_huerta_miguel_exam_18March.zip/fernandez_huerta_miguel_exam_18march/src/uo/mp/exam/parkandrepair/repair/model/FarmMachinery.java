package uo.mp.exam.parkandrepair.repair.model;


import uo.mp.util.ArgumentsCheck;

public class FarmMachinery implements Repairable{
	
	private String id; // n�mero de identificaci�n
	private String owner; // nombre del propietario
	private RepairStatus repared; // indica si est� reparado o no o pendiente

	/**
	 * Constructor de la clase con par�metros
	 * 
	 * @param el identificador
	 * @param el nombre del propietario
	 */
	public FarmMachinery(String id, String owner)
	{
		setId(id);
		setOwner(owner);
		setRepared(RepairStatus.no);
	}
	
	public RepairStatus getRepared() {
		RepairStatus copy = this.repared;
		return copy;
	}

	public void setRepared(RepairStatus repared) {
		ArgumentsCheck.isTrue(repared != null, 
				"Esperaba estado de reparaci�n pero fue null");
		this.repared = repared;
	}
	
	public String getId() {
		String copy = this.id;
		return copy;
	}
	
	private void setId(String id) {
		ArgumentsCheck.isTrue(id != null, "Esperaba id pero fue null");
		this.id = id;
	}
	
	public String getOwner() {
		String copy = this.owner;
		return copy;
	}
	
	private void setOwner(String owner) {
		ArgumentsCheck.isTrue(owner != null, 
				"Esperaba propietario pero fue null");
		this.owner = owner;
	}
	
	@Override
	public String toString()
	{
		return "FarmMachinery [id = " + getId() + ", owner = " + getOwner() +
				"]" + "\n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result + ((repared == null) ? 0 : repared.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof FarmMachinery))
		{
			return false;
		}
		if (((FarmMachinery) obj).getId().equals(this.getId()))
		{
			return true;
		}
		return false;
	}
	
	
	/**
	 * Devuelve el descuento que recibe para una reparaci�n
	 * 
	 * Siempre recibir� un descuento del 10%
	 * 
	 * @return el descuento
	 */
	public double discount()
	{
		return 0.10;
	}
	
	
}
