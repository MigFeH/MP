package uo.mp.exam.parkandrepair.parking.model;

import uo.mp.exam.parkandrepair.repair.model.RepairStatus;
import uo.mp.exam.parkandrepair.repair.model.Repairable;
import uo.mp.util.ArgumentsCheck;

public class Car extends Vehicle implements Repairable{
	
	private Size size; // tama�o del coche
	private RepairStatus repared; // indica si est� reparado o no o pendiente
	
	/**
	 * Constructor de la clase con par�metro size
	 * 
	 * @param el tama�o del coche
	 */
	public Car(Size size)
	{
		super();
		setSize(size);
		setRepared(RepairStatus.no);
	}

	
	public RepairStatus getRepared() {
		RepairStatus copy = this.repared;
		return copy;
	}

	public void setRepared(RepairStatus repared) {
		ArgumentsCheck.isTrue(repared != null, 
				"Esperaba estado de reparaci�n pero fue null");
		this.repared = repared;
	}



	public Size getSize() {
		Size copy = this.size;
		return copy;
	}

	private void setSize(Size size) {
		ArgumentsCheck.isTrue(size != null, "Esperaba tama�o pero fue null");
		this.size = size;
	}
	
	/**
	 * Calcula la tarifa de aparcamiento a partir del precio base de 
	 * aparcamiento y en funci�n del tama�o del coche
	 * 
	 * Si es peque�o se le a�ade 0.5� al precio base
	 * Si es mediano se le a�ade 0.75� al precio base
	 * Si es grande se le a�ade 1� al precio base
	 * 
	 * @param el precio base
	 * @return el precio final aplicado con la variaci�n de precio seg�n tama�o
	 */
	public double getParkingFee(double basePrice)
	{
		ArgumentsCheck.isTrue(basePrice > 0, "Precio base no v�lido");
		
		if (this.getSize() == Size.small) // coche peque�o...
		{
			return basePrice + 0.5;
		}
		if (this.getSize() == Size.medium) // coche mediano...
		{
			return basePrice + 0.75;
		}
		if (this.getSize() == Size.large) // coche grande...
		{
			return basePrice + 1.0;
		}
		return 0.0;
	}
	
	
	@Override
	public String toString()
	{
		return "Car [plate = " + getPlate() + ", size = " + getSize() + "]" + 
				"\n";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((repared == null) ? 0 : repared.hashCode());
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Car))
		{
			return false;
		}
		if (((Vehicle) obj).getPlate().equals(this.getPlate()))
		{
			return true;
		}
		return false;
	}
	
	@Override
	public boolean isParked()
	{
		return super.isParked();
	}
	
	
	/**
	 * Devuelve el descuento que recibe para una reparaci�n
	 * 
	 * Si el coche est� aparcado en el parking tiene un descuento del 15%
	 * Si el coche no est� aparcado en el parking tiene un descuento del 5%
	 * 
	 * @return el descuento
	 */
	public double discount()
	{
		if (isParked()) // si est� aparcado en el parking...
		{
			return 0.15;
		}
		return 0.05;
	}
	
}
