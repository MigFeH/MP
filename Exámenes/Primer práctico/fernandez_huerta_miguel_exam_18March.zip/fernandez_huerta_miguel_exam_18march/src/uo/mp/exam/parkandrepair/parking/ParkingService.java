package uo.mp.exam.parkandrepair.parking;

import java.util.ArrayList;
import java.util.List;

import uo.mp.exam.parkandrepair.parking.model.Vehicle;
import uo.mp.util.ArgumentsCheck;

public class ParkingService {
	
	private List<Vehicle> vehicles = new ArrayList<>(); // lista de veh�culos

	/**
	 * A�ade un coche o cami�n al parking
	 * 
	 * @param el coche o cami�n a a�adir
	 */
	public void park(Vehicle theVehicle)
	{
		ArgumentsCheck.isTrue(theVehicle != null, 
				"Esperaba veh�culo pero fue null");
		theVehicle.setParked(true); // veh�culo aparcado
		this.vehicles.add(theVehicle);
	}
	
	/**
	 * Devuelve la recaudaci�n total de todos los veh�culos aparcados, teniendo
	 * en cuenta el precio base recibido
	 */
	public double getIncome(double basePrice)
	{
		ArgumentsCheck.isTrue(basePrice > 0.0, "Precio base no v�lido");
		
		double aux = 0.0;
		
		for (Vehicle theVehicle: vehicles)
		{
			aux = aux + theVehicle.getParkingFee(basePrice);
		}
		
		return aux;
	}
	
	
	/**
	 * Retorna el veh�culo aparcado en una posici�n del parking
	 * 
	 * @param la posici�n en el parking
	 * @return el veh�culo
	 */
	public Vehicle getVehicle(int index)
	{
		ArgumentsCheck.isTrue(index >= 0, "Posici�n no v�lida");
		return this.vehicles.get(index);
	}
	

}
