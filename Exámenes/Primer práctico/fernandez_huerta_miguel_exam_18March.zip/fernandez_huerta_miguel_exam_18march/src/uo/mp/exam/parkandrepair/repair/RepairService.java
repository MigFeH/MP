package uo.mp.exam.parkandrepair.repair;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import uo.mp.exam.parkandrepair.repair.model.RepairStatus;
import uo.mp.exam.parkandrepair.repair.model.Repairable;
import uo.mp.util.ArgumentsCheck;

public class RepairService {
	
	private static final double MIN_REPAIR_COST = 100;
	private static final double MAX_REPAIR_COST = 3000;
	
	private List<Repairable> repairables = new ArrayList<>(); // lista de elementos reparables
	
	/**
	 * A�ade un objeto a la lista de objetos a ser reparados. Esto implica que 
	 * el objeto a reparar deber�, de alguna forma, cambiar su estado a 
	 * pendiente de reparaci�n
	 * 
	 * @param el objeto a ser a�adido a la lista de objetos a reparar
	 */
	public void register(Repairable rp)
	{
		ArgumentsCheck.isTrue(rp != null, 
				"Esperaba objeto a reparable pero fue  null");
		if (rp.getRepared() == RepairStatus.no) // si no est� reparado...
		{
			rp.setRepared(RepairStatus.pendient);
			this.repairables.add(rp);
		}
	}
	
	
	/**
	 * Devuelve la lista con los siguientes datos de todos los objetos que est�n
	 * pendientes de reparaci�n
	 * 
	 * Para los coches: matr�cula y tama�o
	 * Para la m�quina agr�cola: identificador y nombre del propietario
	 * 
	 * @return lista con los datos antes mencionados
	 */
	public List<String> getForRepair()
	{
		List<String> aux = new ArrayList<>();
		
		for (Repairable rp: repairables)
		{
			aux.add(rp.toString());
		}
		
		return aux;
	}
	
	
	
	/**
	 * Busca un objeto igual al recibido como par�metro, si es posible lo repara
	 * y devuelve el coste de la reparaci�n.
	 * 
	 * La reparaci�n implica cambiar el estado interno del objeto para indicar
	 * que ya est� reparado y adem�s devolver el coste de la reparaci�n.
	 * 
	 * @param el objeto reparable a buscar
	 * @return el coste de la reparaci�n si se ha podido reparar o -1 en caso
	 * contrario
	 */
	public double repair(Repairable rp)
	{
		ArgumentsCheck.isTrue(rp != null, 
				"Esperaba objeto reparable a buscar pero fue null");
		
		for (Repairable theRepairable: repairables)
		{
			if (theRepairable.equals(rp)) // si son iguales...
			{
				return repairPrice() - discount(rp);
			}
		}
		return -1;
	}
	
	
	
	/**
	 * Genera el coste de una reparaci�n de forma aleatoria con un n�mero 
	 * comprendido entre 100 y 3000
	 */
	private double repairPrice()
	{
		Random rd = new Random();
		double repairPrice = MIN_REPAIR_COST + 
				(MAX_REPAIR_COST - MIN_REPAIR_COST) * rd.nextDouble();
		return repairPrice;
	}
	
	
	/**
	 * Retorna el descuento correspondiente a un objeto reparable
	 * 
	 * @return el descuento
	 */
	private double discount(Repairable rp)
	{
		return rp.discount();
	}
	
	
}
