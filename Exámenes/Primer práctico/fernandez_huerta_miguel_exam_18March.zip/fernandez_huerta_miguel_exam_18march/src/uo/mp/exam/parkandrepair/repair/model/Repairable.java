package uo.mp.exam.parkandrepair.repair.model;

public interface Repairable {
	
	RepairStatus getRepared();
	void setRepared(RepairStatus repared);
	double discount();

}
