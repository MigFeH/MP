package uo.mp.exam.parkandrepair.parking.model;

import uo.mp.util.ArgumentsCheck;

public class Truck extends Vehicle{
	
	private double weight; // peso del cami�n
	
	/**
	 * Constructor de la clase con par�metro peso
	 * 
	 * @param el peso
	 */
	public Truck(double weight)
	{
		super();
		setWeight(weight);
	}
	
	
	public double getWeight() {
		double copy = this.weight;
		return copy;
	}

	private void setWeight(double weight) {
		ArgumentsCheck.isTrue(weight > 0, "Peso de cami�n no valido");
		this.weight = weight;
	}
	
	/**
	 * Calcula la tarifa de aparcamiento a partir del precio base de 
	 * aparcamiento y en funci�n del peso del cami�n
	 * 
	 * Se le a�ade al precio base el 10% del peso del cami�n
	 * 
	 * @param el precio base
	 * @return el precio final aplicado con la variaci�n de precio seg�n peso
	 */
	public double getParkingFee(double basePrice)
	{
		ArgumentsCheck.isTrue(basePrice > 0, "Precio base no v�lido");
		
		return basePrice + this.tenPercentOfWeight();
	}
	
	
	
	
	/**
	 * Devuelve el 10% del peso del cami�n
	 * 
	 * @return el peso
	 */
	private double tenPercentOfWeight()
	{
		return this.getWeight() * 0.1;
	}
}
