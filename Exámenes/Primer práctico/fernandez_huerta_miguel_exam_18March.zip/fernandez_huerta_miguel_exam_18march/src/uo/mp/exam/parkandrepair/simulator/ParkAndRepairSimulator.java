package uo.mp.exam.parkandrepair.simulator;

import uo.mp.exam.parkandrepair.parking.ParkingService;
import uo.mp.exam.parkandrepair.parking.model.Car;
import uo.mp.exam.parkandrepair.parking.model.Size;
import uo.mp.exam.parkandrepair.parking.model.Truck;
import uo.mp.exam.parkandrepair.parking.model.Vehicle;
import uo.mp.exam.parkandrepair.repair.RepairService;
import uo.mp.exam.parkandrepair.repair.model.FarmMachinery;
import uo.mp.exam.parkandrepair.repair.model.Repairable;

public class ParkAndRepairSimulator {

	public void start() {
		
		/*
		 * 1. Create an instance of parking service, then
		 * 1.1 park a small car, a medium one and a large one
		 * 1.2 print total income considering base price 2 euros
		 * 1.3 park a truck 18 tons and other 26 tons
		 * 1.4 print total income including both cars and trucks with base price 2 euros 
		 */
		ParkingService ps = new ParkingService();
		
		Vehicle smallCar1 = new Car(Size.small);
		Vehicle mediumCar1 = new Car(Size.medium);
		Vehicle largeCar1 = new Car(Size.large);
		
		ps.park(smallCar1);
		ps.park(mediumCar1);
		ps.park(largeCar1);
		
		System.out.println("Total income with 3 cars: " + ps.getIncome(2.0));
		
		Vehicle truck1 = new Truck(26.0);
		
		ps.park(truck1);
		
		System.out.println("Total income with all vehicles: " + ps.getIncome(2.0));
		
		
		/*
		 * 2. Create an instance of repair service, then
		 * 2.1 register a parked small car for repairing
		 * 2.2 register a farm machine for repairing
		 * 2.3 register a non-parked large car for repairing
		 * 2.4 print all objects pending repair
		 * 2.5 repair the farm machine pending repair and print the returned value
		 * 2.6 try to repair the same farm machine again and print the returned value
		 * 2.7 print again each and every object pending repairing  
		 */
		RepairService rs = new RepairService();
		
		Repairable smallCar2 = new Car(Size.small);
		
		rs.register(smallCar2);
		
		Repairable farmMachine = new FarmMachinery("001","Angel Garc�a");
		
		rs.register(farmMachine);
		
		Car largeCar2 = new Car(Size.large);
		
		largeCar2.setParked(false);
		
		rs.register(largeCar2);
		
		System.out.println("Objects pending repair: " + rs.getForRepair());
		
		System.out.println("Farm machine repair cost: " + rs.repair(farmMachine));
		
		System.out.println("Second farm machine repair cost: " + rs.repair(farmMachine));
		
		System.out.println("Objects pending repair: " + rs.getForRepair());
	}
}
