package uo.mp.exam.parkandrepair.repair.model;

public enum RepairStatus {
	yes, no, pendient

}
