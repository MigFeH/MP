package uo.mp.exam.parkandrepair.parking.model;

public enum Size {
	small, medium, large 
}
