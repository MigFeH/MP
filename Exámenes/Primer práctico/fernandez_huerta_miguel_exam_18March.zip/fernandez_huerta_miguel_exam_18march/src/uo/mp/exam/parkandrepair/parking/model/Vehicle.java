package uo.mp.exam.parkandrepair.parking.model;

import uo.mp.util.ArgumentsCheck;

public abstract class Vehicle {
	
	private String plate; // matr�cula del veh�culo
	private boolean parked; // si el veh�culo est� aparcado o no
	
	/**
	 * Construtor sin par�metros de la clase
	 */
	public Vehicle()
	{
		setParked(false);
	}
	
	
	public boolean isParked() {
		boolean copy = this.parked;
		return copy;
	}

	public void setParked(boolean parked) {
		this.parked = parked;
	}
	
	public String getPlate() {
		String copy = this.plate;
		return copy;
	}

	private void setPlate(String plate) {
		ArgumentsCheck.isTrue(plate != null,
				"Esperaba matr�cula pero fue null");
		this.plate = plate;
	}
	
	public abstract double getParkingFee(double basePrice);
	
	
	
}
