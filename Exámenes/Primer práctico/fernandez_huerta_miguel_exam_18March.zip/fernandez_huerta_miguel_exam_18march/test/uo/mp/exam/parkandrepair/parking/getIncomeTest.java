package uo.mp.exam.parkandrepair.parking;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.exam.parkandrepair.parking.model.Car;
import uo.mp.exam.parkandrepair.parking.model.Size;

public class getIncomeTest {

	/**
	 * GIVEN: Precio base no v�lido
	 * WHEN: Se llama al m�todo getIncome
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testGetIncomeWithInvalidParam()
	{
		ParkingService ps = new ParkingService();
		ps.getIncome(-20.0);
	}
	
	/**
	 * GIVEN: Precio base v�lido
	 * WHEN: Se llama al m�todo getIncome
	 * THEN: Devuelve la recaudaci�n total de todos los veh�culos aparcados, 
	 * teniendo en cuenta el precio base recibido
	 */
	@Test
	public void testGetIncomeWithValidParam()
	{
		ParkingService ps = new ParkingService();
		
		for (int i = 0; i < 10; i++)
		{
			ps.park(new Car(Size.small));
		}
		
		assertEquals(55.0, ps.getIncome(5.0),0.0);
	}
	
}
