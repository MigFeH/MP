package uo.mp.exam.parkandrepair.parking;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.exam.parkandrepair.parking.model.Car;
import uo.mp.exam.parkandrepair.parking.model.Size;
import uo.mp.exam.parkandrepair.parking.model.Truck;

public class parkTest {

	/**
	 * GIVEN: Veh�culo null
	 * WHEN: Se llama al m�todo park
	 * THEN: Salta excepci�n
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testParkWithNullParam()
	{
		ParkingService ps = new ParkingService();
		ps.park(null);
	}
	
	
	/**
	 * GIVEN: Veh�culo coche
	 * WHEN: Se llama al m�todo park
	 * THEN: Se a�ade a la lista de veh�culos aparcados el coche
	 */
	@Test
	public void testParkWithCarParam()
	{
		ParkingService ps = new ParkingService();
		ps.park(new Car(Size.small));
		
		assertNotNull(ps.getVehicle(0));
	}
	
	
	/**
	 * GIVEN: Veh�culo cami�n
	 * WHEN: Se llama al m�todo park
	 * THEN: Se a�ade a la lista de veh�culos aparcados el cami�n
	 */
	@Test
	public void testParkWithTruckParam()
	{
		ParkingService ps = new ParkingService();
		ps.park(new Truck(12.0));
		
		assertNotNull(ps.getVehicle(0));
	}
	
}
