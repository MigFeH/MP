package uo.mp.util.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import uo.mp.util.ArgumentsCheck;

public class ZipFileUtil {
	
	public List<String> zipFileReadLines(String inZipName) throws FileNotFoundException
	{
		ArgumentsCheck.isTrue(inZipName != null && !inZipName.isBlank());
		
		List<String> res = new ArrayList<>();
		try
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(inZipName))));
			try
			{
				String line;
				while ((line = in.readLine()) != null)
				{
					res.add(line);
				}
			} finally 
			{
				in.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException("Fichero no encontrado");
		}
		return res;
	}
	
	public void zipFileWriteLines(String outZipName, List<String> lines) {
		ArgumentsCheck.isTrue(outZipName != null && !outZipName.isBlank());
		
		try 
		{
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(outZipName))));
			try 
			{
				for (String line : lines)
				{
					out.write(line);
					out.newLine();
				}
			} finally 
			{
				out.close();
			}
		} catch (IOException e)
		{
			throw new RuntimeException();
		}
	}
	
	public void saveToFile(String outFileName, List<String> lines) {
		
		ArgumentsCheck.isTrue(outFileName != null && !outFileName.isBlank(), "Nombre de fichero destino no v�lido");
		ArgumentsCheck.isTrue(lines != null, "Lista de lineas String no v�lida");
		
		try
		{
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(outFileName))));
			
			try
			{
				for(String theLine : lines)
				{
					out.write(theLine);
					out.newLine();
				}
			}finally
			{
				out.close();
			}
		}catch(IOException e)
		{
			throw new RuntimeException("Error al guardar en el fichero salida");
		}		
	}
}
