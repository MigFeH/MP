package uo.mp2122.payroll.workshop;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;


public class LoadMonthlyDataFileTest {

	private String nullName; // caso 1
	private String emptyName; // caso 2
	
	private String nonExistingName; // caso 3
	
	private String fileName; // caso 4
	
	/**
	 * 1- Que el nombre del fichero sea null (salta IllegalArgumentException)
	 * 2- Que el nombre del fichero sea una cadena vac�a (salta IllegalArgumentException)
	 * 
	 * 3- Que el nombre del fichero no corresponda con alguno con el que exista (Salta RuntimeException)
	 * 
	 * 4- Que el nombre del fichero sea correcto (Se crean objetos MonthlyWorkRecord y son a�adidos a una lista)
	 */
	
	@Before
	public void SetUp()
	{
		this.nullName = null;
		this.emptyName = "";
		
		this.nonExistingName = "yughwdyhichwo.txt";
		
		this.fileName = "monthlyData.txt";
	}
	
	
	/**
	 * GIVEN: Nombre de fichero null
	 * WHEN: Se llama al m�todo loadMonthlyDataFile()
	 * THEN: Salta IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testLoadMonthlyDataFileWithNullFileName()
	{
		Workshop ws = new Workshop();
		
		ws.loadMonthlyDataFile(nullName);
	}

	/**
	 * GIVEN: Nombre de fichero vac�o
	 * WHEN: Se llama al m�todo loadMonthlyDataFile()
	 * THEN: Salta IllegalArgumentException
	 */
	@Test
	(expected = IllegalArgumentException.class)
	public void testLoadMonthlyDataFileWithEmptyFileName()
	{
		Workshop ws = new Workshop();
		
		ws.loadMonthlyDataFile(emptyName);
	}
	
	/**
	 * GIVEN: Nombre del fichero no correspondiente con alguno con que exista
	 * WHEN: Se llama al m�todo loadMonthlyDataFile()
	 * THEN: Salta RuntimeException
	 */
	@Test
	(expected = RuntimeException.class)
	public void testLoadMonthlyDataFileWithNonExistingFileName()
	{
		Workshop ws = new Workshop();
		
		ws.loadMonthlyDataFile(nonExistingName);
	}
	
	/**
	 * GIVEN: Nombre del fichero sea correcto
	 * WHEN: Se llama al m�todo loadMonthlyDataFile()
	 * THEN: Se crean objetos MonthlyWorkRecord y son a�adidos a una lista
	 */
	@Test
	public void testLoadMonthlyDataFileWithValidFileName()
	{
		Workshop ws = new Workshop();
		
		ws.loadMonthlyDataFile(fileName);
		
		List<String> expected = new ArrayList<>();
		
		expected.add("MonthlyWorkRecord [dni=11111111A, month=5, year=2022, extra=70.0]");
		expected.add("MonthlyWorkRecord [dni=22222222J, month=5, year=2022, extra=10.0]");
		expected.add("MonthlyWorkRecord [dni=33333333E, month=5, year=2022, extra=50.0]");
		expected.add("MonthlyWorkRecord [dni=44444444H, month=5, year=2022, extra=60.0]");
		expected.add("MonthlyWorkRecord [dni=55555555C, month=5, year=2022, extra=50.0]");
		expected.add("MonthlyWorkRecord [dni=66666666B, month=5, year=2022, extra=200.0]");
		expected.add("MonthlyWorkRecord [dni=99999999D, month=5, year=2022, extra=0.0]");
		
		assertEquals(ws.getMonthlyRecords().toString(), expected.toString());
	}
	
}
