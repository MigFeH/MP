package uo.mp2122.payroll.comparator;

import java.util.Comparator;

import uo.mp2122.payroll.payroll.Payroll;

public class OrderPayrollsByNetSalaryAndDni implements Comparator<Payroll> {

	@Override
	public int compare(Payroll o1, Payroll o2) {
		int diff = (int) (o2.getNetSalary() - o1.getNetSalary()); // orden descendente
		if(diff == 0)
		{
			return o2.getDni().compareTo(o1.getDni()); // orden descendente
		}
		return diff;
	}

	
	
}
