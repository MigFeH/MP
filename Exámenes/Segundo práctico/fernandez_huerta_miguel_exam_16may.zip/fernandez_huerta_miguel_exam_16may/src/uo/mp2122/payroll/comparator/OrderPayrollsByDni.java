package uo.mp2122.payroll.comparator;

import java.util.Comparator;

import uo.mp2122.payroll.payroll.Payroll;

public class OrderPayrollsByDni implements Comparator<Payroll> {

	@Override
	public int compare(Payroll o1, Payroll o2) {
		int diff = o1.getDni().compareTo(o2.getDni()); // orden ascendente
		return diff;
	}



}
