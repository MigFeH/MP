package uo.mp2122.payroll.model;

import uo.mp.util.ArgumentsCheck;

public class Employee {
	
	private String dni; // dni del trabajador
	private double baseSalary;
	
	public Employee(String dni, double salary)
	{
		ArgumentsCheck.isTrue(dni != null && !dni.isBlank(), "Identificador del trabajador no v�lido");
		ArgumentsCheck.isTrue(salary >= 0.0, "Salario base del trabajador no v�lido");
		this.dni = dni;
		this.baseSalary = salary;
	}


	public String getDni() {
		String aux = this.dni;
		return aux;
	}
	
	public double getBaseSalary() {
		double aux = this.baseSalary;
		return aux;
	}
	

}
