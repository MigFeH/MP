package uo.mp2122.payroll.monthlyWorkRecord;

import uo.mp.util.ArgumentsCheck;

public class MonthlyWorkRecord {
	
	private String dni;
	private int month;
	private int year;
	private double extra;
	
	public MonthlyWorkRecord(String dni, int month, int year, double extra)
	{
		ArgumentsCheck.isTrue(dni != null && !dni.isBlank(), "dni no v�lido");
		ArgumentsCheck.isTrue(month > 0 && month <= 12, "Mes no v�lido");
		ArgumentsCheck.isTrue(year >= 1000 && month <= 9999, "A�o no v�lido");
		ArgumentsCheck.isTrue(extra >= 0.0, "Extra no v�lido");
		
		this.dni = dni;
		this.month = month;
		this.year = year;
		this.extra = extra;
	}

	public String getDni() {
		String aux = this.dni;
		return aux;
	}

	public int getMonth() {
		int aux = this.month;
		return aux;
	}

	public int getYear() {
		int aux = this.year;
		return aux;
	}

	public double getExtra() {
		double aux = this.extra;
		return aux;
	}

	public String monthToString() {
		String aux = "";
		return aux + getMonth();
	}
	
	public String yearToString() {
		String aux = "";
		return aux + getYear();
	}

	@Override
	public String toString() {
		return "MonthlyWorkRecord [dni=" + dni + ", month=" + month + ", year=" + year + ", extra=" + extra + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		long temp;
		temp = Double.doubleToLongBits(extra);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + month;
		result = prime * result + year;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MonthlyWorkRecord other = (MonthlyWorkRecord) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		if (Double.doubleToLongBits(extra) != Double.doubleToLongBits(other.extra))
			return false;
		if (month != other.month)
			return false;
		if (year != other.year)
			return false;
		return true;
	}
	

	
}
