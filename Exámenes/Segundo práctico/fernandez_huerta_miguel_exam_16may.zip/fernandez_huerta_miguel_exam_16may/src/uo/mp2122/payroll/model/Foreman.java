package uo.mp2122.payroll.model;

import uo.mp.util.ArgumentsCheck;

public class Foreman extends Employee{
	
	private static final double BASE_SALARY = 2000.0; // salario base del capataz
	
	private int experience; // a�os de experiencia del capataz
	
	public Foreman(String dni, int experience)
	{
		super(dni, BASE_SALARY);
		ArgumentsCheck.isTrue(experience >= 0, "A�os de experiencia del capataz no v�lidos");
		this.experience = experience;
	}

	public int getExperience() {
		int aux = this.experience;
		return aux;
	}

	
	
}
