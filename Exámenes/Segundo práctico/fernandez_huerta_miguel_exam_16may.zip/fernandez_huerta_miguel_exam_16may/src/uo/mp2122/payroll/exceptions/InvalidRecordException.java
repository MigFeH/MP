package uo.mp2122.payroll.exceptions;

import uo.mp.util.ArgumentsCheck;

public class InvalidRecordException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	private int lineNumber;
	
	public InvalidRecordException(String msg, int lineNumber)
	{
		super(msg);
		ArgumentsCheck.isTrue(lineNumber > 0);
		this.lineNumber = lineNumber;
	}
	
	@Override
	public String getMessage()
	{
		return "REGISTRO NO V�LIDO en l�nea " + lineNumber + " debido a " + super.getMessage();
	}

}
