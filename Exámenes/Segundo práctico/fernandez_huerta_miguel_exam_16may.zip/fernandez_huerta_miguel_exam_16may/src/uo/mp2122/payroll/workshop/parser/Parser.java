package uo.mp2122.payroll.workshop.parser;

import java.util.ArrayList;
import java.util.List;

import uo.mp.util.ArgumentsCheck;
import uo.mp.util.ui.Logger;
import uo.mp2122.payroll.exceptions.InvalidRecordException;
import uo.mp2122.payroll.monthlyWorkRecord.MonthlyWorkRecord;

public class Parser {
	
	private int lineNumber = 0;

	public List<MonthlyWorkRecord> parse(List<String> aux) {
		ArgumentsCheck.isTrue(aux != null, "Lista de l�neas de fichero no v�lidas");
		List<MonthlyWorkRecord> res = parseLine(aux);
		ArgumentsCheck.isTrue(res != null, "Lista de registros no v�lida");
		return res;
	}

	private List<MonthlyWorkRecord> parseLine(List<String> lines) {
		ArgumentsCheck.isTrue(lines != null, "Lista de l�neas de fichero no v�lidas");
		
		List<MonthlyWorkRecord> res = new ArrayList<>();
		
		String[] aux;
		
		for(String theLine : lines)
		{
			lineNumber++;
			try
			{			
				aux = theLine.split("-");
				checkParts(aux, 4);
				
				String dni = aux[0];
				int month = monthToInteger(aux[1]);
				int year = yearToInteger(aux[2]);
				double extra = toDouble(aux[3]);
				
				res.add(new MonthlyWorkRecord(dni, month, year, extra));
			} catch(InvalidRecordException e)
			{
				Logger.log(e.getMessage());
			}
		}
		return res;
	}

	private double toDouble(String string) throws InvalidRecordException {
		ArgumentsCheck.isTrue(string != null && !string.isBlank(), "Cadena a pasar a double no v�lida");
		try
		{
			double aux = Double.parseDouble(string);
			return aux;
		}catch(NumberFormatException e)
		{
			throw new InvalidRecordException("N�MERO NO V�LIDO", lineNumber);
		}
	}

	private int monthToInteger(String string) throws InvalidRecordException{
		ArgumentsCheck.isTrue(string != null && !string.isBlank(), "Cadena a pasar a entero no v�lida");
		int aux = Integer.parseInt(string);
		checkMonth(aux);
		return aux;
	}
	
	private int yearToInteger(String string) throws InvalidRecordException{
		ArgumentsCheck.isTrue(string != null && !string.isBlank(), "Cadena a pasar a entero no v�lida");
		if(!(string.length() == 4))
		{
			throw new InvalidRecordException("FECHA NO V�LIDA", lineNumber);
		}
		int aux = Integer.parseInt(string);
		return aux;
	}
	
	private void checkMonth(int aux) throws InvalidRecordException {
		if(aux < 1 || aux > 12)
		{
			throw new InvalidRecordException("FECHA NO V�LIDA", lineNumber);
		}
	}

	private void checkParts(String[] aux, int i) throws InvalidRecordException {
		ArgumentsCheck.isTrue(aux != null && i > 0, "Par�metros no v�lidos");
		if(aux.length != i)
		{
			throw new InvalidRecordException("N�MERO DE CAMPOS NO V�LIDO", lineNumber);
		}
		
	}

}
