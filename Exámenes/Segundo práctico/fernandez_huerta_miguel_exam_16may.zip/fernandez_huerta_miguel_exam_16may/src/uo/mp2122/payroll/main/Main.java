package uo.mp2122.payroll.main;

import uo.mp2122.payroll.simulator.Simulator;

public class Main {


	public static void main(String[] args) {
		new Main()
			.run();		
	}

	
	private void run() {
		new Simulator().run();
		
	}

}
