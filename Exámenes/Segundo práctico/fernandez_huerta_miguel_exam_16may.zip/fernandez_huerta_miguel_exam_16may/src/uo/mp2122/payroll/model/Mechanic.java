package uo.mp2122.payroll.model;

import uo.mp.util.ArgumentsCheck;

public class Mechanic extends Employee{
	
	private static final double BASE_SALARY = 1600.0; // salario base del mec�nico

	private double hourlyRate; // tarifa por hora extra del mec�nico
	
	public Mechanic(String dni, double hourlyRate) 
	{
		super(dni, BASE_SALARY);
		ArgumentsCheck.isTrue(hourlyRate >= 0.0, "Tarifa por hora del mec�nico no v�lida");
		this.hourlyRate = hourlyRate;
	}

	public double getHourlyRate() {
		double aux = this.hourlyRate;
		return aux;
	}
	
}
