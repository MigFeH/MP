package uo.mp2122.payroll.payroll;

import java.io.Serializable;

import uo.mp.util.ArgumentsCheck;

public class Payroll implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String dni;
	private transient String month;
	private transient String year;
	private double netSalary;
	
	
	public Payroll(String dni, String month, String year, double salary)
	{
		ArgumentsCheck.isTrue(dni != null && !dni.isBlank(), "dni no v�lido");
		ArgumentsCheck.isTrue(month != null && !month.isBlank(), "mes no v�lido");
		ArgumentsCheck.isTrue(year != null && !year.isBlank(), "a�o no v�lido");
		ArgumentsCheck.isTrue(salary > 0.0, "salario no v�lido");
		
		this.dni = dni;
		this.month = month;
		this.year = year;
		this.netSalary = salary;
	}


	public String getDni() {
		String aux = this.dni;
		return aux;
	}


	public String getMonth() {
		String aux = this.month;
		return aux;
	}


	public String getYear() {
		String aux = this.year;
		return aux;
	}


	public double getNetSalary() {
		double aux = this.netSalary;
		return aux;
	}


	@Override
	public String toString() {
		return "Payroll [dni=" + dni + ", month=" + month + ", year=" + year + ", netSalary=" + netSalary + "]";
	}
	
	
	public String serialize()
	{
		return getDni() + "->" + getNetSalary();
	}
	
}
