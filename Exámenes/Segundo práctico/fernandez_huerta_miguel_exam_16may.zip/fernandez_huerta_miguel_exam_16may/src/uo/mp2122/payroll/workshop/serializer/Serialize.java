package uo.mp2122.payroll.workshop.serializer;

import java.util.ArrayList;
import java.util.List;

import uo.mp.util.file.FileUtil;
import uo.mp2122.payroll.payroll.Payroll;

public class Serialize {

	
	
	public void serialize(List<Payroll> payrolls, String filename) {
		List<String> aux = new ArrayList<>();
		for(Payroll thePayroll : payrolls)
		{
			aux.add(thePayroll.serialize());
		}
		new FileUtil().saveToFile(filename, aux);
		
	}

}
