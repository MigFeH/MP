package uo.mp2122.payroll.comparator;

import java.util.Comparator;

import uo.mp2122.payroll.monthlyWorkRecord.MonthlyWorkRecord;

public class OrderMonthlyRecordsByDni implements Comparator<MonthlyWorkRecord> {

	@Override
	public int compare(MonthlyWorkRecord o1, MonthlyWorkRecord o2) {
		int diff = o1.getDni().compareTo(o2.getDni()); // orden ascendente
		return diff;
	}



}
