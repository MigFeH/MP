package uo.mp2122.payroll.model;


public class OfficeClerk extends Employee {
	
	private static final double BASE_SALARY = 1300.0; // salario base del oficinista

	private boolean online; // indicador de si el oficinista puede trabajar online
	
	public OfficeClerk(String dni, boolean online)
	{
		super(dni, BASE_SALARY);
		this.online = online;
	}

	public boolean isOnline() {
		boolean aux = this.online;
		return aux;
	}
	
	
}
