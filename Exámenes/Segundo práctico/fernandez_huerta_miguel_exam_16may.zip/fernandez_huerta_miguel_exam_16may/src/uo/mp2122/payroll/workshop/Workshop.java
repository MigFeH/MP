package uo.mp2122.payroll.workshop;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.util.ArgumentsCheck;
import uo.mp.util.file.FileUtil;
import uo.mp2122.payroll.comparator.OrderMonthlyRecordsByDni;
import uo.mp2122.payroll.comparator.OrderPayrollsByDni;
import uo.mp2122.payroll.comparator.OrderPayrollsByNetSalaryAndDni;
import uo.mp2122.payroll.exceptions.WorkshopException;
import uo.mp2122.payroll.model.Employee;
import uo.mp2122.payroll.model.Foreman;
import uo.mp2122.payroll.model.Mechanic;
import uo.mp2122.payroll.model.OfficeClerk;
import uo.mp2122.payroll.monthlyWorkRecord.MonthlyWorkRecord;
import uo.mp2122.payroll.payroll.Payroll;
import uo.mp2122.payroll.workshop.parser.Parser;
import uo.mp2122.payroll.workshop.serializer.Serialize;

public class Workshop {

	private List<Employee> employees = new ArrayList<>(); // lista de empleados
	
	private List<MonthlyWorkRecord> monthlyRecords; // lista de registros
	
	private List<Payroll> payrolls = new ArrayList<>(); // lista de n�minas
	
	/**
	 * Add next employees
	 * 
	 * Professional group: Foreman		DNI:22222222J  		experience: 10
	 * Professional group: Office clerk	DNI:66666666B		onlineWork: true
	 * Professional group: Office clerk	DNI:99999999D		onlineWork: false
	 * Professional group: Mechanic		DNI:11111111A		hourlyRate: 70.0
	 * Professional group: Mechanic		DNI:44444444H		hourlyRate: 60.0
	 * Professional group: Mechanic		DNI:55555555C		hourlyRate: 50.0
	 * Professional group: Mechanic		DNI:33333333E		hourlyRate: 50.0
	 * 
	 * 
	 */
	public void configure() {
		
		employees.add(new Foreman("22222222J", 10));
		
		employees.add(new OfficeClerk("66666666B", true));
		employees.add(new OfficeClerk("99999999D", false));
		
		employees.add(new Mechanic("11111111A", 70.0));
		employees.add(new Mechanic("44444444H", 60.0));
		employees.add(new Mechanic("55555555C", 50.0));
		employees.add(new Mechanic("33333333E", 50.0));
	}
	
	
	/**
	 * Reads the input file, parse the content, generates a list of
	 * MonthlyWorkRecord and validates this list 
	 * (no repeated records, no missing records, matching dni)
	 * @param filename input file name containing monthly information 
	 *
	 */
	public void loadMonthlyDataFile(String filename) {
		ArgumentsCheck.isTrue(filename != null && !filename.isBlank(), "Nombre de fichero a cargar no v�lido");
		
		List<String> aux;
		try 
		{
			aux = new FileUtil().readLines(filename);
			this.monthlyRecords = new Parser().parse(aux);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("El archivo " + filename + " no existe");
		}
	}


	/**
	 * Using the monthly work records, generate the payrolls for the employees.
	 * @throws WorkshopException 
	 * 
	 *  
	 */
	public void generatePayrolls() throws WorkshopException {
		checkData();
		
		for(int i = 0; i < monthlyRecords.size(); i++)
		{
			for(int j = 0; j < employees.size(); j++)
			{
				if(monthlyRecords.get(i).getDni().equals(employees.get(j).getDni())) // si coinciden los dni...
				{
					payrolls.add(new Payroll(
							employees.get(j).getDni(),
							monthlyRecords.get(i).monthToString(),
							monthlyRecords.get(i).yearToString(),
							calculateNetSalary(employees.get(j), monthlyRecords.get(i))));
				}
			}
		}
		
	}


	private void checkData() throws WorkshopException {
		if(employees.size() != monthlyRecords.size())
		{
			throw new WorkshopException("Datos de entrada incosistentes");
		}
		
		
		int cont = 0;
		
		for(int i = 0; i < monthlyRecords.size(); i++)
		{
			for(int j = 0; j < employees.size(); j++)
			{
				if(monthlyRecords.get(i).getDni().equals(employees.get(j).getDni())) // si coinciden los dni...
				{
					cont++;
				}
			}
		}
		
		if(cont != employees.size()) // si no hay un dni registrado en el bucle anterior...
		{
			throw new WorkshopException("Datos de entrada incosistentes");
		}
		
	}


	private double calculateNetSalary(Employee employee, MonthlyWorkRecord monthlyWorkRecord) {
		ArgumentsCheck.isTrue(employee != null, "Empleado no v�lido");
		ArgumentsCheck.isTrue(monthlyWorkRecord != null, "Registro no v�lido");
		if(employee instanceof Foreman)
		{
			return employee.getBaseSalary() + monthlyWorkRecord.getExtra() + 0.01 * employee.getBaseSalary() * ((Foreman) employee).getExperience();
		}
		if(employee instanceof Mechanic)
		{
			return employee.getBaseSalary() + monthlyWorkRecord.getExtra() * ((Mechanic) employee).getHourlyRate();
		}
		if(employee instanceof OfficeClerk)
		{
			return employee.getBaseSalary() + monthlyWorkRecord.getExtra();
		}
		return 0.0;
	}


	/**
	 * 
	 * @return payrolls ordered by dni
	 */
	public List<Payroll> getPayrolls() {
		Collections.sort(payrolls, new OrderPayrollsByDni());
		return new ArrayList<>(payrolls);
	}

	/**
	 * 
	 * @return the monthly records by ascending dni 
	 */
	public List<MonthlyWorkRecord> getMonthlyRecords() {
		Collections.sort(monthlyRecords, new OrderMonthlyRecordsByDni());
		return new ArrayList<>(monthlyRecords);
		
	}

	
	/**
	 * 
	 * @param filename
	 * Write the payrolls ordered by descending net salary. In case of tie 
	 * by dni
	 */
	public void savePayrolls(String filename) {
		ArgumentsCheck.isTrue(filename != null && !filename.isBlank(), "Nombre de fichero destino no v�lido");
		Collections.sort(payrolls, new OrderPayrollsByNetSalaryAndDni());
		new Serialize().serialize(payrolls, filename);
		
	}

}
