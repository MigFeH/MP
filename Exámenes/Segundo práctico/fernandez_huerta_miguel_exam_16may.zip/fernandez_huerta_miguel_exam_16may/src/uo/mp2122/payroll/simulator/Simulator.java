package uo.mp2122.payroll.simulator;

import java.util.List;

import uo.mp.util.ui.Console;
import uo.mp.util.ui.Logger;
import uo.mp2122.payroll.exceptions.WorkshopException;
import uo.mp2122.payroll.monthlyWorkRecord.MonthlyWorkRecord;
import uo.mp2122.payroll.payroll.Payroll;
import uo.mp2122.payroll.workshop.Workshop;



public class Simulator {
	
	private static final String INPUTFILENAME = "monthlyData.txt";
	private static final String OUTPUTFILENAME = "payrolls.txt";
	private Workshop workshop = new Workshop();

	public void run() {
		try
		{
			workshop.configure();
			generatePayrollThisMonth(INPUTFILENAME, OUTPUTFILENAME);			
		} catch(RuntimeException e)
		{
			handleSystemError(e);
			return;
		}catch(WorkshopException e)
		{
			handleUserError(e);
		}
		
	}



	private void handleUserError(Exception e) {
		Console.println("El programa ha finalizado debido a un error interno, revise este error: " + e.getMessage());
	}



	private void handleSystemError(RuntimeException e) {
		Console.println("ERROR IRRECUPERABLE. CONTACTAR CON EL ADMINISTRADOR DEL SISTEMA");
		Logger.log(e);
		Logger.log(e.getMessage());	
	}



	private void generatePayrollThisMonth(String argin, String argout) throws WorkshopException { 
			
		/*
		 * Load, parse and validate the input file
		 */
		workshop.loadMonthlyDataFile(argin);
		
		/*
		 * Display the monthly records generated
		 */
		List<MonthlyWorkRecord> records = workshop.getMonthlyRecords();
		displayRecords(records);
		
		/*
		 * Generate payroll for each employee considering their 
		 * monthly information 
		 */
		workshop.generatePayrolls();
		
		/*
		 * Display payrolls ordered by dni
		 */
		List<Payroll> payrolls = workshop.getPayrolls();
		displayPayrolls(payrolls);
		
		/*
		 * Save payrolls ordered by netSalary, dni
		 */
		workshop.savePayrolls(OUTPUTFILENAME);    
		
	}

	
	private void displayPayrolls(List<Payroll> payrolls) {
		System.out.println("-------- Payrolls ------------");
		System.out.println(
				String.format("%10s %6s %6s %10s \n", 
						"DNI", "MONTH", "YEAR","NETSALARY" ));
		
		for (Payroll p : payrolls) {
			System.out.println(
					String.format("%10s %6s %6s   %.2f \n", 
							p.getDni(),
							p.getMonth(),
							p.getYear(),
							p.getNetSalary()));
						}		
	}


	private void displayRecords(List<MonthlyWorkRecord> records) {
		System.out.println("-------- Monthly records ------------");
		System.out.println(
				String.format("%10s %6s %6s   %6s \n",
						      "DNI", "MONTH", "YEAR", "EXTRA DATA"));
		for (MonthlyWorkRecord record : records) {
			System.out.println(
					String.format("%10s %6s %6s   %.2f \n", 
							record.getDni(), 
							record.getMonth(),
							record.getYear(),
							record.getExtra()
							));
		}		
	}
}
